package com.example.mylaundry;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.example.mylaundry.Model.PreferencesHelper;

public class SplashActivity extends AppCompatActivity {

    ImageView logo;

    PreferencesHelper preferencesHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        preferencesHelper = new PreferencesHelper(this);
        logo = findViewById(R.id.imageView);


        Animation anim1 = AnimationUtils.loadAnimation(this, R.anim.anim);
        logo.startAnimation(anim1);

        anim1.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

//                if (preferencesHelper.getIsLogin()) {
//                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
//                    startActivity(intent);
//                } else {
                Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
                //   }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {


            }


        });
        logo.setOnClickListener(view -> {

            Intent intent1 = new Intent(SplashActivity.this, LoginActivity.class);
            startActivity(intent1);
            finish();


        });


    }


}