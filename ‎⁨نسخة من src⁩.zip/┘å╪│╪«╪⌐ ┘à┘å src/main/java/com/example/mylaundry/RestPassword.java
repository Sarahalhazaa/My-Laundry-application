package com.example.mylaundry;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

import org.checkerframework.checker.nullness.qual.NonNull;

public class RestPassword extends AppCompatActivity {

    EditText emailrest ;

    Button sent ;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rest_password);
        emailrest =findViewById(R.id.editTextTextPersonName5);

      //  String EMAIL =  emailrest.getText().toString();
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        sent = findViewById(R.id.button);


        sent .setOnClickListener(view -> {

            if (TextUtils.isEmpty(emailrest.getText().toString())) {
                Toast.makeText(this, " Please enter email ", Toast.LENGTH_SHORT).show();
            } else {
                progressBar.setVisibility(View.VISIBLE);
                FirebaseAuth.getInstance().sendPasswordResetEmail(emailrest.getText().toString())
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(RestPassword.this, "SENT EMAIL :)", Toast.LENGTH_SHORT).show();
                                    Toast.makeText(getApplicationContext(), "Check Your Email", Toast.LENGTH_SHORT).show();

                                    finish();
                                    Intent intent = new Intent(RestPassword.this, LoginActivity.class);
                                    startActivity(intent);


                                }
                                progressBar.setVisibility(View.GONE);
                            }
                        });

            }

        }
     );}}
