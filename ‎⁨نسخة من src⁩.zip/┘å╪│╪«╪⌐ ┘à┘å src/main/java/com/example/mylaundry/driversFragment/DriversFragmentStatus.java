package com.example.mylaundry.driversFragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.R;
import com.example.mylaundry.driversFragment.AdapterDriver.AdapterDriverStauts;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;


public class DriversFragmentStatus extends Fragment {

    RecyclerView recyclerView;
    AdapterDriverStauts adapterStauts;
    FirebaseFirestore db;
    PreferencesHelper preferencesHelper;
    ArrayList<SubscriptionModel> st;
    SubscriptionModel subscriptionModel;
FirebaseAuth auth =FirebaseAuth.getInstance();
    public DriversFragmentStatus() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragmentreturn inflater.inflate(R.layout.fragment_drivers_status, container, false);
        View rootView = inflater.inflate(R.layout.fragment_drivers_status, container, false);
        recyclerView = rootView.findViewById(R.id.recyclerviewon);
        db = FirebaseFirestore.getInstance();
        preferencesHelper = new PreferencesHelper(getActivity());
        st = new ArrayList<>();
        getData();
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapterStauts = new AdapterDriverStauts(getActivity(), st);
        recyclerView.setAdapter(adapterStauts);

        return rootView;
    }

    void getData() {
        db.collection("SubscriptionDriver").whereEqualTo("key",auth.getUid() ).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        if (!queryDocumentSnapshots.isEmpty()) {
                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                            for (DocumentSnapshot d : list) {
                                subscriptionModel = d.toObject(SubscriptionModel.class);
                                if (subscriptionModel.getType().equals("PREVIOUS")){

                                }else {
                                    st.add(subscriptionModel);
                                }
                            }
                            adapterStauts.update(st);

                        } else {

                            //Toast.makeText(getActivity(), "No data found ", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(e -> {
                    // if we do not get any data or any error we are displaying
                    // a toast message that we do not get any data
                    Toast.makeText(getActivity(), "Fail to get the data.", Toast.LENGTH_SHORT).show();
                });


    }


}