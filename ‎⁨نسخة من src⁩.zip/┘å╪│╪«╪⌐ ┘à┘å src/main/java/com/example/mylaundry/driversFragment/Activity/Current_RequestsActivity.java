package com.example.mylaundry.driversFragment.Activity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.R;
import com.example.mylaundry.driversFragment.AdapterDriver.AdapterNewOrder;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class Current_RequestsActivity extends AppCompatActivity {

    ArrayList<RequestModel> st;
    RecyclerView recyclerView;
    AdapterNewOrder adapterviewOrder;
    FirebaseFirestore db;
    PreferencesHelper preferencesHelper;
    RequestModel requestModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_requests2);


        db = FirebaseFirestore.getInstance();
        recyclerView = findViewById(R.id.recyclerviewder);
        st = new ArrayList<>();
        preferencesHelper =new PreferencesHelper(this);


        Button back = findViewById(R.id.button16);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        getData();

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapterviewOrder = new AdapterNewOrder(this, st,1);
        recyclerView.setAdapter(adapterviewOrder);
    }


    void getData() {
        db.collection("RequestModel").get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        if (!queryDocumentSnapshots.isEmpty()) {
                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                            for (DocumentSnapshot d : list) {
                                preferencesHelper.setPREF_Item_Update(d.getId());

                                requestModel = d.toObject(RequestModel.class);
                                if (requestModel.getType().equals("Delivered")||requestModel.getType().equals("request Rejected")||requestModel.getType().equals("loading")){
                                    Toast.makeText(Current_RequestsActivity.this, "No data found ", Toast.LENGTH_SHORT).show();


                                }else {
                                    st.add(requestModel);
                                }

                            }
                            adapterviewOrder.update(st);

                        } else {

                            Toast.makeText(Current_RequestsActivity.this, "No data found ", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(e -> {
                    // if we do not get any data or any error we are displaying
                    // a toast message that we do not get any data
                    Toast.makeText(Current_RequestsActivity.this, "Fail to get the data.", Toast.LENGTH_SHORT).show();
                });


    }
}