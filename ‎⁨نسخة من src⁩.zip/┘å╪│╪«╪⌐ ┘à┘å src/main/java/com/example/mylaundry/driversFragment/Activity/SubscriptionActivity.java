package com.example.mylaundry.driversFragment.Activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.R;
import com.example.mylaundry.driversFragment.AdapterDriver.AdapterNewSubDriver;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class SubscriptionActivity extends AppCompatActivity {

    Button New_sup;
    RecyclerView recyclerView;
    AdapterNewSubDriver adapterNewSubDriver ;
    FirebaseFirestore db;
    ArrayList<SubscriptionModel> st;
    SubscriptionModel subscriptionModel;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subscription2);

        New_sup = findViewById(R.id.button25);
        recyclerView = findViewById(R.id.recy_driver);

        db = FirebaseFirestore.getInstance();
        st = new ArrayList<>();
        auth=FirebaseAuth.getInstance();
        New_sup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent sup=new Intent(SubscriptionActivity.this, NewSubDriver.class);
                startActivity(sup);
            }
        });

        getData();

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapterNewSubDriver = new AdapterNewSubDriver(this, st);
        recyclerView.setAdapter(adapterNewSubDriver);



    }


    void getData(){



        db.collection("SubscriptionDriver").whereEqualTo("key",auth.getUid() ).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        if (!queryDocumentSnapshots.isEmpty()) {
                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                            for (DocumentSnapshot d : list) {
                                subscriptionModel = d.toObject(SubscriptionModel.class);
                                New_sup.setVisibility(View.GONE);

                                if (subscriptionModel.getType().equals("PREVIOUS")){
                                    New_sup.setVisibility(View.VISIBLE);

                                }else {
                                    New_sup.setVisibility(View.GONE);
                                    st.add(subscriptionModel);
                                }
                            }
                            adapterNewSubDriver.update(st);
                            New_sup.setVisibility(View.GONE);

                        } else {
                            New_sup.setVisibility(View.VISIBLE);
                            Toast.makeText(SubscriptionActivity.this, "No data found ", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(e -> {
                    // if we do not get any data or any error we are displaying
                    // a toast message that we do not get any data
                    Toast.makeText(SubscriptionActivity.this, "Fail to get the data.", Toast.LENGTH_SHORT).show();
                });

    }

}