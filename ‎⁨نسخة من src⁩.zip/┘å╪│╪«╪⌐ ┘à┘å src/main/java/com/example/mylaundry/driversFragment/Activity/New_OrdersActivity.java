package com.example.mylaundry.driversFragment.Activity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dhims.timerview.TimerTextView;
import com.example.mylaundry.AcivitysMainFragment.ActivityCurrentRequests;
import com.example.mylaundry.AdapterView.AdapterviewOrder;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.R;
import com.example.mylaundry.databinding.ActivityNewOrdersBinding;
import com.example.mylaundry.driversFragment.AdapterDriver.AdapterNewOrder;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class New_OrdersActivity extends AppCompatActivity {
    ArrayList<RequestModel> st;
    CountDownTimer timer2;
    AdapterNewOrder adapterviewOrder;
    FirebaseFirestore db;
    PreferencesHelper preferencesHelper;
    RequestModel requestModel;
    ActivityNewOrdersBinding binding;
    int  counter;
    ArrayList<String> listid= new ArrayList<>();
    String type;
     String typess;
     String area;
     FirebaseAuth auth=FirebaseAuth.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= DataBindingUtil.setContentView(this,R.layout.activity_new_orders);


        db = FirebaseFirestore.getInstance();

        st = new ArrayList<>();
        preferencesHelper =new PreferencesHelper(this);


//        futureTimestamp==00.00.00













        binding.recyclerviewder.setHasFixedSize(true);
        binding.recyclerviewder.setLayoutManager(new LinearLayoutManager(this));
        adapterviewOrder = new AdapterNewOrder(this, st ,0);
        binding.recyclerviewder.setAdapter(adapterviewOrder);

    }

    void getData() {
        db.collection("RequestModel").whereEqualTo("city", area).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        if (!queryDocumentSnapshots.isEmpty()) {
                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                            st.clear();
                            listid.clear();
                            for (DocumentSnapshot d : list) {
                                preferencesHelper.setPREF_Item_Update(d.getId());

                                requestModel = d.toObject(RequestModel.class);

                                if (requestModel.getType().equals("loading")) {
                                    type = requestModel.getType();
                                    listid.add(requestModel.getDocumentId());
                                    counter = listid.size();
                                    st.add(requestModel);
                                }else {

                                }
                            }
                            adapterviewOrder.update(st);
                            //adapterviewOrder.notifyDataSetChanged();
                            timer(counter);
                            //Toast.makeText(New_OrdersActivity.this, ""+list.size(), Toast.LENGTH_SHORT).show();

                        } else {
                            st.clear();
                            adapterviewOrder.update(st);
                            Toast.makeText(New_OrdersActivity.this, "No data found ", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(e -> {
                    // if we do not get any data or any error we are displaying
                    // a toast message that we do not get any data
                    Toast.makeText(New_OrdersActivity.this, "Fail to get the data.", Toast.LENGTH_SHORT).show();
                });


    }


  private void timer(int num){
        if (num<=0){
            Toast.makeText(New_OrdersActivity.this, "no delete", Toast.LENGTH_SHORT).show();

            //  Toast.makeText(this, ""+listid.get(0), Toast.LENGTH_SHORT).show();
        }else {
            long futureTimestamp = System.currentTimeMillis() + (5 * 60 * 1000);
            binding.timerTexts.setEndTime(futureTimestamp);

          new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    db.collection("RequestModel").document(listid.get(0)).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            typess=documentSnapshot.getString("type");
                            if (typess.equals("request accepted")|| typess.equals("Delivered")){
                                Toast.makeText(New_OrdersActivity.this, "no", Toast.LENGTH_SHORT).show();
                                getData();
                            }else {
                                Toast.makeText(New_OrdersActivity.this, "yes", Toast.LENGTH_SHORT).show();
                                db.collection("RequestModel").document(listid.get(0))
                             .update("type","request Rejected" );
                                getData();
                            }
                           // Toast.makeText(New_OrdersActivity.this, ""+typess, Toast.LENGTH_SHORT).show();
                        }
                    });
                    //Toast.makeText(New_OrdersActivity.this, "delete"+getdtat2(listid.get(0)), Toast.LENGTH_SHORT).show();

//                          db.collection("RequestModel").document(listid.get(0))
//              .update("type","request Rejected" );

                }
            }, 300000);
        }

//      db.collection("RequestModel").document(listid.get(0))
//              .update("type","request Rejected" );
    }

    @Override
    protected void onStart() {
        super.onStart();
        db.collection("SubscriptionDriver").whereEqualTo("key",auth.getUid())
                .get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (DocumentSnapshot document : task.getResult()) {
                                 area = document.getString("area");
                            }
                            getData();
                        }
                        else {
                           // Toast.makeText(getContext(), "fill", Toast.LENGTH_SHORT).show();
                        }

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(New_OrdersActivity.this, "fill"+e.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
      //  Toast.makeText(this, ""+, Toast.LENGTH_SHORT).show();
//        if (counter<=0){
//
//        }else {
//            timer2.onFinish();
//        }


    }


}