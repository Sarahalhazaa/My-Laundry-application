package com.example.mylaundry.driversFragment.AdapterDriver;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.AcivitysMainFragment.Details_Order;
import com.example.mylaundry.AdapterView.AdapterviewOrder;
import com.example.mylaundry.AdapterView.ModelArray;
import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.R;
import com.example.mylaundry.driversFragment.Activity.NewOrder_DEtlActivity;

import java.util.ArrayList;

public class AdapterNewOrder extends RecyclerView.Adapter<AdapterNewOrder.myViewHolder> {
    Activity activity;
    ArrayList<RequestModel> data;

    int TypeOrder ;


    public void update(ArrayList<RequestModel> newList) {
        data = newList;
        notifyDataSetChanged();
    }

    public AdapterNewOrder(Activity activity, ArrayList<RequestModel> data ,int TypeOrder) {
        this.activity = activity;
        this.data = data;
        this.TypeOrder=TypeOrder;
    }
    @Override
    public AdapterNewOrder.myViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(activity).inflate(R.layout.itemdel, parent, false);
        return new AdapterNewOrder.myViewHolder(root);
    }

    @Override
    public void onBindViewHolder(AdapterNewOrder.myViewHolder holder, int position) {
        RequestModel model = data.get(position);


        holder.tv_name.setText(model.getNamelaundry());
        holder.type.setText(model.getType());



        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(activity, NewOrder_DEtlActivity.class);

                intent.putExtra("namela", model.getNamelaundry());
                intent .putExtra("TypeOrder",TypeOrder);
                intent.putExtra("dec",model.getDocumentId());
                intent.putExtra("keyuser",model.getKeyuser());
                intent.putExtra("address", model.getAddress());
                intent.putExtra("EMAIL", model.getEmail());
                intent.putExtra("addtax", model.getAddtax());
                intent.putExtra("amount", model.getAmount());
                intent.putExtra("date", model.getDate());
                intent.putExtra("total", model.getTotal());
                intent.putExtra("number", model.getNumberRequest());
                intent.putExtra("NAME", model.getNamelaundry());
                intent.putExtra("type",model.getType());
                intent.putExtra("numberorders",model.getNumberRequest());

                ModelArray modelArray = new ModelArray();
                modelArray.setOrderData(model.getData());

                intent.putExtra("DataOrder", modelArray);

                activity.startActivity(intent);
                activity.finish();


            }
        });
    }

    @Override
    public int getItemCount() {
        return  data.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {
        TextView tv_name, type;
        public myViewHolder(View itemView) {
            super(itemView);
            tv_name = itemView.findViewById(R.id.textname);
            type = itemView.findViewById(R.id.stut);
        }
    }
}
