package com.example.mylaundry.driversFragment;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.mylaundry.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivityDrivers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_drivers);

        BottomNavigationView bottomNav = findViewById(R.id.Owner_navigatin_view);
        bottomNav.setOnNavigationItemSelectedListener(navListener);
        getSupportFragmentManager().beginTransaction().replace(R.id.drivers_container, new DriversFragmentMain()).commit();

    }

    private final BottomNavigationView.OnNavigationItemSelectedListener navListener = item -> {
        Fragment selectedFragment = null;
        int itemId = item.getItemId();
        if (itemId == R.id.homeowner) {
            selectedFragment = new DriversFragmentMain();
        } else if (itemId == R.id.status) {
            selectedFragment = new DriversFragmentStatus();
        } else if (itemId == R.id.moreowner) {
            selectedFragment = new DriversFragmentMore();
        }
        // It will help to replace the
        // one fragment to other.
        if (selectedFragment != null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.drivers_container, selectedFragment).commit();
        }
        return true;
    };

}