package com.example.mylaundry.driversFragment.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mylaundry.AdapterView.AdapterOrder;
import com.example.mylaundry.AdapterView.ModelArray;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.kofigyan.stateprogressbar.StateProgressBar;
import com.kofigyan.stateprogressbar.components.StateItem;
import com.kofigyan.stateprogressbar.listeners.OnStateItemClickListener;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;
import java.util.List;

public class NewOrder_DEtlActivity extends AppCompatActivity {
    ArrayList<RequestModel> requestModels;
    RecyclerView recyclerView;
    TextView total, addtax, amount, namela, Date, stat, number;
    TextView time;
    ArrayList<Services> services;
    AdapterOrder adapterCon;
    FirebaseFirestore firestore,getFirestore;
    ModelArray model;
    AdapterOrder adapterOrder;
    PreferencesHelper preferencesHelper;
    String[] descriptionData = {"Waiting for request", "request accepted",
            "Items received", "Items have been delivered to the laundromat", "Delivered"};
    TextView tv1,tv2,tv3,tv4,tv5,tv6;
    Button Acceptance ,Objects_received ,Delivered;
    String EMAIL,NAME;
    ModelArray modelArray;
    String Status_Order;
   int TypeOrder ;
   String decomentid;
   String keyuser;
   String type;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_order_detl);
        namela = findViewById(R.id.namelaundryorder);
        recyclerView = findViewById(R.id.recyclerView);
        stat = findViewById(R.id.textView70);
        total = findViewById(R.id.totalnumber);
        number = findViewById(R.id.textView33);
        addtax = findViewById(R.id.totalprice);
        amount = findViewById(R.id.totalp);
        Acceptance=findViewById(R.id.button18);
        Objects_received=findViewById(R.id.button19);
        Delivered=findViewById(R.id.button20);
        keyuser=getIntent().getStringExtra("keyuser");
        decomentid=getIntent().getStringExtra("dec");
        type=getIntent().getStringExtra("type");
         EMAIL =getIntent().getStringExtra("EMAIL");
         String numberorders=getIntent().getStringExtra("numberorders");
        number.setText(numberorders);
                firestore = FirebaseFirestore.getInstance();
        getFirestore = FirebaseFirestore.getInstance();




        TypeOrder=getIntent().getIntExtra("TypeOrder",0);


        switch(TypeOrder) {
            case 0:
                Acceptance.setVisibility(View.VISIBLE);
                Objects_received.setVisibility(View.GONE);
                Delivered.setVisibility(View.GONE);

                break;
            case 1:
                Acceptance.setVisibility(View.GONE);
                Objects_received.setVisibility(View.VISIBLE);
                Delivered.setVisibility(View.GONE);
                break;
            case 2:
                Acceptance.setVisibility(View.GONE);
                Objects_received.setVisibility(View.GONE);
                Delivered.setVisibility(View.GONE);

                break;
        }


        Acceptance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                firestore.collection("RequestModel").document(preferencesHelper.getPREF_Item_Update())
                        .update("type","request accepted" );

                onBackPressed();
            }
        });
        Objects_received.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            if (type.equals("request finished")) {

                firestore.collection("RequestModel").document(preferencesHelper.getPREF_Item_Update())
                        .update("type", "Delivered");
                onBackPressed();
            }else {
                Toast.makeText(NewOrder_DEtlActivity.this, "no request finished", Toast.LENGTH_SHORT).show();
            }
//                TypeOrder = 2 ;
//                finish();
//                startActivity(getIntent());



            }
        });

        Delivered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firestore.collection("RequestModel").document(preferencesHelper.getPREF_Item_Update())
                        .update("type","Delivered" );

                onBackPressed();

            }
        });













        modelArray = (ModelArray) getIntent().getSerializableExtra("DataOrder");
        Log.d("order", "onCreate: " + modelArray.getOrder());

        NAME=getIntent().getStringExtra("NAME");




        preferencesHelper = new PreferencesHelper(this);

        recyclerView.setHasFixedSize(true);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapterOrder = new AdapterOrder(this, modelArray.getOrderData());

        recyclerView.setAdapter(adapterOrder);


        stat.setText("request accepted");

        StateProgressBar stateProgressBar = findViewById(R.id.your_state_progress_bar_id);
        stateProgressBar.setOnStateItemClickListener(new OnStateItemClickListener() {
            @Override
            public void onStateItemClick(StateProgressBar stateProgressBar, StateItem stateItem, int stateNumber, boolean isCurrentState) {
                Toast.makeText(getApplicationContext(), "state Clicked Number is "
                        + stateNumber, Toast.LENGTH_LONG).show();
            }
        });





        String name = getIntent().getStringExtra("namela");
        namela.setText(name);
        String totall = getIntent().getStringExtra("total");
        total.setText(totall);
        String Addtax = getIntent().getStringExtra("addtax");
        addtax.setText(Addtax);
        String Amount = getIntent().getStringExtra("amount");
        amount.setText(Amount);
        String Nu = getIntent().getStringExtra("number");
        model = (ModelArray) getIntent().getSerializableExtra("getdata");





        // stateProgressBar.setStateDescriptionData(descriptionData);



        tv1=findViewById(R.id.textView78);
        tv2=findViewById(R.id.textView79);
        tv3=findViewById(R.id.textView80);


        tv4=findViewById(R.id.textView76);
        tv5=findViewById(R.id.textView81);
        tv6=findViewById(R.id.textView82);

        Log.d("khadijat", "onCreate: "+ EMAIL);

        firestore.collection("user")
                .whereEqualTo("key",keyuser)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (DocumentSnapshot document : task.getResult()) {
                                String street_name = document.getString("street_name");
                                String nearest_teacher = document.getString("nearest_teacher");
                                String cityname = document.getString("cityname");
                                String homenumber=document.getString("home_number");
                                Status_Order=document.getString("type");
                                Log.d("khadijat", "onCreate: "+ street_name );
                                Log.d("khadijat", "onCreate: "+ nearest_teacher );

                                tv4.setText("Neighborhood :" +cityname);
                                tv5.setText("Street name  :" +street_name);
                                tv6.setText("Nearest landmark :" +nearest_teacher +"\n" + "home number :" +homenumber);
                                tv1.setText("name  :" +name);
//                                password = document.getString("password");
//                                pass = Integer.parseInt(password);

//                                Log.d("date", "onComplete: " + email);
//                                Log.d("date", "onComplete: " + numberphone);
//                                Log.d("date", "onComplete: " + name);
//                                et_name.setHint(name + "" + namelast);
//                                et_email.setHint(email);
//                                et_phone.setHint(numberphone);


                            }
                        } else {
                            Log.d("TAG", "Error getting documents: ", task.getException());
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("INDEXXX", e.toString());
                    }
                });




        getFirestore.collection("Subscription")
                .whereEqualTo("name", NAME)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (DocumentSnapshot document : task.getResult()) {
                                String name = document.getString("name");
                                String area = document.getString("area");
                                String street = document.getString("street");

                                tv1.setText("name  :" +name);
                                tv2.setText("Street name  :" +area);
                                tv3.setText("Nearest landmark :" +street);

//                                password = document.getString("password");
//                                pass = Integer.parseInt(password);
//
//                                Log.d("date", "onComplete: " + email);
//                                Log.d("date", "onComplete: " + numberphone);
//                                Log.d("date", "onComplete: " + name);
//                                et_name.setHint(name + "" + namelast);
//                                et_email.setHint(email);
//                                et_phone.setHint(numberphone);


                            }
                        } else {
                            Log.d("TAG", "Error getting documents: ", task.getException());
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("INDEXXX", e.toString());
                    }
                });



//                switch (Status_Order) {
//            case "request accepted":
//                stateProgressBar.setCurrentStateNumber(StateProgressBar.StateNumber.TWO);
//                break;
//            case "Objects received":
//                stateProgressBar.setCurrentStateNumber(StateProgressBar.StateNumber.THREE);
//                break;
//            case "delivered to the laundry":
//                stateProgressBar.setCurrentStateNumber(StateProgressBar.StateNumber.FOUR);
//                break;
//            case "Delivered":
//                stateProgressBar.setAllStatesCompleted(true);
//                break;
      //  }



    }
}