package com.example.mylaundry.driversFragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.fragment.app.Fragment;

import com.example.mylaundry.ActivitysMore.ModifyData;
import com.example.mylaundry.EditDataDriver;
import com.example.mylaundry.R;
import com.example.mylaundry.SplashActivity;
import com.example.mylaundry.driversFragment.Activity.SubscriptionActivity;


public class DriversFragmentMore extends Fragment {

    LinearLayout account ;
    LinearLayout Sup , out ;



    public DriversFragmentMore() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View rootView = inflater.inflate(R.layout.fragment_drivers_more, container, false);

        account = rootView.findViewById(R.id.linera);
        Sup = rootView.findViewById(R.id.linera2);
        out=rootView.findViewById(R.id.linera4);
        account .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent modify = new Intent(getActivity(), EditDataDriver.class);
                startActivity(modify);

            }
        });
        Sup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Sup = new Intent(getActivity() , SubscriptionActivity.class);
                startActivity(Sup);


            }
        });
        out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
                Intent out = new Intent(getActivity() , SplashActivity.class);
                startActivity(out);
            }
        });














        return  rootView;
    }
}