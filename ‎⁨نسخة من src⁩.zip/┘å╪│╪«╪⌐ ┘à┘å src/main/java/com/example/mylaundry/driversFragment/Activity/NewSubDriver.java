package com.example.mylaundry.driversFragment.Activity;

import android.annotation.TargetApi;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mylaundry.AdapterView.AdapterItem;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.R;
import com.example.mylaundry.helpers.Constants;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Locale;
import java.util.Random;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class NewSubDriver extends AppCompatActivity {
    EditText name;
    EditText phone , ID , briday ,email;
    Button done;
    LocalDate enddate;
    int age;
    String nation;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    String[] Area2 = {"Al-Suwaidi district", "Al-Nafl district", "Al-Awali district", "Al-Yasmeen district",
            "Al-Mursalat District", "Al-Sahafah district", "Al-Sahafah district", "Al-Yarmouk district"};

    String[] duration = new String[]{"6 months", "One year"};

    FrameLayout frameLayout;
    private FirebaseAuth mAuth;
    FirebaseFirestore db;
    String selectedText;
    Calendar myCalendar;
    AdapterItem adapterItem;

    Spinner spino , spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.subscription_driver);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        name = findViewById(R.id.edit_name);
        phone = findViewById(R.id.edtiphone);
        email = findViewById(R.id.edit_mail);
        ID = findViewById(R.id.edit_mail2);
        done = findViewById(R.id.button26);
        briday = findViewById(R.id.edit_age);


        myCalendar = Calendar.getInstance();

        DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, day);
                updateLabel();
            }
        };


        briday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(NewSubDriver.this, date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();

            }
        });


        spino = findViewById(R.id.spinner);

        ArrayAdapter ad
                = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, Area2);//        holder.inputLayout.setAdapter(adapter);
        ad.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        spino.setAdapter(ad);
        Area2[0] = "Select  Neighborhood";
        spino.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int mPosition, long id) {

                // Toast.makeText(getApplicationContext(), Area.get(mPosition), Toast.LENGTH_LONG).show();
            }


            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });


        spinner = findViewById(R.id.spinner2);
        ArrayAdapter ad1
                = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, duration);//        holder.inputLayout.setAdapter(adapter);
        ad1.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(ad1);
        // duration[0] = "Select  duration";
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @TargetApi(Build.VERSION_CODES.O)
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int mPosition, long id) {

                if (spinner.getSelectedItem().equals("6 months")) {

                    enddate = LocalDate.now().plusMonths(6);


                    Log.d("date", "onCreate: " + LocalDate.now().plusMonths(6));
                } else if (spinner.getSelectedItem().equals("One year")) {
                    Log.d("date", "onCreate:year " + LocalDate.now().plusMonths(12));

                    enddate = LocalDate.now().plusMonths(12);


                }

                // Toast.makeText(getApplicationContext(), duration.get(mPosition), Toast.LENGTH_LONG).show();
            }


            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });



        done.setOnClickListener(new View.OnClickListener() {
            @TargetApi(Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {

                if (name.getText().toString().isEmpty()){
                    name.setError("name is empty");
                    return;
                }
                if( phone.getText().toString().isEmpty()){
                    phone.setError("phone is empty");
                    return;
                }
                if(email.getText().toString().isEmpty()){
                    email.setError("email is empty");
                    return;
                }
                if (ID.getText().toString().isEmpty())
                {ID.setError("ID is empty");
                return;
                    //Toast.makeText(getApplicationContext(), "  Plz   fill in all required data", Toast.LENGTH_SHORT).show();
                }
                else if (email.getText().toString().isEmpty()
                        && !Patterns.EMAIL_ADDRESS.matcher(email.getText().toString().trim()).matches()
                        || !email.getText().toString().matches(emailPattern)) {
                    email.setError(" email is valid");
                }
                else if (spinner.getSelectedItem().equals("Select  duration")) {
                    new SweetAlertDialog(NewSubDriver.this)
                            .setTitleText("Sorry, Select  duration ")
                            .show();
                } else if (spino.getSelectedItem().equals("Select  Neighborhood")) {
                    new SweetAlertDialog(NewSubDriver.this)
                            .setTitleText("Sorry, Select  Neighborhood ")
                            .show();

                } else if (phone.length() > 8 || phone.length() < 8) {
                    phone.setError("You must enter 8 numbers");

                } else if (ID.length() > 10 || ID.length() < 10) {
                    ID.setError("not equals 10 numbers");

                } else {

                    Random r = new Random();
                    int randomNumber = r.nextInt(100);
                    String random = Integer.toString(randomNumber);
                    LocalDate date = LocalDate.now();
                    Log.d("date", "onClick: " + date.toString());


                    SubscriptionModel subscriptionModel = new SubscriptionModel(
                            name.getText().toString(),
                            phone.getText().toString(),
                            email.getText().toString(),
                            spino.getSelectedItem().toString(),
                            spinner.getSelectedItem().toString(),
                            random,
                            LocalDate.now().toString(),
                            enddate.toString(),
                            "wait",
                            Constants.NEW ,
                            ID.getText().toString(),
                            "driver" );
                    subscriptionModel.setStatus("not work");
                    subscriptionModel.setKey(mAuth.getUid());
                    subscriptionModel.setNationality(nation);

                    db.collection("SubscriptionDriver")
                            .add(subscriptionModel)
                            .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                @Override
                                public void onSuccess(DocumentReference documentReference) {
                                    Log.d("TAG", "DocumentSnapshot written with ID: " + documentReference.getId());
                                    db.collection("SubscriptionDriver").document(documentReference.getId())
                                            .update("documentId", documentReference.getId());
                                   // preferencesHelper.setPREF_subscription_DOCID(documentReference.getId());


                                    finish();
                                    Intent intent = new Intent(getApplicationContext(), SubscriptionActivity.class);
                                    startActivity(intent);
                                    Toast.makeText(NewSubDriver.this, " DONE", Toast.LENGTH_SHORT).show();

                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.w("TAG", "Error adding document", e);


                                }
                            });


                }











            }
        });





    }



    private void updateLabel() {
        String myFormat = "MM/dd/yyyy";
        SimpleDateFormat dateFormat = new SimpleDateFormat(myFormat, Locale.US);
        briday.setText(dateFormat.format(myCalendar.getTime()));
        age = getPerfectAgeInYears(myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH));
        Log.d("age", "updateLabel: " + getPerfectAgeInYears(myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)));
    }


    public int getPerfectAgeInYears(int year, int month, int date) {
        Calendar dobCalendar = Calendar.getInstance();
        dobCalendar.set(Calendar.YEAR, year);
        dobCalendar.set(Calendar.MONTH, month);
        dobCalendar.set(Calendar.DATE, date);

        int ageInteger = 0;

        Calendar today = Calendar.getInstance();

        ageInteger = today.get(Calendar.YEAR) - dobCalendar.get(Calendar.YEAR);

        if (today.get(Calendar.MONTH) == dobCalendar.get(Calendar.MONTH)) {

            if (today.get(Calendar.DAY_OF_MONTH) < dobCalendar.get(Calendar.DAY_OF_MONTH)) {

                ageInteger = ageInteger - 1;
            }

        } else if (today.get(Calendar.MONTH) < dobCalendar.get(Calendar.MONTH)) {

            ageInteger = ageInteger - 1;

        }

        return ageInteger;

    }

    @Override
    protected void onStart() {
        super.onStart();
        db.collection("user").document(mAuth.getUid()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if (documentSnapshot.exists()){
                    nation=documentSnapshot.getString("nationality");
                    Toast.makeText(NewSubDriver.this, ""+nation, Toast.LENGTH_SHORT).show();
                }else {
                    nation="not know";
                    Toast.makeText(NewSubDriver.this, ""+nation, Toast.LENGTH_SHORT).show();

                }

            }
        });
    }
}