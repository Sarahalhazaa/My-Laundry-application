package com.example.mylaundry.driversFragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.mylaundry.R;
import com.example.mylaundry.databinding.FragmentDriversMainBinding;
import com.example.mylaundry.driversFragment.Activity.Current_RequestsActivity;
import com.example.mylaundry.driversFragment.Activity.New_OrdersActivity;
import com.example.mylaundry.driversFragment.Activity.Previous_RequestsActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;


public class DriversFragmentMain extends Fragment {
    FragmentDriversMainBinding binding;

    TextView new_requ, current_requ, previous_requ;
    FirebaseAuth auth;
    FirebaseFirestore firestore;
    public DriversFragmentMain() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_drivers_main, container, false);
        auth=FirebaseAuth.getInstance();
        firestore=FirebaseFirestore.getInstance();
        new_requ =rootView.findViewById(R.id.textView48);
        current_requ =rootView.findViewById(R.id.textView49);
        previous_requ =rootView.findViewById(R.id.textView74);
        new_requ.setEnabled(false);
        current_requ.setEnabled(false);
        previous_requ.setEnabled(false);


        firestore.collection("SubscriptionDriver").whereEqualTo("key",auth.getUid())
                .get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {

                            for (DocumentSnapshot document : task.getResult()) {
                                String status = document.getString("status");
                                String type = document.getString("type");
                                if (status.equals("work") && type.equals("CURRENT")){
                                    new_requ.setEnabled(true);
                                    current_requ.setEnabled(true);
                                    previous_requ.setEnabled(true);
                                }
                                else {
                                    new_requ.setEnabled(false);
                                    current_requ.setEnabled(false);
                                    previous_requ.setEnabled(false);


                                }





                            }
                        }else {
                            Toast.makeText(getContext(), "fill", Toast.LENGTH_SHORT).show();
                        }

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getContext(), "fill"+e.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });

        new_requ.setOnClickListener(v -> {

            Intent intent = new Intent(getActivity(), New_OrdersActivity.class);
            startActivity(intent);

        });

        current_requ.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), Current_RequestsActivity.class);
            startActivity(intent);

        });

        previous_requ.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), Previous_RequestsActivity.class);
            startActivity(intent);

        });

        return rootView;
    }


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);




    }

    @Override
    public void onStart() {
        super.onStart();


    }
}