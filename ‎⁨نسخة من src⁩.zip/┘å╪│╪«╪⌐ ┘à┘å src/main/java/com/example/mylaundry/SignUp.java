package com.example.mylaundry;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.mylaundry.AcivitysOfLaundry.OrderConfirmation;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.UserType;
import com.example.mylaundry.Model.user.dataDriver;
import com.example.mylaundry.Model.user.dataowner;
import com.example.mylaundry.Model.user.datauser;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Pattern;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class SignUp extends AppCompatActivity {

    EditText Ed_firstname, ed_lastname, edit_phone, edit_age,
            edit_pass, edit_passconfirm, edit_email, edit_nationalityid;

    int age;
    Boolean IsExisting = false;

    FrameLayout frameLayout;

    //edit_nationality,
//    Button bt_User, bt_Driver, bt_Owner, sign, back;

    String[] Area = {"Gulf", "Saudi", "Egyptian", "Indian",
            "Emirati", "Omani", "diagonal"};

    String[] Area2 = {"Al-Suwaidi district", "Al-Nafl district", "Al-Awali district", "Al-Yasmeen district",
            "Al-Mursalat District", "Al-Sahafah district", "Al-Sahafah district", "Al-Yarmouk district"};


    RadioButton bt_User, bt_Driver, bt_Owner;
    RadioGroup group;
    Button back, sign;
    private FirebaseAuth mAuth;
    FirebaseFirestore db;
    String selectedText;

    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    // String emailPattern2= "/^\\w+([\\.-]?\\w+)@\\w+([\\.-]?\\w+)(\\.\\w{2,3})+$/";

    Spinner spinner, spino;
    String nationality;
    PreferencesHelper preferencesHelper;
    EditText Street_name, nearest_teacher, home_number;
    Calendar myCalendar;
    int position = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        init();
        mAuth = FirebaseAuth.getInstance(); // auth
        preferencesHelper =new PreferencesHelper(this);
        db = FirebaseFirestore.getInstance(); // database
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);

            }
        });


        ArrayAdapter ad = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, Area);//        holder.inputLayout.setAdapter(adapter);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinner.setAdapter(ad);

        Area[0] = "Select nationality";

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int mPosition, long id) {


                // Toast.makeText(getApplicationContext(), Area.get(mPosition), Toast.LENGTH_LONG).show();

                //   nationality =Area.get(mPosition);
                if (parent.getItemAtPosition(mPosition).equals("Select nationality")) {

                } else {
                    String item = parent.getItemAtPosition(position).toString();
                    //   Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_SHORT).show();
                }

            }


            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });


        myCalendar = Calendar.getInstance();

        DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, day);
                updateLabel();
            }
        };
        edit_age.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(SignUp.this, date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });


        ArrayAdapter ad2 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, Area2);//        holder.inputLayout.setAdapter(adapter);
        ad2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        Area2[0] = "Select  neighborhood";

        spino.setAdapter(ad2);
        spino.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int mPosition, long id) {

                if (parent.getItemAtPosition(mPosition).equals("Select  neighborhood")) {

                } else {
                    String item = parent.getItemAtPosition(position).toString();
                    //Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });


        group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                int radioBtnID = group.getCheckedRadioButtonId();
                View radioB = group.findViewById(radioBtnID);

                RadioButton radioButton = (RadioButton) group.findViewById(radioBtnID);

                selectedText = (String) radioButton.getText();


                position = group.indexOfChild(radioB);

//                Street_name = findViewById(R.id.Streetname);
//                nearest_teacher = findViewById(R.id.namestree);
//                home_number = findViewById(R.id.numberhome);


//                if(position == -1){
//
//
//                    Ed_firstname.setVisibility(View.GONE);
//                    ed_lastname.setVisibility(View.GONE);
//                    edit_phone.setVisibility(View.GONE);
//                    edit_age.setVisibility(View.GONE);
//                    edit_pass.setVisibility(View.GONE);
//                    edit_passconfirm.setVisibility(View.GONE);
//                    edit_email.setVisibility(View.GONE);
//                    edit_nationalityid.setVisibility(View.GONE);
//                    spino.setVisibility(View.GONE);
//                    spinner.setVisibility(View.GONE);
//                    sign.setVisibility(View.GONE);
//
//                }
//               else
                if (position == 0) {

                    Ed_firstname.setVisibility(View.VISIBLE);
                    ed_lastname.setVisibility(View.VISIBLE);
                    edit_phone.setVisibility(View.VISIBLE);
                    edit_pass.setVisibility(View.VISIBLE);
                    edit_passconfirm.setVisibility(View.VISIBLE);
                    edit_email.setVisibility(View.VISIBLE);
                    sign.setVisibility(View.VISIBLE);
                    frameLayout.setVisibility(View.VISIBLE);

                    edit_age.setVisibility(View.GONE);
                    spinner.setVisibility(View.GONE);
                    spino.setVisibility(View.VISIBLE);
                    edit_nationalityid.setVisibility(View.GONE);
                    Street_name.setVisibility(View.VISIBLE);
                    nearest_teacher.setVisibility(View.VISIBLE);
                    home_number.setVisibility(View.VISIBLE);
                   // Toast.makeText(SignUp.this, "" + position, Toast.LENGTH_SHORT).show();


                } else if (position == 2) {
                    //     edit_age.setVisibility(View.VISIBLE);

                    frameLayout.setVisibility(View.VISIBLE);

                    Ed_firstname.setVisibility(View.VISIBLE);
                    ed_lastname.setVisibility(View.VISIBLE);
                    edit_phone.setVisibility(View.VISIBLE);
                    edit_pass.setVisibility(View.VISIBLE);
                    edit_passconfirm.setVisibility(View.VISIBLE);
                    edit_email.setVisibility(View.VISIBLE);
                    sign.setVisibility(View.VISIBLE);
                    edit_age.setVisibility(View.GONE);
                    spino.setVisibility(View.GONE);
                    spinner.setVisibility(View.GONE);
                    edit_nationalityid.setVisibility(View.GONE);
                    Street_name.setVisibility(View.GONE);
                    nearest_teacher.setVisibility(View.GONE);
                    home_number.setVisibility(View.GONE);
                    Toast.makeText(SignUp.this, "" + position, Toast.LENGTH_SHORT).show();

                } else if (position == 1) {
                    frameLayout.setVisibility(View.VISIBLE);

                    Ed_firstname.setVisibility(View.VISIBLE);
                    ed_lastname.setVisibility(View.VISIBLE);
                    edit_phone.setVisibility(View.VISIBLE);
                    edit_pass.setVisibility(View.VISIBLE);
                    edit_passconfirm.setVisibility(View.VISIBLE);
                    edit_email.setVisibility(View.VISIBLE);
                    sign.setVisibility(View.VISIBLE);

                    edit_age.setVisibility(View.VISIBLE);
                    spinner.setVisibility(View.VISIBLE);
                    spino.setVisibility(View.GONE);
                    edit_nationalityid.setVisibility(View.VISIBLE);
                    Street_name.setVisibility(View.GONE);
                    nearest_teacher.setVisibility(View.GONE);
                    home_number.setVisibility(View.GONE);
                    Toast.makeText(SignUp.this, "" + position, Toast.LENGTH_SHORT).show();

                }


            }
        });


        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                db.collection("UserType")
                        .whereEqualTo("phonenumber", "05" + edit_phone.getText().toString())
                        .get()
                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                if (task.isSuccessful()) {
                                    for (QueryDocumentSnapshot document : task.getResult()) {
                                        Log.d("TAGg", document.getId() + " => " + document.getData());
                                        String number = document.getString("phonenumber");
                                        Log.d("TAGg", "onComplete: " + number);
                                        Log.d("TAGg", "onComplete: " + document.getString("phonenumber"));

                                        //    IsExisting = false;
                                        edit_phone.setError("the number phone is Existing ");
                                        edit_phone.setText("");

                                    }
                                } else {
                                    Log.d("TAGg", "Error getting documents: ", task.getException());
                                    IsExisting = true;

                                }
                            }
                        });


                if (position == 0) {
                    if (edit_pass.getText().toString().length()<6){
                        edit_pass.setError("You must enter 6 numbers");
                        return;
                    }
                    if (!edit_pass.getText().toString().equals(edit_passconfirm.getText().toString())) {
                        Toast.makeText(SignUp.this, " The password does not match", Toast.LENGTH_SHORT).show();
                        edit_passconfirm.setError(" confirm password is not equals password");
                        return;
                    }
                    if (edit_phone.length() > 8 || edit_phone.length() < 8) {
                        Toast.makeText(SignUp.this, " phone not Valid", Toast.LENGTH_SHORT).show();
                        edit_phone.setError("You must enter 8 numbers");
                        return;
                        //  else  if (edit_email.getText().toString().trim().matches(emailPattern) )
                    }  if (edit_email.getText().toString().isEmpty()
                            && !Patterns.EMAIL_ADDRESS.matcher(edit_email.getText().toString().trim()).matches()
                            || !edit_email.getText().toString().matches(emailPattern)) {
                        //Toast.makeText(getApplicationContext(), " Not valid email address", Toast.LENGTH_SHORT).show();
                        edit_email.setError("Not valid email");
                        return;
                    }  if (TextUtils.isEmpty(Ed_firstname.getText().toString()) ||
                            TextUtils.isEmpty(ed_lastname.getText().toString()) ||
                            TextUtils.isEmpty(edit_phone.getText().toString()) ||
                            TextUtils.isEmpty(edit_pass.getText().toString()) ||
                            TextUtils.isEmpty(edit_passconfirm.getText().toString()) ||
                            TextUtils.isEmpty(edit_email.getText().toString()) ||
                            TextUtils.isEmpty(Street_name.getText().toString()) ||
                            TextUtils.isEmpty(nearest_teacher.getText().toString()) ||
                            TextUtils.isEmpty(home_number.getText().toString())||edit_pass.getText().toString().length()<6) {
                        Toast.makeText(SignUp.this, " Please Enter full data ", Toast.LENGTH_SHORT).show();
                        return;

                    } else if (TextUtils.isEmpty(Ed_firstname.getText().toString()) &&
                            TextUtils.isEmpty(ed_lastname.getText().toString()) &&
                            TextUtils.isEmpty(edit_phone.getText().toString()) &&
                            TextUtils.isEmpty(edit_pass.getText().toString()) &&
                            TextUtils.isEmpty(edit_passconfirm.getText().toString()) &&
                            TextUtils.isEmpty(edit_email.getText().toString()) &&
                            TextUtils.isEmpty(Street_name.getText().toString()) &&
                            TextUtils.isEmpty(nearest_teacher.getText().toString()) &&
                            TextUtils.isEmpty(home_number.getText().toString())) {
                        Ed_firstname.setError("first name is empty");
                        ed_lastname.setError("last name is empty");
                        edit_phone.setError("phone is empty");
                        edit_pass.setError("password is empty");
                        edit_passconfirm.setError("confirm password is empty");
                        Street_name.setError("Street name is empty");
                        nearest_teacher.setError("nearest is empty");
                        home_number.setError("home number is empty");
                        edit_email.setError("email is empty");

                    } else if (spino.getSelectedItem().equals("Select  neighborhood")) {
                        new SweetAlertDialog(SignUp.this)
                                .setTitleText("Sorry, Select your neighborhood ")
                                .show();

                    } else {

                        preferencesHelper.setPREF_User_adreess(Street_name.getText().toString() + "-" + nearest_teacher.getText().toString() + "-" + home_number.getText().toString());
                        preferencesHelper.setPREF_uer_area(spino.getSelectedItem().toString());
                        mAuth.createUserWithEmailAndPassword(edit_email.getText().toString().trim(), edit_pass.getText().toString())
                                .addOnCompleteListener(SignUp.this, new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        if (task.isSuccessful()) {
                                            // Sign in success, update UI with the signed-in user's information
                                            //      Log.d(TAG, "createUserWithEmail:success");
                                            FirebaseUser users = mAuth.getCurrentUser();
                                            preferencesHelper.setPREF_User_adreess(Street_name.getText().toString() + "-" + nearest_teacher.getText().toString() + "-" + home_number.getText().toString());
                                            preferencesHelper.setPREF_uer_area(spino.getSelectedItem().toString());

                                            // find the radiobutton by returned id
//                                            UserType userModel = new UserType
//                                                    (Ed_firstname.getText().toString(),
//                                                            ed_lastname.getText().toString(),
//                                                            edit_email.getText().toString().trim(),
//                                                            "05" + edit_phone.getText().toString().trim(),
//                                                            edit_pass.getText().toString().trim(),
//                                                            edit_passconfirm.getText().toString().trim(),
//                                                            edit_age.getText().toString().trim(),
//                                                            spinner.getSelectedItem().toString(),
//                                                            edit_nationalityid.getText().toString(),
//                                                            selectedText,
//                                                            spino.getSelectedItem().toString(),
//                                                            Street_name.getText().toString(),
//                                                            nearest_teacher.getText().toString(),
//                                                            home_number.getText().toString()
//
//                                                    );

                                            datauser user = new datauser();
                                            user.setFirstname(Ed_firstname.getText().toString());
                                            user.setLastname(ed_lastname.getText().toString());
                                            user.setEmail(edit_email.getText().toString());
                                            user.setPassword(edit_pass.getText().toString());
                                            user.setKey(mAuth.getUid());
                                            user.setTypeuser(selectedText);
                                            user.setCityname(spino.getSelectedItem().toString());
                                            user.setStreet_name(Street_name.getText().toString());
                                            user.setNearest_teacher(nearest_teacher.getText().toString());
                                            user.setHome_number(home_number.getText().toString());
                                            user.setNumberphone(edit_phone.getText().toString());
//                                            UserType userType = new UserType(
//                                                    Ed_firstname.getText().toString(),
//                                                    ed_lastname.getText().toString(),
//                                                    edit_email.getText().toString(),
//                                                    edit_phone.getText().toString(),
//                                                    edit_pass.getText().toString(),
//                                                    edit_passconfirm.getText().toString(),"null",
//                                                    selectedText,
//                                                    spino.getSelectedItem().toString(),
//                                                    Street_name.getText().toString(),
//                                                    nearest_teacher.getText().toString(),
//                                                    home_number.getText().toString(),mAuth.getUid());
//                                            preferencesHelper.setPREF_User_adreess(Street_name.getText().toString() + "-" + nearest_teacher.getText().toString() + "-" + home_number.getText().toString());
//                                            preferencesHelper.setPREF_uer_area(spino.getSelectedItem().toString());
                                            db.collection("user").document(mAuth.getUid())
                                                    .set(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                        @Override
                                                        public void onComplete(@androidx.annotation.NonNull Task<Void> task) {

                                                            Intent start = new Intent(getApplicationContext(), LoginActivity.class);
                                                            startActivity(start);
                                                            finish();
                                                        }
                                                    }).addOnFailureListener(new OnFailureListener() {
                                                        @Override
                                                        public void onFailure(@androidx.annotation.NonNull Exception e) {

                                                        }
                                                    });

                                        } else {
                                            Toast.makeText(
                                                    getApplicationContext(),
                                                    "Registration failed!!"
                                                            + " Please try again later^^" + task.getException(),
                                                    Toast.LENGTH_LONG).show();
                                            Log.d("TAG", "onComplete: " + task.getException());
                                            edit_email.setError("Please enter another email");


                                        }
                                    }

                                });


                    }


                }
                else if (position == 1) {
                    if (edit_pass.getText().toString().length()<6){
                        edit_pass.setError("You must enter 6 numbers");
                        return;
                    }
                    if (!edit_pass.getText().toString().equals(edit_passconfirm.getText().toString())) {
                        Toast.makeText(SignUp.this, " The password does not match", Toast.LENGTH_SHORT).show();
                        edit_pass.setError("password not equals confirm password");
                        edit_passconfirm.setError("confirm password not equals password");
                    } else if (edit_phone.length() > 8 || edit_phone.length() < 8) {
                      Toast.makeText(SignUp.this, " phone not Valid", Toast.LENGTH_SHORT).show();
                        edit_phone.setError("You must enter 8 numbers");

                        //  else  if (edit_email.getText().toString().trim().matches(emailPattern) )
                    } else if (edit_email.getText().toString().isEmpty()
                            && !Patterns.EMAIL_ADDRESS.matcher(edit_email.getText().toString().trim()).matches()
                            || !edit_email.getText().toString().matches(emailPattern)) {
                        //Toast.makeText(getApplicationContext(), " Not valid email address", Toast.LENGTH_SHORT).show();
                        edit_email.setError("Not valid email");
                    } else if (TextUtils.isEmpty(Ed_firstname.getText().toString()) ||
                            TextUtils.isEmpty(ed_lastname.getText().toString()) ||
                            TextUtils.isEmpty(edit_phone.getText().toString()) ||
                            TextUtils.isEmpty(edit_pass.getText().toString()) ||
                            TextUtils.isEmpty(edit_passconfirm.getText().toString()) ||
                            TextUtils.isEmpty(edit_email.getText().toString()) ||
                            TextUtils.isEmpty((edit_nationalityid.getText().toString())) ||
                            TextUtils.isEmpty(edit_age.getText().toString())) {
                        Toast.makeText(SignUp.this, " Please Enter full data ", Toast.LENGTH_SHORT).show();

                    } else if (TextUtils.isEmpty(Ed_firstname.getText().toString()) &&
                            TextUtils.isEmpty(ed_lastname.getText().toString()) &&
                            TextUtils.isEmpty(edit_phone.getText().toString()) &&
                            TextUtils.isEmpty(edit_pass.getText().toString()) &&
                            TextUtils.isEmpty(edit_passconfirm.getText().toString()) &&
                            TextUtils.isEmpty(edit_email.getText().toString()) &&
                            TextUtils.isEmpty(edit_nationalityid.getText().toString()) &&
                            TextUtils.isEmpty(edit_age.getText().toString())) {
                        Ed_firstname.setError("");
                        ed_lastname.setError("");
                        edit_phone.setError("");
                        edit_pass.setError("");
                        edit_passconfirm.setError("");
                        Street_name.setError("");
                        nearest_teacher.setError("");
                        home_number.setError("");
                        edit_email.setError("");
                        edit_nationalityid.setError("");
                        edit_age.setError("");

                    } else if (spinner.getSelectedItem().equals("Select nationality")) {
                        new SweetAlertDialog(SignUp.this)
                                .setTitleText("Sorry, Select your nationality ")
                                .show();
                    } else if (age < 17) {
                        new SweetAlertDialog(SignUp.this)
                                .setTitleText("Sorry, you cannot register")
                                .show();
                    } else {
                        mAuth.createUserWithEmailAndPassword(edit_email.getText().toString().trim(), edit_pass.getText().toString())
                                .addOnCompleteListener(SignUp.this, new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        if (task.isSuccessful()) {
                                            // Sign in success, update UI with the signed-in user's information
                                            //      Log.d(TAG, "createUserWithEmail:success");
                                            FirebaseUser users = mAuth.getCurrentUser();
                                            dataDriver Driver = new dataDriver();
                                            Driver.setFirstname(Ed_firstname.getText().toString());
                                            Driver.setLastname(ed_lastname.getText().toString());
                                            Driver.setEmail(edit_email.getText().toString());
                                            Driver.setKey(mAuth.getUid());
                                            Driver.setPassword(edit_pass.getText().toString());
                                            Driver.setNumberphone(edit_phone.getText().toString());
                                            Driver.setBirthday(edit_age.getText().toString());
                                            Driver.setTypeuser(selectedText);
                                            Driver.setNationality(spinner.getSelectedItem().toString());
                                            Driver.setNationalityId(edit_nationalityid.getText().toString());
//                                            UserType userType = new UserType(
//                                                    Ed_firstname.getText().toString(),
//                                                    ed_lastname.getText().toString(),
//                                                    edit_email.getText().toString(),
//                                                    edit_phone.getText().toString(),mAuth.getUid(),
//                                                    edit_pass.getText().toString(),
//                                                    edit_passconfirm.getText().toString(),
//                                                    edit_age.getText().toString(),
//                                                    spinner.getSelectedItem().toString(),
//                                                    edit_nationalityid.getText().toString(),
//                                                    selectedText);


                                            db.collection("user").document(mAuth.getUid())
                                                    .set(Driver)
                                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                        @Override
                                                        public void onComplete(@androidx.annotation.NonNull Task<Void> task) {

                                                            Intent start = new Intent(getApplicationContext(), LoginActivity.class);
                                                            startActivity(start);
                                                            finish();
                                                        }
                                                    }).addOnFailureListener(new OnFailureListener() {
                                                        @Override
                                                        public void onFailure(@androidx.annotation.NonNull Exception e) {

                                                        }
                                                    });
                                        } else {
                                            Toast.makeText(
                                                    getApplicationContext(),
                                                    "Registration failed!!"
                                                            + " Please try again later^^" + task.getException(),
                                                    Toast.LENGTH_LONG).show();
                                            Log.d("TAG", "onComplete: " + task.getException());
                                            edit_email.setError("Please enter another email");


                                        }
                                    }

                                });
                    }
                }
                else if (position == 2) {
                    //// Owner

                    if (edit_pass.getText().toString().length()<6){
                        edit_pass.setError("You must enter 6 numbers");
                        return;
                    }
                    if (!edit_pass.getText().toString().equals(edit_passconfirm.getText().toString())) {
                        Toast.makeText(SignUp.this, " The password does not match", Toast.LENGTH_SHORT).show();
                        edit_pass.setError("password not equals confirm password");
                        edit_passconfirm.setError("confirm password not equals password");
                    }
                    else if (edit_phone.length() > 8 || edit_phone.length() < 8) {
                        Toast.makeText(SignUp.this, " phone not Valid", Toast.LENGTH_SHORT).show();
                        edit_phone.setError("You must enter 8 numbers");

                        //  else  if (edit_email.getText().toString().trim().matches(emailPattern) )
                    }
                    else if (edit_email.getText().toString().isEmpty()
                            && !Patterns.EMAIL_ADDRESS.matcher(edit_email.getText().toString().trim()).matches()
                            || !edit_email.getText().toString().matches(emailPattern)) {
                        //Toast.makeText(getApplicationContext(), " Not valid email address", Toast.LENGTH_SHORT).show();
                        edit_email.setError("Not valid email");
                    } else if (TextUtils.isEmpty(Ed_firstname.getText().toString()) ||
                            TextUtils.isEmpty(ed_lastname.getText().toString()) ||
                            TextUtils.isEmpty(edit_phone.getText().toString()) ||
                            TextUtils.isEmpty(edit_pass.getText().toString()) ||
                            TextUtils.isEmpty(edit_passconfirm.getText().toString()) ||
                            TextUtils.isEmpty(edit_email.getText().toString())
                    ) {
                        Toast.makeText(SignUp.this, " Please Enter full data ", Toast.LENGTH_SHORT).show();

                    } else if (TextUtils.isEmpty(Ed_firstname.getText().toString()) &&
                            TextUtils.isEmpty(ed_lastname.getText().toString()) &&
                            TextUtils.isEmpty(edit_phone.getText().toString()) &&
                            TextUtils.isEmpty(edit_pass.getText().toString()) &&
                            TextUtils.isEmpty(edit_passconfirm.getText().toString()) &&
                            TextUtils.isEmpty(edit_email.getText().toString())) {
                        Ed_firstname.setError("");
                        ed_lastname.setError("");
                        edit_phone.setError("");
                        edit_pass.setError("");
                        edit_passconfirm.setError("");
                        edit_email.setError("");
                    } else {
                        mAuth.createUserWithEmailAndPassword(edit_email.getText().toString().trim(), edit_pass.getText().toString())
                                .addOnCompleteListener(SignUp.this, new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        if (task.isSuccessful()) {
                                            // Sign in success, update UI with the signed-in user's information
                                            //      Log.d(TAG, "createUserWithEmail:success");
                                            FirebaseUser users = mAuth.getCurrentUser();
                                            dataowner owner = new dataowner();
                                            owner.setFirstname(Ed_firstname.getText().toString());
                                            owner.setLastname(ed_lastname.getText().toString());
                                            owner.setKey(mAuth.getUid());
                                            owner.setEmail(edit_email.getText().toString());
                                            owner.setNumberphone(edit_phone.getText().toString());
                                            owner.setTypeuser(selectedText);
                                            owner.setPassword(edit_pass.getText().toString());

//                                            UserType userType = new UserType(
//                                                    Ed_firstname.getText().toString(),
//                                                    ed_lastname.getText().toString(),
//                                                    edit_email.getText().toString(),
//                                                    edit_phone.getText().toString(),
//                                                    edit_pass.getText().toString(),
//                                                    edit_passconfirm.getText().toString(),
//                                                    selectedText,mAuth.getUid());


                                            db.collection("user").document(mAuth.getUid())
                                                    .set(owner)
                                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                        @Override
                                                        public void onComplete(@androidx.annotation.NonNull Task<Void> task) {

                                                            Intent start = new Intent(getApplicationContext(), LoginActivity.class);
                                                            startActivity(start);
                                                            finish();
                                                        }
                                                    }).addOnFailureListener(new OnFailureListener() {
                                                        @Override
                                                        public void onFailure(@androidx.annotation.NonNull Exception e) {

                                                        }
                                                    });
                                        } else {
                                            Toast.makeText(
                                                    getApplicationContext(),
                                                    "Registration failed!!"
                                                            + " Please try again later^^" + task.getException(),
                                                    Toast.LENGTH_LONG).show();
                                            Log.d("TAG", "onComplete: " + task.getException());
                                            edit_email.setError("Please enter another email");


                                        }
                                    }

                                });


                    }


                }


//
//
//                if (!edit_pass.getText().toString().equals(edit_passconfirm.getText().toString())) {
//                    Toast.makeText(SignUp.this, " The password does not match", Toast.LENGTH_SHORT).show();
//                    edit_pass.setError("");
//                    edit_passconfirm.setError("");
//                } else if (edit_phone.length() > 8 || edit_phone.length() < 8) {
//                    Toast.makeText(SignUp.this, " phone not Valid", Toast.LENGTH_SHORT).show();
//                    edit_phone.setError("You must enter 8 numbers");
//
//                    //  else  if (edit_email.getText().toString().trim().matches(emailPattern) )
//                } else if (edit_email.getText().toString().isEmpty()
//                        && !Patterns.EMAIL_ADDRESS.matcher(edit_email.getText().toString().trim()).matches()
//                        || !edit_email.getText().toString().matches(emailPattern)) {
//                    //Toast.makeText(getApplicationContext(), " Not valid email address", Toast.LENGTH_SHORT).show();
//                    edit_email.setError("Not valid email");
//                } else if (TextUtils.isEmpty(Ed_firstname.getText().toString()) ||
//                        TextUtils.isEmpty(ed_lastname.getText().toString()) ||
//                        TextUtils.isEmpty(edit_phone.getText().toString()) ||
//                        TextUtils.isEmpty(edit_pass.getText().toString()) ||
//                        TextUtils.isEmpty(edit_passconfirm.getText().toString()) ||
//                        TextUtils.isEmpty(edit_email.getText().toString())) {
//                    Toast.makeText(SignUp.this, " Please Enter full data ", Toast.LENGTH_SHORT).show();
//
//                } else if (TextUtils.isEmpty(Ed_firstname.getText().toString()) &&
//                        TextUtils.isEmpty(ed_lastname.getText().toString()) &&
//                        TextUtils.isEmpty(edit_phone.getText().toString()) &&
//                        TextUtils.isEmpty(edit_pass.getText().toString()) &&
//                        TextUtils.isEmpty(edit_passconfirm.getText().toString()) &&
//                        TextUtils.isEmpty(edit_email.getText().toString())) {
//                    Ed_firstname.setError("");
//                    ed_lastname.setError("");
//                    edit_phone.setError("");
//                    edit_pass.setError("");
//                    edit_passconfirm.setError("");
//                    edit_email.setError("");
//                } else if (spinner.getSelectedItem().equals("Select nationality")) {
//                    new SweetAlertDialog(SignUp.this)
//                            .setTitleText("Sorry, Enter your nationality ")
//                            .show();
//                }
////                else if (IsExisting ) {
////
////                   edit_phone.setError(" number is Existing");
////
////
////
////                //    Toast.makeText(SignUp.this, "fffffffffffffff", Toast.LENGTH_SHORT).show();
////                }
//                else if (position == -1) {
//                    new SweetAlertDialog(SignUp.this)
//                            .setTitleText("Sorry, You must choose the type of yours")
//                            .show();
//                } else if (position == 0) {
//                    if (spino.getSelectedItem().equals("Choose the neighborhood")) {
//                        new SweetAlertDialog(SignUp.this)
//                                .setTitleText("Sorry, Enter your neighborhood  ")
//                                .show();
//                    } else if (TextUtils.isEmpty(Street_name.getText().toString()) ||
//                            TextUtils.isEmpty(nearest_teacher.getText().toString()) ||
//                            TextUtils.isEmpty(home_number.getText().toString())) {
//
//                        Street_name.setError("");
//                        nearest_teacher.setError("");
//                        home_number.setError("");
//                        Toast.makeText(SignUp.this, " Please Enter full address ", Toast.LENGTH_SHORT).show();
//
//                    } else if (TextUtils.isEmpty(Street_name.getText().toString()) &&
//                            TextUtils.isEmpty(nearest_teacher.getText().toString()) &&
//                            TextUtils.isEmpty(home_number.getText().toString())) {
//
//                        Street_name.setError("");
//                        nearest_teacher.setError("");
//                        home_number.setError("");
//
//
//
//                }
//                } else if (position == 1) {
//                    if (age <= 18) {
//                        new SweetAlertDialog(SignUp.this)
//                                .setTitleText("Sorry, you cannot register")
//                                .show();
//
//
//                    } else if (edit_age.getText().toString().isEmpty()) {
//                        edit_age.setError(" please enter age ");
//                    } else if (edit_nationalityid.getText().toString().isEmpty()) {
//                        edit_nationalityid.setError("please enter nationality id");
//                    }
//
//                } else if (position == 2) {
//
//                    if (spino.getSelectedItem().equals("Choose the neighborhood")) {
//                        new SweetAlertDialog(SignUp.this)
//                                .setTitleText("Sorry, Enter your neighborhood  ")
//                                .show();
//                }
//
//                } else {
//
//
////
//                    mAuth.createUserWithEmailAndPassword(edit_email.getText().toString().trim(), edit_pass.getText().toString())
//                            .addOnCompleteListener(SignUp.this, new OnCompleteListener<AuthResult>() {
//                                @Override
//                                public void onComplete(@NonNull Task<AuthResult> task) {
//                                    if (task.isSuccessful()) {
//                                        // Sign in success, update UI with the signed-in user's information
//                                        //      Log.d(TAG, "createUserWithEmail:success");
//                                        FirebaseUser users = mAuth.getCurrentUser();
//
//
//                                        // find the radiobutton by returned id
//                                        UserType userModel = new UserType
//                                                (Ed_firstname.getText().toString(),
//                                                        ed_lastname.getText().toString(),
//                                                        edit_email.getText().toString().trim(),
//                                                        "05" + edit_phone.getText().toString().trim(),
//                                                        edit_pass.getText().toString().trim(),
//                                                        edit_passconfirm.getText().toString().trim(),
//                                                        edit_age.getText().toString().trim(),
//                                                        spinner.getSelectedItem().toString(),
//                                                        edit_nationalityid.getText().toString(),
//                                                        selectedText,
//                                                        spino.getSelectedItem().toString(),
//                                                        Street_name.getText().toString(),
//                                                        nearest_teacher.getText().toString(),
//                                                        home_number.getText().toString()
//
//                                                );
//
//
//                                        db.collection("UserType")
//                                                .add(userModel)
//                                                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
//                                                    @Override
//                                                    public void onSuccess(DocumentReference documentReference) {
//                                                        Log.d("TAG", "DocumentSnapshot written with ID: " + documentReference.getId());
//
//                                                        finish();
//                                                        Intent start = new Intent(getApplicationContext(), LoginActivity.class);
//                                                        startActivity(start);
//                                                    }
//                                                })
//                                                .addOnFailureListener(new OnFailureListener() {
//                                                    @Override
//                                                    public void onFailure(@NonNull Exception e) {
//                                                        Log.w("TAG", "Error adding document", e);
//
//
//                                                    }
//                                                });
//                                    } else {
//                                        Toast.makeText(
//                                                getApplicationContext(),
//                                                "Registration failed!!"
//                                                        + " Please try again later^^" + task.getException(),
//                                                Toast.LENGTH_LONG).show();
//                                        Log.d("TAG", "onComplete: " + task.getException());
//                                        edit_email.setError("Please enter another email");
//
//
//                                    }
//                                }
//
//                            });

                // }


            }
        });

//
//        if (bt_User.isChecked()== true) {
//
//            edit_age.setVisibility(View.GONE);
//            edit_nationality.setVisibility(View.GONE);
//
//        } else if (bt_Driver.isChecked()== true) {
//            edit_age.setVisibility(View.VISIBLE);
//            edit_nationality.setVisibility(View.VISIBLE);
//        } else if (bt_Owner.isChecked()== true) {
//            edit_age.setVisibility(View.VISIBLE);
//            edit_nationality.setVisibility(View.VISIBLE);
//
//        }


//
//
//            }
//        });
//
//        bt_Driver.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                bt_Driver.setBackgroundColor(bt_Driver.getContext().getResources().getColor(R.color.app));
//                //  bt_User.setBackgroundColor(bt_User.getContext().getResources().getColor(R.color.white));
//                // bt_Owner.setBackgroundColor(bt_Owner.getContext().getResources().getColor(R.color.white));
//                //  bt_Driver.setBackgroundResource(R.drawable.edittextshap);
//                bt_User.setBackgroundResource(R.drawable.edittextshap);
//                bt_Owner.setBackgroundResource(R.drawable.edittextshap);
//
//

//            }
//        });
//
//
//        bt_Owner.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                bt_Owner.setBackgroundColor(bt_Owner.getContext().getResources().getColor(R.color.app));
//                //  bt_Driver.setBackgroundColor(bt_Driver.getContext().getResources().getColor(R.color.white));
//                //  bt_User.setBackgroundColor(bt_User.getContext().getResources().getColor(R.color.white));

//            }
//        });


    }


    void init() {
        Ed_firstname = findViewById(R.id.firstname);
        ed_lastname = findViewById(R.id.lastname);
        edit_email = findViewById(R.id.edit_email);
        edit_phone = findViewById(R.id.edit_phone);
        edit_age = findViewById(R.id.edit_age);
        //  edit_nationality = findViewById(R.id.edit_nationality);
        spinner = findViewById(R.id.spinner);
        edit_pass = findViewById(R.id.edit_pass);
        edit_passconfirm = findViewById(R.id.edit_passconfirm);
        bt_User = findViewById(R.id.bt_User);
        bt_Driver = findViewById(R.id.bt_Driver);
        bt_Owner = findViewById(R.id.bt_Owner);
        group = findViewById(R.id.radio);
        sign = findViewById(R.id.sign);
        back = findViewById(R.id.back);
        edit_nationalityid = findViewById(R.id.edit_nationalityid);
        spino = findViewById(R.id.spinneruser);
        Street_name = findViewById(R.id.Streetname);
        nearest_teacher = findViewById(R.id.namestree);
        home_number = findViewById(R.id.numberhome);
        frameLayout = findViewById(R.id.framesign);
    }


    private boolean isValidEmailId(String email) {

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }

    private void updateLabel() {
        String myFormat = "MM/dd/yyyy";
        SimpleDateFormat dateFormat = new SimpleDateFormat(myFormat, Locale.US);
        edit_age.setText(dateFormat.format(myCalendar.getTime()));
        age = getPerfectAgeInYears(myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH));
        Log.d("age", "updateLabel: " + getPerfectAgeInYears(myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)));
    }


    public int getPerfectAgeInYears(int year, int month, int date) {
        Calendar dobCalendar = Calendar.getInstance();
        dobCalendar.set(Calendar.YEAR, year);
        dobCalendar.set(Calendar.MONTH, month);
        dobCalendar.set(Calendar.DATE, date);

        int ageInteger = 0;

        Calendar today = Calendar.getInstance();

        ageInteger = today.get(Calendar.YEAR) - dobCalendar.get(Calendar.YEAR);

        if (today.get(Calendar.MONTH) == dobCalendar.get(Calendar.MONTH)) {

            if (today.get(Calendar.DAY_OF_MONTH) < dobCalendar.get(Calendar.DAY_OF_MONTH)) {

                ageInteger = ageInteger - 1;
            }

        } else if (today.get(Calendar.MONTH) < dobCalendar.get(Calendar.MONTH)) {

            ageInteger = ageInteger - 1;

        }

        return ageInteger;

    }
}
