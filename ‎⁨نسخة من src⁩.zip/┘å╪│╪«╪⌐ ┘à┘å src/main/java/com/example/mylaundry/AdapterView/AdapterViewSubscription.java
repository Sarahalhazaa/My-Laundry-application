package com.example.mylaundry.AdapterView;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.R;

import java.util.ArrayList;

public class AdapterViewSubscription extends RecyclerView.Adapter<AdapterViewSubscription.myViewHolder> {

    Activity activity;
    ArrayList<SubscriptionModel> data;


    public AdapterViewSubscription(Activity activity, ArrayList<SubscriptionModel> data) {
        this.activity = activity;
        this.data = data;
    }

    @Override
    public AdapterViewSubscription.myViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(activity).inflate(R.layout.subscriptioncardviewitem, parent, false);
        return new AdapterViewSubscription.myViewHolder(root);
    }

    @Override
    public void onBindViewHolder(AdapterViewSubscription.myViewHolder holder, int position) {

        holder.tv_name.setText(data.get(position).getName());
        holder.tv_number.setText(data.get(position).getCommercial_register_number());
        holder.firstDate.setText(data.get(position).getNowdate());
        holder.lastDate.setText(data.get(position).getEndDate());
        holder.period.setText(data.get(position).getDuration());
        holder.number.setText(data.get(position).getNumberSubscr());
        holder.streetname.setText(data.get(position).getStreet());
        holder.diration.setText(data.get(position).getArea());



    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {

        TextView tv_name, tv_number, firstDate, lastDate ,period , number,streetname,diration;


        public myViewHolder(View itemView) {
            super(itemView);
            tv_name = itemView.findViewById(R.id.textNAME);
            tv_number = itemView.findViewById(R.id.NAMEDATE);
            firstDate = itemView.findViewById(R.id.firstdate);
            lastDate = itemView.findViewById(R.id.lastdate);
            period =itemView.findViewById(R.id.period);
            number =itemView.findViewById(R.id.Subscription_number);
            streetname=itemView.findViewById(R.id.dataStreetname);
            diration=itemView.findViewById(R.id.dataDircthion);


        }
    }
}


