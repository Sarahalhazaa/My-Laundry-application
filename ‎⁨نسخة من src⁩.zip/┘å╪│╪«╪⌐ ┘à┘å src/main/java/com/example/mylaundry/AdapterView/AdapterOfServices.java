package com.example.mylaundry.AdapterView;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.onClickadd;
import com.example.mylaundry.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;

public class AdapterOfServices extends RecyclerView.Adapter<AdapterOfServices.myViewHolder> {

    onClickadd clickadd ;
    ArrayList<Services> data;
    PreferencesHelper preferencesHelper;
    FirebaseFirestore db;


    public void update(ArrayList<Services> newList) {
        data = newList;
        notifyDataSetChanged();
    }

    public AdapterOfServices( ArrayList<Services> data ,onClickadd clickadd) {

        this.data = data;
        this.clickadd=clickadd;
//        preferencesHelper = new PreferencesHelper(activity);
        db = FirebaseFirestore.getInstance();
    }

    @Override
    public AdapterOfServices.myViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(parent.getContext()).inflate(R.layout.itemowner, parent, false);
        return new AdapterOfServices.myViewHolder(root);

    }

    @Override
    public void onBindViewHolder(AdapterOfServices.myViewHolder holder, int position) {
//        Services model = data.get(position);
//        holder.onBind(model);


        holder.name.setText("Name Service \n \n"+data.get(position).getItemsservies().get(0).getName_servies());
        holder.price.setText("Price \n \n"+data.get(position).getItemsservies().get(0).getPrice());
        holder.type.setText("Type Service \n \n"+data.get(position).getNameService());
        holder.textviews.setText("Name Laundry  : \t "+data.get(position).getNameLaundry());
        holder.numofday.setText(" Days \n \n "+data.get(position).getNumberOfday());

        holder.del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                db.collection("Services").document(data.get(position).getDocumentId()).
                        delete().
                        addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                // inside on complete method we are checking
                                // if the task is success or not.
                                if (task.isSuccessful()) {
                                    // this method is called when the task is success
                                    // after deleting we are starting our MainActivity.
                                    holder.itemView.setVisibility(View.GONE);
                                    Toast.makeText(holder.itemView.getContext(), " has been deleted from Database.", Toast.LENGTH_SHORT).show();
//                                    Intent i = new Intent(UpdateCourse.this, MainActivity.class);
//                                    startActivity(i);
                                } else {
                                    // if the delete operation is failed
                                    // we are displaying a toast message.
                                    Toast.makeText(holder.itemView.getContext(), "Fail to delete the course. ", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });


            }
        });
        holder.add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               clickadd.onclickadd(data.get(position).getKeysub(),data.get(position).getNameLaundry(),data.get(position).getEmail());
            }
        });

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {

        TextView price, name, type,textviews,numofday;
        Button add;
        ImageView del;

        public myViewHolder(View itemView) {
            super(itemView);
            price = itemView.findViewById(R.id.Service_price);
            name = itemView.findViewById(R.id.Servicename);
            type = itemView.findViewById(R.id.servicetype);
            add = itemView.findViewById(R.id.button14);
            del = itemView.findViewById(R.id.imageView12);
            textviews=itemView.findViewById(R.id.textviews);
            numofday=itemView.findViewById(R.id.numofday);

        }

        private void onBind(Services model) {
            // name.setText(model.getItemsservies().get(getAdapterPosition()).getServies());
        }
    }
}
