package com.example.mylaundry.AdapterView;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.Model.ItemServies;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.R;

import java.util.ArrayList;

public class AdapterItem extends RecyclerView.Adapter<AdapterItem.myViewHolder> {

    Activity activity;
    ArrayList<ItemServies> data;

    public AdapterItem(Activity activity, ArrayList<ItemServies> data) {
        this.activity = activity;
        this.data = data;
    }


    @Override
    public AdapterItem.myViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(activity).inflate(R.layout.itemservices, parent, false);
        return new AdapterItem.myViewHolder(root);
    }

    @Override
    public void onBindViewHolder(AdapterItem.myViewHolder holder, int position) {
        holder.tv_name.setText(data.get(position).getPrice());
        holder.tv_namerservicer.setText(data.get(position).getServies());
        holder.tv_number.setText(data.get(position).getName());
        holder.numbers.setText(data.get(position).getType_servies());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {
        TextView tv_name, tv_number, tv_namerservicer,numbers;

        public myViewHolder(View itemView) {
            super(itemView);
            tv_name = itemView.findViewById(R.id.number);
            tv_number = itemView.findViewById(R.id.type);
            tv_namerservicer = itemView.findViewById(R.id.textname);
            numbers=itemView.findViewById(R.id.numbers);
        }
    }
}
