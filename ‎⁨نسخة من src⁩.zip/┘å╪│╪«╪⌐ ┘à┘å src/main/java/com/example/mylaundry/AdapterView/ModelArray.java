package com.example.mylaundry.AdapterView;


import com.example.mylaundry.Model.Services;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;

import java.io.Serializable;
import java.util.ArrayList;

public class ModelArray implements Serializable {

    ArrayList<Services> Data;


    ArrayList<Services> ArrayData;

    ArrayList<SubscriptionModel> subscriptionModelsArray;

    ArrayList<Services> order;

    ArrayList<Services> orderdel;


    ArrayList<Services> OrderData;


    public ArrayList<Services> getOrderData() {
        return OrderData;
    }

    public void setOrderData(ArrayList<Services> orderData) {
        OrderData = orderData;
    }

    public ArrayList<Services> getOrderdel() {
        return orderdel;
    }

    public void setOrderdel(ArrayList<Services> orderdel) {
        this.orderdel = orderdel;
    }

    public ArrayList<Services> getOrder() {
        return order;
    }

    public void setOrder(ArrayList<Services> order) {
        this.order = order;
    }

    public ModelArray() {
    }

    public ArrayList<SubscriptionModel> getSubscriptionModelsArray() {
        return subscriptionModelsArray;
    }

    public void setSubscriptionModelsArray(ArrayList<SubscriptionModel> subscriptionModelsArray) {
        this.subscriptionModelsArray = subscriptionModelsArray;
    }

    public ArrayList<Services> getArrayData() {
        return ArrayData;
    }

    public void setArrayData(ArrayList<Services> arrayData) {
        ArrayData = arrayData;
    }

    ModelArray(ArrayList<Services> data) {
        Data = data;
    }

    public ArrayList<Services> getData() {
        return Data;
    }

    public void setData(ArrayList<Services> data) {
        Data = data;
    }
}
