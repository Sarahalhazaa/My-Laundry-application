package com.example.mylaundry.AdapterView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.AcivitysOfLaundry.OrderConfirmation;
import com.example.mylaundry.Model.ItemServies;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.myViewHolder> {

    Activity activity;
    // ArrayList<ItemServies> ArrayData;
    ArrayList<Services> ArrayData;
    FirebaseFirestore db;

    String pricesp;
    PreferencesHelper preferencesHelper;

    int minteger =1;
    int count = 0;
    float totAmount = 0.0F;
    String text;

    public RecyclerViewAdapter(Activity activity, ArrayList<Services> arrayData) {
        this.activity = activity;
        ArrayData = arrayData;
        preferencesHelper = new PreferencesHelper(activity);
        db = FirebaseFirestore.getInstance();
    }

    @Override
    public RecyclerViewAdapter.myViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(activity).inflate(R.layout.item_product_basket, parent, false);
        return new RecyclerViewAdapter.myViewHolder(root);

    }

    @Override
    public void onBindViewHolder(myViewHolder holder, @SuppressLint("RecyclerView") int position) {

        // ItemServies model = ArrayData.get(position);

        if (position == getItemCount() - 1) {
            holder.continuation.setVisibility(View.VISIBLE);
        } else {
            holder.continuation.setVisibility(View.GONE);

        }


        Services model = ArrayData.get(position);


        // holder.onBind(model);

//        ArrayList<String> spinnerData = new ArrayList<>();
//        spinnerData.add(model.getItemsservies());

        ArrayList<String> spinnerData = new ArrayList<>();
        for (ItemServies service : model.getItemsservies()) {
            spinnerData.add(service.getServies());
        }

        ArrayAdapter<String> ad = new ArrayAdapter<>(activity, android.R.layout.simple_spinner_item, spinnerData);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        holder.spino.setAdapter(ad);
        holder.spino.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int mPosition, long id) {
                model.setSelectedPrice(model.getItemsservies().get(mPosition).getPrice());

                holder.price.setText(model.getItemsservies().get(mPosition).getPrice());
                pricesp = model.getItemsservies().get(mPosition).getPrice();
                text= holder.spino.getSelectedItem().toString();
                //Toast.makeText(activity, ""+text, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        holder.nameservies.setText(ArrayData.get(position).getEidtetxt());
        holder.namelaundry.setText(ArrayData.get(position).getNameLaundry());
        holder.price.setText(model.getSelectedPrice());
//        minteger=Integer.parseInt(ArrayData.get(position).getTotal());
//        holder.pricetext.setText("" + minteger);


        holder.increase.setOnClickListener(v1 -> {
            minteger = minteger + 1;
            holder.pricetext.setText("" + minteger);
            count = minteger * Integer.parseInt(holder.price.getText().toString());
            Log.d("TAG", "onBindViewHolder: " + count);
            holder.total.setText("" + count);
            model.setTotal(count + "");
            model.setNumberofService(minteger + "");
            ArrayData.get(position).setNumberofService(minteger + "");
        });

        holder.decrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                minteger = minteger - 1;
                holder.pricetext.setText("" + minteger);
                count = minteger * Integer.parseInt(holder.price.getText().toString());
                Log.d("TAG", "onBindViewHolder: " + count);
                holder.total.setText("" + count);
                model.setTotal(count + "");
                model.setNumberofService(minteger + "");
                ArrayData.get(position).setNumberofService(minteger + "");
//                for (Services s :ArrayData){
//                    Log.d("jj", "onBindViewHolder:position " + position);
//                    Log.d("jj", "onBindViewHolder: " + model.getNumberofService());
//                    Log.d("jj", "onBindViewHolder: " + model.getSelectedPrice());
            }
          //  }
        });

        model.setTotal(holder.total.getText().toString());
      //  model.setNumberofService(minteger - 1 + "");
//        model.setSelectedPrice(holder.spino.getSelectedItem().toString());
//        ArrayData.get(position).setSelectedPrice(holder.spino.getSelectedItem().toString());
      //  ArrayData.get(position).setNumberofService(minteger - 1 + "");

        ArrayData.get(position).setTotal(holder.total.getText().toString());

        Log.d("int", "onBindViewHolder: " + model.getTotal());

        model.setTotal(holder.total.getText().toString());

        model.setPricetext(holder.pricetext.getText().toString());


        holder.dayofnumber.setText("Number of day : " + model.getNumberOfday());


        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.itemView.setVisibility(View.GONE);
                Toast.makeText(activity, " Done", Toast.LENGTH_SHORT).show();
                //preferencesHelper.getPREF_Item_Delete();

                db.collection("Basket").document(preferencesHelper.getPREF_Item_Delete()).
                        delete().
                        addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                // inside on complete method we are checking
                                // if the task is success or not.
                                if (task.isSuccessful()) {
                                    // this method is called when the task is success
                                    // after deleting we are starting our MainActivity.
                                    Toast.makeText(activity, " has been deleted from Database.", Toast.LENGTH_SHORT).show();
//                                    Intent i = new Intent(UpdateCourse.this, MainActivity.class);
//                                    startActivity(i);
                                } else {
                                    // if the delete operation is failed
                                    // we are displaying a toast message.
                                    Toast.makeText(activity, "Fail to delete the course. ", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });


            }
        });

        // holder.total.setText("" + total);


        holder.continuation.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {

                Log.d("ServicesOrder", "onCreate:11 " + ArrayData);


                Intent sent = new Intent(activity, OrderConfirmation.class);
                ModelArray modelArray = new ModelArray();
                modelArray.setData(ArrayData);
                model.setTotal(count + "");
                int total = 0;
                for (Services u : ArrayData) {
                    if (u.getTotal().trim().isEmpty() || u.getTotal().trim().equals("0")) {
                        u.setTotal(u.getSelectedPrice());
                    }
                    total += (Integer.parseInt(u.getTotal()));
                }

                sent.putExtra("model", modelArray);

                sent.putExtra("total", total);

                sent.putExtra("email", model.getEmail());
                sent.putExtra("minteger",minteger);
                sent.putExtra("textser",text);
                sent.putExtra("keysub",model.getDocumentId());
                sent.putExtra("keyowner",model.getKeysub());
                Toast.makeText(activity, ""+model.getDocumentId(), Toast.LENGTH_SHORT).show();

                Log.d("email", "onClick: " + model.getEmail());
                activity.startActivity(sent);

            }
        });


    }

    @Override
    public int getItemCount() {
        return ArrayData.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {

        //  ItemProductBasketBinding binding;
        TextView price, nameservies, pricetext, tvname, namelaundry, dayofnumber;

        Button increase, decrease, continuation;

        TextView delete, nameserv, total;


        View view;

        Spinner spino;

        public myViewHolder(View itemView) {
            super(itemView);
            //  binding = ItemProductBasketBinding.bind(itemView);

            spino = itemView.findViewById(R.id.spinner);
            nameservies = itemView.findViewById(R.id.serviceName);
            price = itemView.findViewById(R.id.tv_price);
            increase = itemView.findViewById(R.id.increase);
            decrease = itemView.findViewById(R.id.decrease);
            pricetext = itemView.findViewById(R.id.number_laundry);
            tvname = itemView.findViewById(R.id.textView30);
            view = itemView.findViewById(R.id.view);
            continuation = itemView.findViewById(R.id.Continuation);
            namelaundry = itemView.findViewById(R.id.textView43);
            delete = itemView.findViewById(R.id.textView46);
            total = itemView.findViewById(R.id.total);
            dayofnumber = itemView.findViewById(R.id.dayofnumber);
        }


    }
}
