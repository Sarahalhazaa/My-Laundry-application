package com.example.mylaundry.AdapterView;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.Model.ItemServies;
import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.R;

import java.util.ArrayList;

public class AdapterOrder extends RecyclerView.Adapter<AdapterOrder.myViewHolder>{

    Activity activity;
    ArrayList<Services> data;


    public AdapterOrder(Activity activity, ArrayList<Services> data) {
        this.activity = activity;
        this.data = data;
    }

    @Override
    public AdapterOrder.myViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(activity).inflate(R.layout.itemservices, parent, false);
        return new AdapterOrder.myViewHolder(root);
    }

    @Override
    public void onBindViewHolder(AdapterOrder.myViewHolder holder, int position) {


        holder.tv_name.setText(data.get(position).getEidtetxt());

        holder.tv_number.setText(" 5"+data.get(position).getNumberofService());

        holder.tv_price.setText(data.get(position).getPricetext() + "SR");
    }

    @Override
    public int getItemCount() {
        return data.size();
        // data == null ? 0 :
    }

    public class myViewHolder extends RecyclerView.ViewHolder {

        TextView tv_name, tv_number, tv_price;

        public myViewHolder(View itemView) {
            super(itemView);
            tv_name = itemView.findViewById(R.id.textname);
            tv_number = itemView.findViewById(R.id.number);
            tv_price = itemView.findViewById(R.id.type);


        }

    }
}
