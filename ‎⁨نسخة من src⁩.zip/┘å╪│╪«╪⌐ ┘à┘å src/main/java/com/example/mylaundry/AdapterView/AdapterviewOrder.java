package com.example.mylaundry.AdapterView;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.AcivitysMainFragment.Details_Order;
import com.example.mylaundry.Model.BasketServices;
import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.R;

import java.util.ArrayList;

public class AdapterviewOrder extends RecyclerView.Adapter<AdapterviewOrder.myViewHolder> {

    Activity activity;
    ArrayList<RequestModel> data;

    public void update(ArrayList<RequestModel> newList) {
        data = newList;
        notifyDataSetChanged();
    }

    public AdapterviewOrder(Activity activity, ArrayList<RequestModel> data) {
        this.activity = activity;
        this.data = data;
    }


    @Override
    public AdapterviewOrder.myViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(activity).inflate(R.layout.itemdel, parent, false);
        return new AdapterviewOrder.myViewHolder(root);
    }

    @Override
    public void onBindViewHolder(AdapterviewOrder.myViewHolder holder, int position) {

        RequestModel model = data.get(position);

        holder.tv_name.setText(model.getNamelaundry());
        holder.type.setText(model.getType());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(activity, Details_Order.class);

                intent.putExtra("namela", model.getNamelaundry());

                intent.putExtra("address", model.getAddress());
                intent.putExtra("addtax", model.getAddtax());
                intent.putExtra("amount", model.getAmount());
                intent.putExtra("date", model.getDate());
                intent.putExtra("total", model.getTotal());
                intent.putExtra("number", model.getNumberRequest());

                ModelArray modelArray = new ModelArray();
                modelArray.setOrderdel(model.getData());

                intent.putExtra("getdata", modelArray);

                activity.startActivity(intent);


            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {
        TextView tv_name, type;

        public myViewHolder(View itemView) {
            super(itemView);
            tv_name = itemView.findViewById(R.id.textname);
            type = itemView.findViewById(R.id.stut);

        }
    }
}
