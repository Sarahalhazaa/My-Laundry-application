package com.example.mylaundry.AdapterView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.AcivitysOfLaundry.DetailsLaundry;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.ServiesInt;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.ServicesActivity;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.R;

import java.util.ArrayList;

public class AdapterServices extends RecyclerView.Adapter<AdapterServices.myViewHolder> {
    Activity activity;
    ArrayList<SubscriptionModel> data;
    ServiesInt callback;
    PreferencesHelper preferencesHelper;




    public AdapterServices(Activity activity, ArrayList<SubscriptionModel> data) {
        this.activity = activity;
        this.data = data;
     //   preferencesHelper =new PreferencesHelper(activity);
    }

    public void filterList(ArrayList<SubscriptionModel> filterlist) {

        data = filterlist;

        notifyDataSetChanged();
    }

    @Override
    public AdapterServices.myViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(activity).inflate(R.layout.laundryitem, parent, false);
        return new AdapterServices.myViewHolder(root);
    }

    @Override
    public void onBindViewHolder(AdapterServices.myViewHolder holder, @SuppressLint("RecyclerView") int position) {

//
        holder.tv_name.setText(data.get(position).getName());
        holder.type.setText(data.get(position).getStatus()+"");
        holder.val.setText(data.get(position).getEvaluation() + "/5");

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(activity, DetailsLaundry.class);
                String name = data.get(position).getName();
                String email = data.get(position).getEmail();
                String evaluation = data.get(position).getEvaluation();
                intent.putExtra("name", name);

            //    intent.putExtra("email",email);
                Toast.makeText(activity, ""+data.get(position).getDocumentId(), Toast.LENGTH_SHORT).show();
                intent.putExtra("evaluation", evaluation);
                intent.putExtra("keysub",data.get(position).getDocumentId());
                intent.putExtra("keyowner",data.get(position).getKey());
                activity.startActivity(intent);
            }
        });


    }


    @Override
    public int getItemCount() {
        return data.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {

        TextView tv_name , val,type;



        public myViewHolder(View itemView) {
            super(itemView);
            tv_name = itemView.findViewById(R.id.textname);
            val=itemView.findViewById(R.id.val);
            type=itemView.findViewById(R.id.typeopen);
        }
    }
}


//                String type = data.get(serviceSeletes).getServices().get(0).getItemsservies().
//                        get(KAREEM).getName();
//                Subscribtion x = data.get(index(;
