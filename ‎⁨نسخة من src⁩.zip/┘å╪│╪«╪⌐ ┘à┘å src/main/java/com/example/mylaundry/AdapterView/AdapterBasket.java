package com.example.mylaundry.AdapterView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.Model.BasketServices;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.R;
import com.google.firebase.firestore.FirebaseFirestore;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;

@SuppressLint("NotifyDataSetChanged")
public class AdapterBasket extends RecyclerView.Adapter<AdapterBasket.myViewHolder> {
    Activity activity;
    ArrayList<BasketServices> data;
    FirebaseFirestore db;
    RecyclerViewAdapter recyclerViewAdapter;

    PreferencesHelper preferencesHelper;

    public void update(ArrayList<BasketServices> newList) {
        data = newList;
        notifyDataSetChanged();
    }


    public AdapterBasket(Activity activity, ArrayList<BasketServices> data) {
        this.activity = activity;
        this.data = data;
        preferencesHelper = new PreferencesHelper(activity);
        db = FirebaseFirestore.getInstance();
    }

    @Override
    public AdapterBasket.myViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(activity).inflate(R.layout.item_basket, parent, false);
        return new myViewHolder(root);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterBasket.myViewHolder holder, int position) {
        BasketServices model = data.get(position);
        holder.onBind(model);



    }

    @Override
    public int getItemCount() {
        return data == null ? 0 : data.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {
        TextView nameLaundry;
        Button continuation;
        RecyclerView recyclerView;
        BasketServices model;
        public myViewHolder(View itemView) {
            super(itemView);
            recyclerView = itemView.findViewById(R.id.recyclerView);
            continuation = itemView.findViewById(R.id.button15);
            nameLaundry = itemView.findViewById(R.id.nameLaundry);
        }

        private void onBind(BasketServices model) {
            this.model = model;

            RecyclerViewAdapter recyclerViewAdapter = new
                    RecyclerViewAdapter(activity, model.getServices());

            recyclerView.setHasFixedSize(true);

            recyclerView.setAdapter(recyclerViewAdapter);

            nameLaundry.setText(model.getNameLaundry());

        }
    }
}
