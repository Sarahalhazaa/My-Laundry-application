package com.example.mylaundry.AdapterView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.AcivitysOfLaundry.OrderConfirmation;
import com.example.mylaundry.Model.ItemServies;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.Model.ServiesInt;
import com.example.mylaundry.R;
import com.google.android.gms.tasks.OnCompleteListener;

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public class OrderAdapterCon extends RecyclerView.Adapter<OrderAdapterCon.myViewHolder> {
    ArrayList<Services> data;
    ArrayList<Services> data2;
    ArrayAdapter ad;
    Activity activity;
    String pricesp;
    PreferencesHelper preferencesHelper;
    ServiesInt serviesInt;
    int minteger ;
    int count = 0;
    int number;
    String namela;

    ModelArray modelArray;
    String text;

    public ModelArray getModelArray() {
        return modelArray;
    }

    public void setModelArray(ModelArray modelArray) {
        this.modelArray = modelArray;
    }

    public OrderAdapterCon(Activity activity, ArrayList<Services> data,int minteger,String text) {
        this.activity = activity;
        this.data = data;
        preferencesHelper = new PreferencesHelper(activity);
        this.serviesInt = (ServiesInt) activity;
        this.minteger=minteger;
        this.text=text;
    }

    @Override
    public OrderAdapterCon.myViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(activity).inflate(R.layout.item, parent, false);
        return new OrderAdapterCon.myViewHolder(root);
    }

    @Override
    public void onBindViewHolder(OrderAdapterCon.myViewHolder holder, @SuppressLint("RecyclerView") int position) {

        Services model = data.get(position);
        holder.price.setText(model.getSelectedPrice());
        Toast.makeText(activity, "total"+minteger, Toast.LENGTH_SHORT).show();
        holder.pricetext.setText("" + minteger);
        count = minteger * Integer.parseInt(holder.price.getText().toString());
        holder.total.setText("" + count);
        data2 = new ArrayList<>();

//        holder.pricetext.setText(model.getSelectedPrice());
//        holder.pricetext.setText(model.getNumberOfday());

        ArrayList<String> spinnerData = new ArrayList<>();
        spinnerData.add(text);
        for (ItemServies service : model.getItemsservies()) {
            spinnerData.add(service.getServies());
        }

        ad = new ArrayAdapter(activity, android.R.layout.simple_spinner_item, spinnerData);//        holder.inputLayout.setAdapter(adapter);
        ad.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        holder.spino.setAdapter(ad);
        holder.spino.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int mPosition, long id) {

                //Toast.makeText(activity, spinnerData.get(mPosition), Toast.LENGTH_LONG).show();
                model.setSelectedPrice(model.getItemsservies().get(mPosition).getPrice());

                data.get(position).setSelectedPrice(model.getItemsservies().get(mPosition).getPrice());

                holder.price.setText(model.getItemsservies().get(mPosition).getPrice());

                pricesp = model.getItemsservies().get(mPosition).getPrice();

                model.setSelectedPrice(model.getItemsservies().get(mPosition).getPrice());

                data.get(position).setSelectedPrice(model.getItemsservies().get(mPosition).getPrice());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });


        holder.nameservies.setText(data.get(position).getEidtetxt());

        model.setNameLaundry(data.get(position).getNameLaundry());
       // data2.set(position).setNameLaundry(data.get(position).getNameLaundry());



//        holder.pricetext.setText(model.getPricetext());

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.itemView.setVisibility(View.GONE);
                Toast.makeText(activity, " Done", Toast.LENGTH_SHORT).show();
                preferencesHelper.getPREF_Item_Delete();

//                db.collection("Basket").document(preferencesHelper.getPREF_Item_Delete()).
//                        delete().
//                        addOnCompleteListener(new OnCompleteListener<Void>() {
//                            @Override
//                            public void onComplete(@NonNull Task<Void> task) {
//                                // inside on complete method we are checking
//                                // if the task is success or not.
//                                if (task.isSuccessful()) {
//                                    // this method is called when the task is success
//                                    // after deleting we are starting our MainActivity.
//                                    Toast.makeText(activity, " has been deleted from Database.", Toast.LENGTH_SHORT).show();
////                                    Intent i = new Intent(UpdateCourse.this, MainActivity.class);
////                                    startActivity(i);
//                                } else {
//                                    // if the delete operation is failed
//                                    // we are displaying a toast message.
//                                    Toast.makeText(activity, "Fail to delete the course. ", Toast.LENGTH_SHORT).show();
//                                }
//                            }
//                        });


            }
        });


        holder.day.setText("Number of day" + data.get(position).getNumberOfday());


        holder.increase.setOnClickListener(v1 -> {
            minteger = minteger + 1;
            holder.pricetext.setText("" + minteger);
            count = minteger * Integer.parseInt(holder.price.getText().toString());
            Log.d("TAG", "onBindViewHolder: " + count);
            holder.total.setText("" + count);
            model.setTotal(count + "");
            serviesInt.callbackCall(count);
            model.setNumberofService(minteger + "");
            data.get(position).setNumberofService(minteger + "");
//            Log.d("jj", "onBindViewHolder:position " + position);
//            Log.d("jj", "onBindViewHolder: " + model.getNumberofService());
//            Log.d("jj", "onBindViewHolder: " + model.getSelectedPrice());
        });

        holder.decrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                minteger = minteger - 1;
                holder.pricetext.setText("" + minteger);
                count = minteger * Integer.parseInt(holder.price.getText().toString());
                holder.total.setText("" + count);
                model.setTotal(count + "");
                serviesInt.callbackCall(count);
                Toast.makeText(activity, "" + count, Toast.LENGTH_SHORT).show();
                model.setNumberofService(minteger + "");
                data.get(position).setNumberofService(minteger + "");
            }
        });

        int total = 0;
        for (Services u : data) {
            if (u.getTotal().trim().isEmpty() || u.getTotal().trim().equals("0")) {
                u.setTotal(u.getSelectedPrice());
            }
            total += (Integer.parseInt(u.getTotal()));
            serviesInt.callbackCall(total);
        }
        model.setTotal(holder.total.getText().toString());

        data.get(position).setTotal(holder.total.getText().toString());

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.itemView.setVisibility(View.GONE);
            }
        });

        namela=model.getNameLaundry();
        Log.d("TAG", "onBindViewHolder: " + namela);
        serviesInt.namelay(model.getNameLaundry());

    }

    @Override
    public int getItemCount() {
        return data.size();
    }


    public class myViewHolder extends RecyclerView.ViewHolder {

        TextView price, nameservies, pricetext, tvname, namelaundry, day;

        Button increase, decrease;

        TextView delete, nameserv, total;


        View view;

        Spinner spino;

        public myViewHolder(View itemView) {
            super(itemView);


            spino = itemView.findViewById(R.id.spinner);
            nameservies = itemView.findViewById(R.id.nameserv);
            price = itemView.findViewById(R.id.tv_price);
            increase = itemView.findViewById(R.id.increase);
            decrease = itemView.findViewById(R.id.decrease);
            pricetext = itemView.findViewById(R.id.number_laundry);
            tvname = itemView.findViewById(R.id.textView30);
            view = itemView.findViewById(R.id.view);
            namelaundry = itemView.findViewById(R.id.textView43);
            delete = itemView.findViewById(R.id.textView46);
            total = itemView.findViewById(R.id.total);
            day = itemView.findViewById(R.id.textView53);
        }
    }


   public void AddData(){
       modelArray = new ModelArray();

       for (Services s : data) {
           data2.add(new Services(s.getEidtetxt(),
                   s.getSelectedPrice(),
                   s.getNumberofService(), s.getNameLaundry() ));

           modelArray.setOrder(data2);
       } }


   public void getnamelaundry(String name){
       namela= name  ;
   }

}
