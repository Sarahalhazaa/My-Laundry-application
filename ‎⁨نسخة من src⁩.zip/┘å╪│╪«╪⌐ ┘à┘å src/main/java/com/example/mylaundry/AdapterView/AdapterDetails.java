package com.example.mylaundry.AdapterView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.MainActivity;
import com.example.mylaundry.Model.ItemServies;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.Model.user.BosketUser;
import com.example.mylaundry.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AdapterDetails extends RecyclerView.Adapter<AdapterDetails.myViewHolder> {


    Activity activity;
    //ArrayList<SubscriptionModel> data;
    ArrayList<ItemServies> arrayList;


    int minteger = 1;
    String pricesp;
    ArrayList<Services> data;

    ArrayAdapter ad;
    FirebaseFirestore db;
    PreferencesHelper preferencesHelper;
   String  keyowner,keyuser,keysub;

    public AdapterDetails(Activity activity, ArrayList<Services> data,String keyowner,String keyuser,String keysub) {
        this.activity = activity;
        this.data = data;
        db = FirebaseFirestore.getInstance();
        this.keyowner=keyowner;
        this.keysub=keysub;
        this.keyuser=keyuser;


    }

    @Override
    public AdapterDetails.myViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View root = LayoutInflater.from(activity).inflate(R.layout.itemdetails, parent, false);
        return new AdapterDetails.myViewHolder(root);

    }

    @Override
    public void onBindViewHolder(AdapterDetails.myViewHolder holder, @SuppressLint("RecyclerView") int position) {
        preferencesHelper = new PreferencesHelper(activity);
        Services model = data.get(position);
        ArrayList<String> spinnerData = new ArrayList<>();

        for (ItemServies service : model.getItemsservies()) {
            spinnerData.add(service.getServies());
        }
//
        ad = new ArrayAdapter(activity, android.R.layout.simple_spinner_item, spinnerData);//        holder.inputLayout.setAdapter(adapter);
        ad.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        holder.spino.setAdapter(ad);
        holder.spino.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int mPosition, long id) {

                //Toast.makeText(activity, spinnerData.get(mPosition), Toast.LENGTH_LONG).show();
                model.setSelectedPrice(
                        model.getItemsservies().get(mPosition).getPrice());

                holder.price.setText(model.getItemsservies().get(mPosition).getPrice());
                pricesp = model.getItemsservies().get(mPosition).getPrice();

                // Log.d("TAG", "onItemSelected: " + model.getPrice());

            }

//

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });


        holder.nameservies.setText(data.get(position).getEidtetxt());

        holder.price.setText(model.getSelectedPrice());

        holder.numberOfday.setText("Day of services: " + data.get(position).getNumberOfday());


        holder.increase.setOnClickListener(v1 -> {
            minteger = minteger + 1;
            holder.pricetext.setText("" + minteger);
        });
        holder.decrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                minteger = minteger - 1;
                holder.pricetext.setText("" + minteger);
            }
        });

//       // if(!holder.pricetext.getText().toString() .isEmpty()){
//            int i = Integer.parseInt(holder.price.getText().toString()) ;
//            int j =Integer.parseInt(holder.pricetext.getText().toString());
//            Log.d("ttt", "onBindViewHolder: " + i + "" + j);
//
//            holder.total.setText("Total " + i );
        //  } else {
        //  holder.total.setText("Total " + 1 );
        //  }


        holder.add.setOnClickListener(new View.OnClickListener() {  ////////    فحص المنتج ان كان موجود ولا لا
            @Override
            public void onClick(View v) {

                Toast.makeText(activity, " Done add in basket :) ", Toast.LENGTH_SHORT).show();

//                RequestModel requestModel = new RequestModel(
//                        data.get(position).getNameLaundry(),
//                        data.get(position).getEidtetxt(),
//                        holder.spino.getItemAtPosition(position).toString(),
//                        data.get(position).getSelectedPrice(),
//                        holder.pricetext.getText().toString(), " ", "waite");

//                BosketUser bosketUser=new BosketUser();
//                bosketUser.setDocumentId();
                Services services = new Services(
                        data.get(position).getNameService(),
                        data.get(position).getNameLaundry(),
                        data.get(position).getEmail(),
                        data.get(position).getItemsservies(),
                        data.get(position).getEidtetxt(),
                        data.get(position).getPricetext(),
                        data.get(position).getNumberOfday(),
                        preferencesHelper.getPREF_User_Email(),
                        minteger+"");
                    services.setDocumentId(keysub);
                    services.setKeysub(keyowner);
                    services.setKeyuser(keyuser);


                Toast.makeText(activity, " "+data.get(position).getDocumentId(), Toast.LENGTH_SHORT).show();

                db.collection("Basket")
                        .add(services)
                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                Map<String, Object> Basket = new HashMap<>();
                                Basket.put("documentBasketId", documentReference.getId());
                                db.collection("Basket").document(documentReference.getId())
                                        .set(Basket, SetOptions.merge())
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@androidx.annotation.NonNull Task<Void> task) {

                                            }
                                        });
                                Log.d("TAG", "DocumentSnapshot written with ID: " + documentReference.getId());

                                holder.itemView.setVisibility(View.INVISIBLE);
//                                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
//                                intent.putExtra("code", 3);
//                                //     intent.putExtra("Data2", s);
//                                startActivity(intent);


                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.w("TAG", "Error adding document", e);


                            }
                        });

            }
        });


//        int totalPrice = 0;
//        for (int i = 0; i<data.size(); i++)
//        {
//
//            totalPrice = Integer.parseInt(data.get(i).getSelectedPrice()) *
//            Integer.parseInt(holder.pricetext.getText().toString()) ;  ;
//
//            preferencesHelper.setPREF_Position(totalPrice);
//
//        }


    }

    @Override
    public int getItemCount() {

        return data.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {

        TextView price, nameservies, pricetext, tvname, add, total, numberOfday;

        Button increase, decrease;

        Spinner spino;
        View view;


        public myViewHolder(View itemView) {
            super(itemView);

            spino = itemView.findViewById(R.id.spinner);
            nameservies = itemView.findViewById(R.id.nameserv);
            price = itemView.findViewById(R.id.tv_price);
            increase = itemView.findViewById(R.id.increase);
            decrease = itemView.findViewById(R.id.decrease);
            pricetext = itemView.findViewById(R.id.number_laundry);
            tvname = itemView.findViewById(R.id.textView30);
            view = itemView.findViewById(R.id.view);
            add = itemView.findViewById(R.id.addinbasket);
            total = itemView.findViewById(R.id.tolal);
            numberOfday = itemView.findViewById(R.id.textView52);

        }
    }
}
