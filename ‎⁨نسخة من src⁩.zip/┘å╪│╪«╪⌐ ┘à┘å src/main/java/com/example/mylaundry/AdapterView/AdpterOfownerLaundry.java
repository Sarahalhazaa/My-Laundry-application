package com.example.mylaundry.AdapterView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.AcivitysOfLaundry.DetailsLaundry;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.ServiesInt;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.ServicesOwner;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.OwnerActivitys.Details_Owner_Services;
import com.example.mylaundry.R;

import java.util.ArrayList;

public class AdpterOfownerLaundry extends RecyclerView.Adapter<AdpterOfownerLaundry.myViewHolder>{
    Activity activity;
    ArrayList<SubscriptionModel> data;
    ServiesInt callback;
    PreferencesHelper preferencesHelper;

    public AdpterOfownerLaundry(Activity activity, ArrayList<SubscriptionModel> data) {
        this.activity = activity;
        this.data = data;
        //   preferencesHelper =new PreferencesHelper(activity);
    }
    @Override
    public AdpterOfownerLaundry.myViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(activity).inflate(R.layout.laundryitem, parent, false);
        return new AdpterOfownerLaundry.myViewHolder(root);    }

    @Override
    public void onBindViewHolder(AdpterOfownerLaundry.myViewHolder holder, @SuppressLint("RecyclerView") int position) {

        holder.tv_name.setText(data.get(position).getName());
        holder.typeopen.setText(""+data.get(position).getStatus());
        holder.val.setText(data.get(position).getEvaluation() + "/5");

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(activity, Details_Owner_Services.class);
                String name = data.get(position).getName();
                String email = data.get(position).getEmail();
                String evaluation = data.get(position).getEvaluation();
                intent.putExtra("email", email);
                 intent.putExtra("name",name);
                intent.putExtra("evaluation", evaluation);
                intent.putExtra("num",data.get(position).getDocumentId());
                intent.putExtra("numberphone",data.get(position).getPhone());
                //preferencesHelper.setPREF_Position(position);

                activity.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {
        TextView tv_name , val,typeopen;

        public myViewHolder(View itemView) {
            super(itemView);
            tv_name = itemView.findViewById(R.id.textname);
            val=itemView.findViewById(R.id.val);
            typeopen=itemView.findViewById(R.id.typeopen);
        }
    }
}
