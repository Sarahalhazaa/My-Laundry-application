package com.example.mylaundry.helpers;

public class Constants {
    public static final String NEW = "NEW";
    public static final String CURRENT = "CURRENT";
    public static final String RENEWAL = "RENEWAL";
    public static final String PREVIOUS = "PREVIOUS";


    public static final String SERVICE_HOME = "home";
    public static final String SERVICE_CARPET = "carpet";
    public static final String SERVICE_CLOTHING = "clothing";


    public static final String TYPE_MODEL = "type_model";

}
