package com.example.mylaundry.helpers;

import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.R;

import org.checkerframework.checker.nullness.qual.Nullable;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class BaseFragment extends Fragment {

    protected SweetAlertDialog loadingDialog;
    protected PreferencesHelper preferencesHelper;

    protected void replaceAdmenFragments(Fragment newFragment) {
        FragmentTransaction ft = requireActivity().getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.admin_container, newFragment);
        ft.addToBackStack("");
        ft.commit();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadingDialog = new SweetAlertDialog(requireActivity(), SweetAlertDialog.PROGRESS_TYPE);
        loadingDialog.getProgressHelper().setBarColor(Color.parseColor("#A5DC86"));
        loadingDialog.setTitleText("Loading");
        loadingDialog.setCancelable(true);

        preferencesHelper = new PreferencesHelper(requireActivity());

    }


}
