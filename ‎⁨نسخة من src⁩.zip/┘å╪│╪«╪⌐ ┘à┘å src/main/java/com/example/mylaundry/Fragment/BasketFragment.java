package com.example.mylaundry.Fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.mylaundry.AdapterView.AdapterBasket;
import com.example.mylaundry.Model.BasketServices;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class BasketFragment extends Fragment {

    public BasketFragment() {
        // Required empty public constructor
    }

    View rootView;
    RecyclerView recyclerView;
    PreferencesHelper preferencesHelper;
    FirebaseFirestore db;
    ArrayList<Services> list = new ArrayList<>();
    Set<String> nameServices = new HashSet<>();
    ArrayList<BasketServices> basketServicesList = new ArrayList<>();
    AdapterBasket adapterBasket;
    FirebaseAuth auth;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_basket, container, false);
        auth=FirebaseAuth.getInstance();
        initView();
        return rootView;
    }

    private void initView() {
        preferencesHelper = new PreferencesHelper(requireActivity());
        db = FirebaseFirestore.getInstance();

        recyclerView = rootView.findViewById(R.id.recycleritem);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireActivity()));
        adapterBasket = new AdapterBasket(requireActivity(), basketServicesList);
        recyclerView.setAdapter(adapterBasket);
        getBasketRequest();
    }

    private void getBasketRequest() {
        db.collection("Basket")
                .whereEqualTo("keyuser",auth.getUid() )
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        for (DocumentSnapshot documentSnapshot : queryDocumentSnapshots.getDocuments()) {
                            Services services = documentSnapshot.toObject(Services.class);
                            Log.e("response", "services: " + services);
                            preferencesHelper.setPREF_Item_Delete(documentSnapshot.getId());
                            list.add(services);
                            assert services != null;
                            nameServices.add(services.getNameLaundry());
                        }

                        for (String name: nameServices) {
                            ArrayList<Services> servicesArrayList = (ArrayList<Services>) list.stream().filter(services -> services.getNameLaundry().equals(name)).collect(Collectors.toList());
                            basketServicesList.add(new BasketServices(name,servicesArrayList));
                        }

                        Log.e("response", "____________________________");
                        Log.e("response", "list: " + list);
                        Log.e("basketServicesList", "basketServicesList: " + nameServices);
                        adapterBasket.update(basketServicesList);
                    } else {
                      //  Toast.makeText(getActivity(), "No data found ", Toast.LENGTH_SHORT).show();
                    }
                }).addOnFailureListener(e -> {
                    Toast.makeText(getActivity(), "Fail to get the data.", Toast.LENGTH_SHORT).show();
                });
    }

}