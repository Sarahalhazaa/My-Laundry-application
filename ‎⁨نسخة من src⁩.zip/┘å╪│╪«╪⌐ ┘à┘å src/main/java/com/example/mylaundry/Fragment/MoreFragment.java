package com.example.mylaundry.Fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import com.example.mylaundry.ActivitysMore.AboutLaundry;
import com.example.mylaundry.ActivitysMore.ModifyData;
import com.example.mylaundry.ActivitysMore.PrivacyPolicy;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.R;
import com.example.mylaundry.SplashActivity;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;


public class MoreFragment extends Fragment {

    LinearLayout Modify, logout, about, policy;

    PreferencesHelper preferencesHelper;
    FirebaseFirestore firestore;
    FirebaseAuth auth;

    public MoreFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_more, container, false);


        Modify = rootView.findViewById(R.id.linera);
        preferencesHelper = new PreferencesHelper(getActivity());
        auth=FirebaseAuth.getInstance();
        firestore=FirebaseFirestore.getInstance();

        Modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent Modify = new Intent(getActivity(), ModifyData.class);
                getActivity().startActivity(Modify);
            }
        });

        logout = rootView.findViewById(R.id.linera4);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
                preferencesHelper.setPREF_User_Email("");
                preferencesHelper.setPREF_USER_DOCID("Null");
                Intent logout = new Intent(getActivity(), SplashActivity.class);
                startActivity(logout);
            }
        });


        about = rootView.findViewById(R.id.linera2);
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), AboutLaundry.class);
                startActivity(intent);
            }
        });

        policy = rootView.findViewById(R.id.linera3);

        policy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), PrivacyPolicy.class);
                startActivity(intent);
            }
        });


        return rootView;

    }

    @Override
    public void onStart() {
        super.onStart();

        firestore.collection("user").document(auth.getUid())
                .get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                String type=documentSnapshot.getString("typeuser");
                if (type.equals("Admin")){
                    Modify.setVisibility(View.GONE);
                }
                else {
                    Modify.setVisibility(View.VISIBLE);
                }

            }
        });
    }
}