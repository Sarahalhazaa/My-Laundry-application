package com.example.mylaundry.Fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mylaundry.AcivitysMainFragment.ActivityCurrentRequests;
import com.example.mylaundry.AcivitysMainFragment.ActivityPreviousRequests;
import com.example.mylaundry.AcivitysOfLaundry.ViewAllOfLaundry;
import com.example.mylaundry.ActivitysMore.ModifyData;
import com.example.mylaundry.AdapterView.AdapterServices;
import com.example.mylaundry.AdapterView.AdapterViewSubscription;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionsActivity;

import com.example.mylaundry.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;
import java.util.List;


public class MainFragment extends Fragment {

    Button previous_orders, current_requests;
    RecyclerView recyclerView;
    FirebaseFirestore db;
    FirebaseFirestore firestore;
    ArrayList<SubscriptionModel> st;
    FirebaseAuth auth;

    AdapterServices adapterServices;
    PreferencesHelper preferencesHelper;
    String citynamee;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_main, container, false);
        auth =FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        firestore = FirebaseFirestore.getInstance();

      //  Toast.makeText(getContext(), ""+citynamee, Toast.LENGTH_SHORT).show();
        recyclerView = rootView.findViewById(R.id.recyclerview);
        current_requests = rootView.findViewById(R.id.button3);
        TextView viewall = rootView.findViewById(R.id.viewall);
        preferencesHelper = new PreferencesHelper(getActivity());
        previous_orders = rootView.findViewById(R.id.button2);

        viewall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent viewall = new Intent(getActivity(), ViewAllOfLaundry.class);
                startActivity(viewall);
            }
        });

        previous_orders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getActivity(), ActivityPreviousRequests.class);

                getActivity().startActivity(intent);

            } });

        current_requests.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getActivity(), ActivityCurrentRequests.class);
                getActivity().startActivity(intent);

            }
        });

        firestore.collection("user").document(auth.getUid()).get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@androidx.annotation.NonNull Task<DocumentSnapshot> task) {
                DocumentSnapshot snapshot=task.getResult();
                citynamee=snapshot.getString("cityname");
                Log.d("date", "onComplete:Amed " + citynamee);
                getData();
                  //Toast.makeText(getContext(), ""+citynamee, Toast.LENGTH_SHORT).show();


            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@androidx.annotation.NonNull Exception e) {
                Toast.makeText(getContext(), ""+e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        st = new ArrayList<>();

        ///// change with get in area users


        // getData();


        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapterServices = new AdapterServices(getActivity(), st);
        recyclerView.setAdapter(adapterServices);


        return rootView;

    }


    void getData() {
        Log.d("date", "onComplete:city " + citynamee);

        firestore.collection("Subscription").whereEqualTo("area",citynamee).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        if (!queryDocumentSnapshots.isEmpty()) {
                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                            for (DocumentSnapshot d : list) {
                                //Toast.makeText(getContext(), ""+list.size(), Toast.LENGTH_SHORT).show();
                                SubscriptionModel subscriptionModel = d.toObject(SubscriptionModel.class);
                                if (subscriptionModel.getType().equals("CURRENT")){
                                    st.add(subscriptionModel);
                                }else {
                                  //  Toast.makeText(getContext(), "not found data.", Toast.LENGTH_SHORT).show();

                                }

                                Log.d("date", "onComplete:size " + st.size());

                            }
                            adapterServices.notifyDataSetChanged();
                        } else {
                            Log.d("TAG", "onSuccess: ");
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getActivity(), "Fail to get the data.", Toast.LENGTH_SHORT).show();
                    }
                });


//        db.collection("Subscription").whereEqualTo("cityname", preferencesHelper.getPREF_uer_area()).get()
//                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
//                    @SuppressLint("NotifyDataSetChanged")
//                    @Override
//                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
//
//                        if (!queryDocumentSnapshots.isEmpty()) {
//                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
//                            for (DocumentSnapshot d : list) {
//                                SubscriptionModel subscriptionModel = d.toObject(SubscriptionModel.class);
//                                st.add(subscriptionModel);
//                            }
//                            adapterServices.notifyDataSetChanged();
//
//                        } else {
//
//                            Toast.makeText(getContext(), "No data found ", Toast.LENGTH_SHORT).show();
//                        }
//                    }
//                }).addOnFailureListener(e -> {
//                    // if we do not get any data or any error we are displaying
//                    // a toast message that we do not get any data
//                    Toast.makeText(getActivity(), "Fail to get the data.", Toast.LENGTH_SHORT).show();
//                });


    }





  }