package com.example.mylaundry;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mylaundry.AdminActivities.MainAdmin;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.OwnerActivitys.MainOwner;
import com.example.mylaundry.driversFragment.MainActivityDrivers;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class LoginActivity extends AppCompatActivity {

    EditText et_email, et_password;
    Button login;
    TextView create, forget;

    FirebaseFirestore db;

    FirebaseAuth mAuth;

    PreferencesHelper preferencesHelper;

    String id;
    String type;
    SweetAlertDialog pDialog ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        init();

        db = FirebaseFirestore.getInstance();

        mAuth = FirebaseAuth.getInstance();


        preferencesHelper = new PreferencesHelper(this);

        forget = findViewById(R.id.textView54);
        forget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent forget = new Intent(getApplicationContext(), RestPassword.class);

                startActivity(forget);


            }
        });


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (et_email.getText().toString().isEmpty() && et_password.getText().toString().isEmpty()) {
                    et_email.setError(" Please enter email    ");
                    et_password.setError("Please enter pass");
                } else {

                    loginUser();


                }


            }
        });


        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent signup = new Intent(getApplicationContext(), SignUp.class);
                startActivity(signup);

            }
        });


    }


    void init() {

        et_email = findViewById(R.id.editemail);
        et_password = findViewById(R.id.editpassword);
        login = findViewById(R.id.button);
        create = findViewById(R.id.textView4);

        pDialog = new SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#A5DC86"));
        pDialog.setTitleText("Loading");
        pDialog.setCancelable(true);

//        et_email.setHint("sara@gmail.com");
//        et_password.setHint("123456");

    }


    void loginUser() {

        // Take the value of two edit texts in Strings
//        String email, password;
//        email = emailTextView.getText().toString();
//        password = passwordTextView.getText().toString();

        // validations for input email and password
        if (TextUtils.isEmpty(et_email.getText().toString())) {
            Toast.makeText(getApplicationContext(),
                            "Please enter email!!",
                            Toast.LENGTH_LONG)
                    .show();
            return;
        }

        if (TextUtils.isEmpty(et_password.getText().toString())) {
            Toast.makeText(getApplicationContext(), "Please enter password!!", Toast.LENGTH_LONG).show();
            return;
        }

        pDialog.show();

        mAuth.signInWithEmailAndPassword(et_email.getText().toString().trim(), et_password.getText().toString())
                .addOnCompleteListener(
                        task -> {
                            if (task.isSuccessful()) {
                                //    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                                Toast.makeText(getApplicationContext(),
                                                "Login successful!!",
                                                Toast.LENGTH_LONG)
                                        .show();

                                db.collection("user")
                                        .document(mAuth.getUid())
                                        .get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                            @Override
                                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                                if (task.isSuccessful()){
                                                  String type=  task.getResult().getString("typeuser");
                                                    Toast.makeText(LoginActivity.this, ""+type, Toast.LENGTH_SHORT).show();
                                                    //preferencesHelper.setIsLogin(true);
                                                   // pDialog.cancel();
                                                    open(type);
                                                }
                                            }
                                        })
                                        .addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(LoginActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
                                            }
                                        });

//                                        .addOnCompleteListener(task1 -> {
//                                            if (task1.isSuccessful()) {
//                                                for (QueryDocumentSnapshot document : task1.getResult()) {
//                                                    if (!document.exists()) {
//                                                        Toast.makeText(LoginActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
//                                                        pDialog.dismissWithAnimation();
//                                                    } else {
//                                                        document.getId();
//                                                        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
//                                                        id = user.getUid();
//                                                        String m = user.getEmail();
////                                                        preferencesHelper.setPREF_User_Email(m);
//                                                        preferencesHelper.setPREF_User_Email(et_email.getText().toString());
//                                                        Toast.makeText(LoginActivity.this, "" + m, Toast.LENGTH_SHORT).show();
//                                                        preferencesHelper.setPREF_USER_DOCID(document.getId());
//                                                        preferencesHelper.setIsLogin(true);
//
////                                                            db.collection("UserType").document(document.getId())
////                                                                    .update("id", id);
////                                                            Toast.makeText(LoginActivity.this, "" + type, Toast.LENGTH_SHORT).show();
//
//                                                        type = document.getString("typeuser");
//
//                                                        assert type != null;
//                                                        switch (type) {
//                                                            case "Customer": {
//                                                                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
//                                                                startActivity(intent);
//                                                                finish();
//                                                                break;
//                                                            }
//                                                            case "Owner": {
//                                                                Intent intent = new Intent(getApplicationContext(), MainOwner.class);
//                                                                startActivity(intent);
//                                                                break;
//                                                            }
//                                                            case "Admin": {
//                                                                Intent intent = new Intent(getApplicationContext(), MainAdmin.class);
//                                                                startActivity(intent);
//                                                                break;
//                                                            }
//                                                            case "Driver":{
//                                                                Intent intent = new Intent(getApplicationContext(), MainActivityDrivers.class);
//                                                                startActivity(intent);
//                                                                break;
//                                                            }
//                                                        }
//                                                        pDialog.dismissWithAnimation();
//                                                        finish();
//                                                    }
//                                                }
//                                            }
//                                            else {
//                                                Log.d("TAG", "", task1.getException());
//                                                Toast.makeText(getApplicationContext(),
//                                                                "Login failed!!" + task1.getException(),
//                                                                Toast.LENGTH_LONG)
//                                                        .show();
//                                                pDialog.dismissWithAnimation();
//
//                                            }
//                                        });


                            } else {
                                Toast.makeText(getApplicationContext(),
                                                "Login failed!!",
                                                Toast.LENGTH_LONG)
                                        .show();
                                pDialog.dismissWithAnimation();
//                                showPopupWindow();

                            }
                        });


    }


//
//
//
//     void showPopupWindow(final View view) {
//
//
//        //Create a View object yourself through inflater
//        LayoutInflater inflater = (LayoutInflater) view.getContext().getSystemService(view.getContext().LAYOUT_INFLATER_SERVICE);
//        View popupView = inflater.inflate(R.layout.pop_up_layout, null);
//
//        //Specify the length and width through constants
//        int width = LinearLayout.LayoutParams.MATCH_PARENT;
//        int height = LinearLayout.LayoutParams.MATCH_PARENT;
//
//        //Make Inactive Items Outside Of PopupWindow
//        boolean focusable = true;
//
//        //Create a window with our parameters
//        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
//
//        //Set the location of the window on the screen
//        popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
//
//        //Initialize the elements of our window, install the handler
//
//        TextView test2 = popupView.findViewById(R.id.titleText);
//       // test2.setText(R.string.textTitle);
//
//        Button buttonEdit = popupView.findViewById(R.id.messageButton);
//        buttonEdit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                //As an example, display the message
//               // Toast.makeText(view.getContext(), "Wow, popup action button", Toast.LENGTH_SHORT).show();
//                popupWindow.dismiss();
//            }
//        });
//
//
//
//        //Handler for clicking on the inactive zone of the window
//
//        popupView.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//
//                //Close the window when clicked
//                popupWindow.dismiss();
//                return true;
//            }
//        });
//    }
//
private void open(String type){
    switch (type) {
        case "Customer": {
            pDialog.dismissWithAnimation();
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            finish();
            break;
        }
        case "Owner": {
            pDialog.dismissWithAnimation();
            Intent intent = new Intent(getApplicationContext(), MainOwner.class);
            startActivity(intent);
            finish();
            break;
        }
        case "Admin": {
            pDialog.dismissWithAnimation();
            Intent intent = new Intent(getApplicationContext(), MainAdmin.class);
            startActivity(intent);
            finish();
            break;
        }
        case "Driver": {
            pDialog.dismissWithAnimation();
            Intent intent = new Intent(getApplicationContext(), MainActivityDrivers.class);
            startActivity(intent);
            finish();
            break;
        }
    }
    pDialog.dismissWithAnimation();
    finish();
}
}

