package com.example.mylaundry;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.Toast;

import com.example.mylaundry.ActivitysMore.ModifyData;
import com.example.mylaundry.databinding.ActivityEditDataBinding;
import com.example.mylaundry.databinding.ActivityEditDataDriverBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import org.checkerframework.checker.units.qual.A;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class EditDataDriver extends AppCompatActivity {
    ActivityEditDataDriverBinding binding;
    FirebaseAuth auth;
    FirebaseFirestore firestore;
    FirebaseUser auth2=FirebaseAuth.getInstance().getCurrentUser();
    String itemnationality;
    String pass;
    Calendar myCalendar;
    int age;
    String[] Area = {"Gulf", "Saudi", "Egyptian", "Indian",
            "Emirati", "Omani", "diagonal"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= DataBindingUtil.setContentView(this,R.layout.activity_edit_data_driver);
        auth=FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
        binding.spinnernationality.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int mPosition, long id) {
            itemnationality=binding.spinnernationality.getSelectedItem().toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        myCalendar = Calendar.getInstance();

        DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, day);
                updateLabel();
            }
        };


        binding.editbritheday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(EditDataDriver.this, date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();

            }
        });



       binding.button5.setOnClickListener(v -> {

           if (!binding.editemail.getText().toString().isEmpty()) {
               firestore.collection("user").document(auth.getUid())
                       .update("firstname", binding.editemail.getText().toString());
               onBackPressed();
           } else if (!binding.lastname.getText().toString().isEmpty()) {
               firestore.collection("user").document(auth.getUid())
                       .update("lastname", binding.lastname.getText().toString());
               onBackPressed();
           } else if (!binding.editephone.getText().toString().isEmpty()) {
               if (binding.editephone.length()>8||binding.editephone.length()<8){

                   Toast.makeText(this, "You must enter 8 numbers", Toast.LENGTH_SHORT).show();

               }else {
                   firestore.collection("user").document(auth.getUid())
                           .update("numberphone", binding.editephone.getText().toString());
                   onBackPressed();
               }
           }
           else if (!binding.editbritheday.getText().toString().isEmpty()) {
               if (age<18){
                   Toast.makeText(this, "age not equals 18 years", Toast.LENGTH_SHORT).show();
               }else {
                   firestore.collection("user").document(auth.getUid())
                           .update("birthday", binding.editbritheday.getText().toString());
                   onBackPressed();
               }
           }

           else if (!binding.editnationality.getText().toString().isEmpty()) {
               if (binding.editnationality.getText().toString().length()<10||binding.editnationality.getText().toString().length()>10){
                   Toast.makeText(this, "not equals 10 numbers", Toast.LENGTH_SHORT).show();
               }else {
                   firestore.collection("user").document(auth.getUid())
                           .update("nationalityId", binding.editnationality.getText().toString());
                   onBackPressed();
               }
           }
           else if (binding.editpass.getText().toString().equals(pass)) {
               if (binding.editpass2.getText().toString().equals(binding.editpass3.getText().toString())) {
                   firestore.collection("user").document(auth.getUid())
                           .update("password", binding.editpass2.getText().toString());

                   auth2.updatePassword(binding.editpass2.getText().toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                       @Override
                       public void onComplete(@androidx.annotation.NonNull Task<Void> task) {
                           if (task.isSuccessful()) {
                               Toast.makeText(EditDataDriver.this, "Update completed successfully ", Toast.LENGTH_SHORT).show();
                               onBackPressed();
                           }
                       }
                   }).addOnFailureListener(new OnFailureListener() {
                       @Override
                       public void onFailure(@androidx.annotation.NonNull Exception e) {
                           Toast.makeText(EditDataDriver.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();

                       }
                   });
               }
               else {
                   Toast.makeText(EditDataDriver.this, "no password true", Toast.LENGTH_SHORT).show();
                   Toast.makeText(this, " no change Any Data..", Toast.LENGTH_SHORT).show();

               }
           }
           else if (!itemnationality.isEmpty()) {
               firestore.collection("user").document(auth.getUid())
                       .update("nationality",itemnationality);
               onBackPressed();
           }


       });
    }


    @Override
    protected void onStart() {
        super.onStart();
        firestore.collection("user")
                .document(auth.getUid())
                .get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            String email = document.getString("email");
                            String numberphone = document.getString("numberphone");
                            String name = document.getString("firstname");
                            String namelast = document.getString("lastname");
                            String password = document.getString("password");
                            String birthday = document.getString("birthday");
                            String nationality = document.getString("nationality");
                            String nationalityId = document.getString("nationalityId");
                            pass =password;
                            // Toast.makeText(ModifyData.this, ""+password, Toast.LENGTH_SHORT).show();
                            binding.editemail.setHint(name);
                            binding.editemailuser.setHint(email);
                            binding.editemailuser.setEnabled(false);
                            binding.editephone.setHint(numberphone);
                            binding.editbritheday.setHint(birthday);
                            binding.lastname.setHint(namelast);
                            Area[0] = nationality;
                            ArrayAdapter ad2 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, Area);
                            ad2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            binding.spinnernationality.setAdapter(ad2);
                            binding.editnationality.setHint(nationalityId);


                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@androidx.annotation.NonNull Exception e) {

                    }
                });

    }
    private void updateLabel() {
        String myFormat = "MM/dd/yyyy";
        SimpleDateFormat dateFormat = new SimpleDateFormat(myFormat, Locale.US);
        binding.editbritheday.setText(dateFormat.format(myCalendar.getTime()));
        age = getPerfectAgeInYears(myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH));
        //Log.d("age", "updateLabel: " + getPerfectAgeInYears(myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)));
    }

    public int getPerfectAgeInYears(int year, int month, int date) {
        Calendar dobCalendar = Calendar.getInstance();
        dobCalendar.set(Calendar.YEAR, year);
        dobCalendar.set(Calendar.MONTH, month);
        dobCalendar.set(Calendar.DATE, date);

        int ageInteger = 0;

        Calendar today = Calendar.getInstance();

        ageInteger = today.get(Calendar.YEAR) - dobCalendar.get(Calendar.YEAR);

        if (today.get(Calendar.MONTH) == dobCalendar.get(Calendar.MONTH)) {

            if (today.get(Calendar.DAY_OF_MONTH) < dobCalendar.get(Calendar.DAY_OF_MONTH)) {

                ageInteger = ageInteger - 1;
            }

        } else if (today.get(Calendar.MONTH) < dobCalendar.get(Calendar.MONTH)) {

            ageInteger = ageInteger - 1;

        }

        return ageInteger;

    }

}