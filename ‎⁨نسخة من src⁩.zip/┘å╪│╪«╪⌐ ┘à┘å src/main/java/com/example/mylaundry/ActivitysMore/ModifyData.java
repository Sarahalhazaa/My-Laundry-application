package com.example.mylaundry.ActivitysMore;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mylaundry.Fragment.MoreFragment;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.UserType;
import com.example.mylaundry.R;
import com.example.mylaundry.SplashActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.nullness.qual.NonNull;

public class ModifyData extends AppCompatActivity {
   TextView neighsss,Streetnamesss,nearestLandmasss,home_numbersss;
    Spinner spinneruser;
    EditText et_name, et_email, et_phone, old_pass, newpassword, con_password,streetname,nearest,homenumber,lastname;
    Button Done, backmenu, back;
    FirebaseFirestore firestore;
    PreferencesHelper preferencesHelper;
    String password;
    int pass;
    String text;
    String[] Area2 = {"Al-Suwaidi district", "Al-Nafl district", "Al-Awali district", "Al-Yasmeen district",
            "Al-Mursalat District", "Al-Sahafah district", "Al-Sahafah district", "Al-Yarmouk district"};

    FirebaseUser auth=FirebaseAuth.getInstance().getCurrentUser();
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_data);

        et_name = findViewById(R.id.editemail);
        et_phone = findViewById(R.id.editephone);
        et_email = findViewById(R.id.editemailuser);
        Done = findViewById(R.id.button5);
        backmenu = findViewById(R.id.button4);
        back = findViewById(R.id.button6);
        newpassword = findViewById(R.id.editpass2);
        old_pass = findViewById(R.id.editpass);
        con_password = findViewById(R.id.editpass3);
        streetname=findViewById(R.id.editStreetName);
        nearest=findViewById(R.id.editnearestLandma);
        homenumber=findViewById(R.id.edithomenumber);
        spinneruser = findViewById(R.id.spinneruser);
        neighsss=findViewById(R.id.neigh);
        Streetnamesss=findViewById(R.id.Streetname);
        nearestLandmasss=findViewById(R.id.nearestLandma);
        home_numbersss=findViewById(R.id.home_number);
        lastname=findViewById(R.id.lastname);
//
//        newpassword.setFocusable(false);
//        con_password.setFocusable(false);


        spinneruser.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int mPosition, long id) {
             text =spinneruser.getSelectedItem().toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        backmenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent back = new Intent(getApplicationContext(), MoreFragment.class);
//                startActivity(back);
                onBackPressed();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                Intent back = new Intent(getApplicationContext(), MoreFragment.class);
//                startActivity(back);
                onBackPressed();
            }
        });


        firestore = FirebaseFirestore.getInstance();

        preferencesHelper = new PreferencesHelper(this);


        firestore.collection("user")
                .document(auth.getUid())
                .get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@androidx.annotation.NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                                String email = document.getString("email");
                                String numberphone = document.getString("numberphone");
                                String name = document.getString("firstname");
                                String namelast = document.getString("lastname");
                                password = document.getString("password");
                                pass = Integer.parseInt(password);
                                Toast.makeText(ModifyData.this, ""+password, Toast.LENGTH_SHORT).show();
                                et_name.setHint(name);
                                et_email.setHint(email);
                                et_phone.setHint(numberphone);
                                lastname.setHint(namelast);

                                if (document.getString("typeuser").equals("Owner")){
                                    spinneruser.setVisibility(View.GONE);
                                    streetname.setVisibility(View.GONE);
                                    nearest.setVisibility(View.GONE);
                                    homenumber.setVisibility(View.GONE);
                                    neighsss.setVisibility(View.GONE);
                                    Streetnamesss.setVisibility(View.GONE);
                                    nearestLandmasss.setVisibility(View.GONE);
                                    home_numbersss.setVisibility(View.GONE);
                                    return;

                                }



                                else {
                                    String getstreetname=document.getString("street_name");
                                    String getnearest=document.getString("nearest_teacher");
                                    String gethomenumber=document.getString("home_number");
                                    String getcityname=document.getString("cityname");
                                    Toast.makeText(ModifyData.this, ""+getcityname, Toast.LENGTH_SHORT).show();
                                    Area2[0]=getcityname;
                                    ArrayAdapter ad2 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, Area2);//        holder.inputLayout.setAdapter(adapter);
                                    ad2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                    spinneruser.setAdapter(ad2);
                                    Log.d("date", "onComplete: " + email);
                                    Log.d("date", "onComplete: " + numberphone);
                                    Log.d("date", "onComplete: " + name);
                                    et_name.setHint(name);
                                    et_email.setHint(email);
                                    lastname.setHint(namelast);
                                    et_phone.setHint(numberphone);
                                    streetname.setHint(getstreetname+"");
                                    nearest.setHint(getnearest+"");
                                    homenumber.setHint(gethomenumber);
                                }


//                                if(old_pass.getText().toString().equals(password)){
//                                    Toast.makeText(ModifyData.this, "yes", Toast.LENGTH_SHORT).show();
//                                    newpassword.setFocusableInTouchMode(true);
//                                    con_password.setFocusableInTouchMode(true);
//                                } else {
//                                    Toast.makeText(ModifyData.this, "no", Toast.LENGTH_SHORT).show();
//
//                                    newpassword.setFocusable(false);
//                                    con_password.setFocusable(false);
//                                }
                            }

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@androidx.annotation.NonNull Exception e) {

                    }
                });




        Done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!et_name.getText().toString().isEmpty()) {
                    firestore.collection("user").document(auth.getUid())
                            .update("firstname", et_name.getText().toString());

                } else if (!lastname.getText().toString().isEmpty()) {
                    firestore.collection("user").document(auth.getUid())
                            .update("lastname", lastname.getText().toString());
                } else if (!et_phone.getText().toString().isEmpty()) {
                    if (et_phone.length()>8||et_phone.length()<8){
                        Toast.makeText(ModifyData.this, "You must enter 8 numbers", Toast.LENGTH_SHORT).show();
                    }else {
                        firestore.collection("user").document(auth.getUid())
                                .update("numberphone", et_phone.getText().toString());
                    }
                } else if (!et_email.getText().toString().isEmpty()) {
                    firestore.collection("user").document(auth.getUid())
                            .update("email", et_email.getText().toString());
                } else if (!streetname.getText().toString().isEmpty()) {
                    firestore.collection("user").document(auth.getUid())
                            .update("street_name", streetname.getText().toString());
                } else if (!nearest.getText().toString().isEmpty()) {
                    firestore.collection("user").document(auth.getUid())
                            .update("nearest_teacher", nearest.getText().toString());
                }
                else if (!homenumber.getText().toString().isEmpty()) {
                    firestore.collection("user").document(auth.getUid())
                            .update("home_number",homenumber.getText().toString());
                    Toast.makeText(ModifyData.this, "homenumber", Toast.LENGTH_SHORT).show();
                }
                else if (old_pass.getText().toString().equals(password)) {
                    if (newpassword.getText().toString().equals(con_password.getText().toString())) {
                        firestore.collection("user").document(auth.getUid())
                                .update("password", newpassword.getText().toString());
//                        AuthCredential credential = EmailAuthProvider
//                                .getCredential(et_email.getHint().toString(), old_pass.getText().toString());
//                        auth.reauthenticate(credential);
                        auth.updatePassword(newpassword.getText().toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@androidx.annotation.NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(ModifyData.this, "Update completed successfully ", Toast.LENGTH_SHORT).show();
                                    onBackPressed();
                                }
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@androidx.annotation.NonNull Exception e) {
                                Toast.makeText(ModifyData.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();

                            }
                        });
                    } else {
                        Toast.makeText(ModifyData.this, "no password true", Toast.LENGTH_SHORT).show();
                    }
                }

                else if (!text.isEmpty()) {
                    firestore.collection("user").document(auth.getUid())
                            .update("cityname", text);

                }


               else {
                    Toast.makeText(getApplicationContext(), "Update completed successfully ", Toast.LENGTH_SHORT).show();
                    finish();
                    preferencesHelper.setPREF_USER_DOCID("Null");
                    Intent intent = new Intent(getApplicationContext(), SplashActivity.class);
                    startActivity(intent);

                }


            }
        });


//
//        firestore.collection("User").document(preferencesHelper.getPREF_USER_DOCID())
//                .update("name", firstname.getText().toString(),
//                        "lastname",lastname.getText().toString() );


    }
}