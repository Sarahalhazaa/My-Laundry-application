package com.example.mylaundry.AdapterOwner;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.R;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class AdapterOwnerSub extends RecyclerView.Adapter<AdapterOwnerSub.myViewHolder>{
    Activity activity;
    ArrayList<SubscriptionModel> dataSub;


    public AdapterOwnerSub(Activity activity, ArrayList<SubscriptionModel> dataSub) {
        this.activity = activity;
        this.dataSub = dataSub;
    }

    @Override
    public AdapterOwnerSub.myViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(activity).inflate(R.layout.itemrecylcer, parent, false);
        return new AdapterOwnerSub.myViewHolder(root);
    }

    @Override
    public void onBindViewHolder(AdapterOwnerSub.myViewHolder holder, int position) {

        SubscriptionModel subscriptionModel = dataSub.get(position);
        holder.onBind(subscriptionModel);

    }

    @Override
    public int getItemCount() {
        return dataSub.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {

        TextView tv_number , startDate , EndDate , duration , number;

        public myViewHolder(View itemView) {
            super(itemView);
            tv_number =itemView .findViewById(R.id.editemail);
            startDate =itemView .findViewById(R.id.editemaill);
            EndDate =itemView .findViewById(R.id.emaill);
            duration =itemView .findViewById(R.id.textView63);
            number=itemView.findViewById(R.id.textView65);
        }

        private void onBind(SubscriptionModel model) {
            tv_number.setText(model.getCommercial_register_number());
            startDate.setText(model.getNowdate());
            EndDate.setText(model.getEndDate());
            duration.setText(model.getDuration());
            number.setText(model.getNumberSubscr());
        }
    }
}
