package com.example.mylaundry.AdapterOwner;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.AdapterView.AdapterBasket;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.function.Predicate;

public class AdapterAccountLaundry extends RecyclerView.Adapter<AdapterAccountLaundry.myViewHolder> {
    FirebaseAuth auth=FirebaseAuth.getInstance();

    ArrayList<SubscriptionModel> data;

    Activity activity;
    ArrayList<SubscriptionModel> dataSub;
    FirebaseFirestore firestore;
    PreferencesHelper preferencesHelper;


    public AdapterAccountLaundry(Activity activity, ArrayList<SubscriptionModel> data) {
        this.data = data;
        this.activity = activity;
        firestore = FirebaseFirestore.getInstance();
        preferencesHelper = new PreferencesHelper(activity);
    }

    @Override
    public AdapterAccountLaundry.myViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(activity).inflate(R.layout.item_accountlaundry, parent, false);
        return new AdapterAccountLaundry.myViewHolder(root);

    }

    @Override
    public void onBindViewHolder(AdapterAccountLaundry.myViewHolder holder, int position) {

        SubscriptionModel model = data.get(position);
        holder.onBind(model);


    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {

        EditText et_name, et_email, et_phone;
        Button update;
        RecyclerView recyclerView;

        public myViewHolder(View itemView) {
            super(itemView);
            et_name = itemView.findViewById(R.id.editemail);
            et_email = itemView.findViewById(R.id.emaill);
            et_phone = itemView.findViewById(R.id.editemaill);
            recyclerView = itemView.findViewById(R.id.RecyclerViewitem);
            update = itemView.findViewById(R.id.button14);
        }

        private void onBind(SubscriptionModel model) {
            et_name.setHint(model.getName());
            et_email.setHint(model.getEmail());
            et_phone.setHint("05  "+model.getPhone());

            update.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (!et_name.getText().toString().isEmpty()) {
                        firestore.collection("Subscription").
                                document(model.getDocumentId())
                                .update("name", et_name.getText().toString());
                        Toast.makeText(activity, " data has been updated", Toast.LENGTH_SHORT).show();

                    } else if (!et_email.getText().toString().isEmpty()) {
                        firestore.collection("Subscription").
                                document(model.getDocumentId())
                                .update("email", et_email.getText().toString());

                        Toast.makeText(activity, " data has been updated", Toast.LENGTH_SHORT).show();

                    } else if (!et_phone.getText().toString().isEmpty()) {
                        firestore.collection("Subscription").
                                document(model.getDocumentId())
                                .update("phone", et_phone.getText().toString());
                        Toast.makeText(activity, " data has been updated", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(activity, "No data has been updated", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            SubscriptionModel subscriptionModel = new SubscriptionModel(model.getName(),
                    model.getCommercial_register_number(),
                    model.getDuration(), model.getNowdate(), model.getEndDate(), model.getNumberSubscr(),model.getKey());
            dataSub = new ArrayList<>();
            dataSub.add(subscriptionModel);

            recyclerView.setHasFixedSize(true);
            recyclerView.setLayoutManager(new LinearLayoutManager(activity));
            AdapterOwnerSub adapterOwnerSub = new AdapterOwnerSub(activity, dataSub);
            recyclerView.setAdapter(adapterOwnerSub);
        }
    }


    public void update2(ArrayList<SubscriptionModel> newList) {
        data = newList;
        notifyDataSetChanged();
    }
}
