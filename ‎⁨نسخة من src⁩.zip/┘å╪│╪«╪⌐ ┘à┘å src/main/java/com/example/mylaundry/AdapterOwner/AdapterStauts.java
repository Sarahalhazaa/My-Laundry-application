package com.example.mylaundry.AdapterOwner;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class AdapterStauts extends RecyclerView.Adapter<AdapterStauts.myViewHolder> {

    Activity activity;
    ArrayList<SubscriptionModel> dataSub;
    FirebaseFirestore firestore;
    PreferencesHelper preferencesHelper;
    FirebaseAuth auth=FirebaseAuth.getInstance();


    public AdapterStauts(Activity activity, ArrayList<SubscriptionModel> dataSub) {
        this.dataSub = dataSub;
        this.activity = activity;
        firestore = FirebaseFirestore.getInstance();
        preferencesHelper = new PreferencesHelper(activity);

    }

    @Override
    public AdapterStauts.myViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View root = LayoutInflater.from(activity).inflate(R.layout.itemstauts, parent, false);
        return new AdapterStauts.myViewHolder(root);
    }

    @Override
    public void onBindViewHolder(AdapterStauts.myViewHolder holder, int position) {
        SubscriptionModel model = dataSub.get(position);
        holder.OnBind(model);
        if (model.getStatus().equals("not available ")){
            holder.not_available.setChecked(true);


        }if(model.getStatus().equals("Busy")){
            holder.Busy.setChecked(true);


        }if (model.getStatus().equals("available")){
            holder.available.setChecked(true);

        }



    }

    @Override
    public int getItemCount() {
        return dataSub.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {

        TextView name;
        Button update;
        private RadioGroup radioGroup;
        private RadioButton radioButton;
        RadioButton not_available,Busy,available;

        public myViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.texx);
            update = itemView.findViewById(R.id.button17);
            radioGroup = itemView.findViewById(R.id.radio);
            not_available=itemView.findViewById(R.id.bt_Start);
            Busy=itemView.findViewById(R.id.bt_Busy);
            available=itemView.findViewById(R.id.bt_Suspended);
        }

        private void OnBind(SubscriptionModel model) {
            name.setText(model.getName());
            update.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    int selectedId = radioGroup.getCheckedRadioButtonId();

                    radioButton =  itemView.findViewById(selectedId);
                    Toast.makeText(activity, radioButton.getText(), Toast.LENGTH_SHORT).show();
                    firestore.collection("Subscription").document(model.getDocumentId())
                            .update("status", radioButton.getText());
//                    Log.d("1", "onClick:1 " + preferencesHelper.getPREF_Stuts_DOCID());
//                    Log.d("khadijaa", "onClick:1 " + radioButton.getText());
//                    Log.d("khadijaa", "onClick:1 " + model.getID());
                }
            });
        }
    }

    public void update2(ArrayList<SubscriptionModel> newList) {
        dataSub = newList;
        notifyDataSetChanged();
    }
}
