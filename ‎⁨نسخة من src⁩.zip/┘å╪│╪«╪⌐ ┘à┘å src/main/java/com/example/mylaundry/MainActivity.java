package com.example.mylaundry;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;

import com.example.mylaundry.Fragment.BasketFragment;
import com.example.mylaundry.Fragment.MainFragment;
import com.example.mylaundry.Fragment.MoreFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    private void initView() {
        bottomNav = findViewById(R.id.bottom_nav_view);

        replaceFragment(new MainFragment());
        Intent mIntent = getIntent();
        int intValue = mIntent.getIntExtra("code", 0);
        if (intValue == 3) {
            replaceFragment(new BasketFragment());
        } else {
            replaceFragment(new MainFragment());
        }
        initBottomNavView();
    }

    private void initBottomNavView() {
        bottomNav.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;

            int itemId = item.getItemId();
            if (itemId == R.id.home) {
                selectedFragment = new MainFragment();
            } else if (itemId == R.id.basket) {
                selectedFragment = new BasketFragment();
            } else if (itemId == R.id.more) {
                selectedFragment = new MoreFragment();
            }
            if (selectedFragment != null) {
                replaceFragment(selectedFragment);
            }
            return true;
        });
    }

    private void replaceFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment).commit();
    }

}