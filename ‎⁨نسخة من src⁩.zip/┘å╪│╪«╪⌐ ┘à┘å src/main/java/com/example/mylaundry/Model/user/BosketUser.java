package com.example.mylaundry.Model.user;

import com.example.mylaundry.Model.ItemServies;

import java.util.ArrayList;

public class BosketUser {
    String nameService;
    String nameLaundry;
    String Email;
    ArrayList<ItemServies> itemsservies;
    String selectedPrice;
    String eidtetxt;
    String pricetext;
    String NumberOfday;
    String emailUser;
    String numberofService ;
    String price;
    String total;
    String keysub;
    String documentId;

    public String getNameService() {
        return nameService;
    }

    public void setNameService(String nameService) {
        this.nameService = nameService;
    }

    public String getNameLaundry() {
        return nameLaundry;
    }

    public void setNameLaundry(String nameLaundry) {
        this.nameLaundry = nameLaundry;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public ArrayList<ItemServies> getItemsservies() {
        return itemsservies;
    }

    public void setItemsservies(ArrayList<ItemServies> itemsservies) {
        this.itemsservies = itemsservies;
    }

    public String getSelectedPrice() {
        return selectedPrice;
    }

    public void setSelectedPrice(String selectedPrice) {
        this.selectedPrice = selectedPrice;
    }

    public String getEidtetxt() {
        return eidtetxt;
    }

    public void setEidtetxt(String eidtetxt) {
        this.eidtetxt = eidtetxt;
    }

    public String getPricetext() {
        return pricetext;
    }

    public void setPricetext(String pricetext) {
        this.pricetext = pricetext;
    }

    public String getNumberOfday() {
        return NumberOfday;
    }

    public void setNumberOfday(String numberOfday) {
        NumberOfday = numberOfday;
    }

    public String getEmailUser() {
        return emailUser;
    }

    public void setEmailUser(String emailUser) {
        this.emailUser = emailUser;
    }

    public String getNumberofService() {
        return numberofService;
    }

    public void setNumberofService(String numberofService) {
        this.numberofService = numberofService;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getKeysub() {
        return keysub;
    }

    public void setKeysub(String keysub) {
        this.keysub = keysub;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }
}
