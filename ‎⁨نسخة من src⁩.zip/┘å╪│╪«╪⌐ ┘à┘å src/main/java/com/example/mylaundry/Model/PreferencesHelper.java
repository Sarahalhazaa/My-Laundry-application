package com.example.mylaundry.Model;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferencesHelper {

    private SharedPreferences sharedPreferences;
    private final String PREF_USER_DOCID = "PREF_USER_DOCID";
    private final String PREF_subscription = "PREF_subscription";
    private final String PREF_services = "PREF_services";
    private final String PREF_User_basket = "PREF_User_basket";

    private final String PREF_User_position = "PREF_User_position";
    private final String PREF_User_AREA= "PREF_User_AREA";

    private final String PREF_User_adreess = "PREF_User_position";

    private final String PREF_User_Email = "PREF_User_Email";

    private final String PREF_Item_Delete = "PREF_Item_Delete";

    private final String PREF_Item_Update = "PREF_Item_Update";
    private final String PREF_Item_del= "PREF_Item_del";

    private final String PREF_Item_Status= "PREF_Item_Status";




//    public PreferencesHelper() {
//    }


    public PreferencesHelper(Context context) {
        String PREFERENCES_USERID = "com.example.mylaundry.PREFERENCES_USERID";
        sharedPreferences = context.getSharedPreferences(PREFERENCES_USERID, Context.MODE_PRIVATE);
    }


    public void setPREF_USER_DOCID(String docID) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PREF_USER_DOCID, docID);
        editor.apply();
    }


    public String getPREF_USER_DOCID() {
        return sharedPreferences.getString(PREF_USER_DOCID, "Null");
    }


    public void setPREF_subscription_DOCID(String docID) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PREF_subscription, docID);
        editor.apply();
    }

    public String getPREF_subscription_DOCID() {
        return sharedPreferences.getString(PREF_subscription, "Null");
    }


    public void setPREF_Stuts_DOCID(String docID) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PREF_services, docID);
        editor.apply();
    }

    public String getPREF_Stuts_DOCID() {
        return sharedPreferences.getString(PREF_services, "Null");
    }


    public void setPREF_Total_basket(String docID) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PREF_User_basket, docID);
        editor.apply();
    }

    public String getPREF_Total_basket() {
        return sharedPreferences.getString(PREF_User_basket, "Null");
    }


    public String getPREF_Item_Delete() {
        return sharedPreferences.getString(PREF_Item_Delete, "Null");
    }

    public void setPREF_Item_Delete(String Position) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PREF_Item_Delete, Position);
        editor.apply();
    }


    public String getPREF_Item_Update() {
        return sharedPreferences.getString(PREF_Item_Update, "Null");
    }

    public void setPREF_Item_Update(String Position) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PREF_Item_Update, Position);
        editor.apply();
    }

    public String getPREF_User_adreess() {
        return sharedPreferences.getString(PREF_User_adreess, "Null");
    }

    public void setPREF_User_adreess(String Position) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PREF_User_adreess, Position);
        editor.apply();
    }


    public String getPREF_User_Email() {
        return sharedPreferences.getString(PREF_User_Email, "Null");
    }

    public void setPREF_User_Email(String Position) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PREF_User_Email, Position);
        editor.apply();
    }

    public void setIsLogin(boolean isLogin) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isLogin", isLogin);
        editor.apply();
    }

    public boolean getIsLogin() {
        return sharedPreferences.getBoolean("isLogin", false);
    }

    public String getPREF_Owner_del() {
        return sharedPreferences.getString(PREF_Item_del, "Null");
    }

    public void setPREF_dirver_statue(String Position) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PREF_Item_Update, Position);
        editor.apply();
    }


    public String getPREF_dirver_statueOwner_del() {
        return sharedPreferences.getString(PREF_Item_Update, "Null");
    }

    public void setPREF_Owner_del(String Position) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PREF_Item_del, Position);
        editor.apply();
    }


    public String getPREF_uer_area() {
        return sharedPreferences.getString(PREF_User_AREA, "Null");
    }

    public void setPREF_uer_area(String Position) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PREF_User_AREA, Position);
        editor.apply();
    }
}
