package com.example.mylaundry.Model;

import java.util.ArrayList;

public class Basket {
    ArrayList<Services> data;
    String emailUser ;

    public Basket() {
    }

    public Basket(ArrayList<Services> data, String emailUser) {
        this.data = data;
        this.emailUser = emailUser;
    }

    public ArrayList<Services> getData() {
        return data;
    }

    public void setData(ArrayList<Services> data) {
        this.data = data;
    }

    public String getEmail() {
        return emailUser;
    }

    public void setEmail(String email) {
        this.emailUser = email;
    }

    @Override
    public String toString() {
        return "Basket{" +
                "data=" + data +
                ", email='" + emailUser + '\'' +
                '}';
    }
}
