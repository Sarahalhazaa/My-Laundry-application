package com.example.mylaundry.Model;

import java.io.Serializable;
import java.util.ArrayList;

public class Services implements Serializable {

    String nameService;
    String nameLaundry;
    String Email;
    ArrayList<ItemServies> itemsservies;
    String selectedPrice;
    String eidtetxt;
    String pricetext;
    String NumberOfday;
    String emailUser;
    String numberofService ;
    String price;
    String total;
    String keysub;
    String documentId;
    String keyuser;

    public String getKeyuser() {
        return keyuser;
    }

    public void setKeyuser(String keyuser) {
        this.keyuser = keyuser;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getKeysub() {
        return keysub;
    }

    public void setKeysub(String keysub) {
        this.keysub = keysub;
    }

    public String getSelectedPrice() {
        return selectedPrice;
    }

    public void setSelectedPrice(String selectedPrice) {
        this.selectedPrice = selectedPrice;
    }

//    public services(String nameService, String nameLaundry, String email,
//                    ArrayList<ItemServies> itemsservies) {
//        this.nameService = nameService;
//        this.nameLaundry = nameLaundry;
//        Email = email;
//        this.itemsservies = itemsservies;
//    }

    public String getEidtetxt() {
        return eidtetxt;
    }

    public void setEidtetxt(String eidtetxt) {
        this.eidtetxt = eidtetxt;
    }

    public Services(String nameService, String nameLaundry, String email,
                    ArrayList<ItemServies> itemsservies, String eidtetxt, String numberOfday) {
        this.nameService = nameService;
        this.nameLaundry = nameLaundry;
        Email = email;
        this.itemsservies = itemsservies;
        this.eidtetxt = eidtetxt;
        NumberOfday = numberOfday;


    }

    public Services(String eidtetxt, String pricetext, String numberofService ,String nameLaundry ) {
        this.eidtetxt = eidtetxt;
        this.pricetext = pricetext;
        this.numberofService = numberofService;
        this.nameLaundry=nameLaundry;

    }

    public Services(String nameService, String nameLaundry, String email,
                    ArrayList<ItemServies> itemsservies, String eidtetxt,
                    String pricetext, String numberOfday, String total) {
        this.nameService = nameService;
        this.nameLaundry = nameLaundry;
        Email = email;
        this.itemsservies = itemsservies;
        this.eidtetxt = eidtetxt;
        NumberOfday = numberOfday;
        this.pricetext = pricetext;
        this.total = total;


    }

    public Services(String nameService, String nameLaundry, String email,
                    ArrayList<ItemServies> itemsservies,
                    String eidtetxt, String pricetext,
                    String numberOfday, String emailUser, String total) {
        this.nameService = nameService;
        this.nameLaundry = nameLaundry;
        Email = email;
        this.itemsservies = itemsservies;
        this.eidtetxt = eidtetxt;
        this.pricetext = pricetext;
        NumberOfday = numberOfday;
        this.emailUser = emailUser;
        this.total = total;

    }

    public Services(String nameService, String nameLaundry, String email, ArrayList<ItemServies> itemsservies, String selectedPrice, String eidtetxt,
                    String pricetext, String numberOfday, String emailUser, String numberofService, String total) {
        this.nameService = nameService;
        this.nameLaundry = nameLaundry;
        Email = email;
        this.itemsservies = itemsservies;
        this.selectedPrice = selectedPrice;
        this.eidtetxt = eidtetxt;
        this.pricetext = pricetext;
        NumberOfday = numberOfday;
        this.emailUser = emailUser;
        this.numberofService = numberofService;
        this.total = total;
    }

    public String getNumberofService() {
        return numberofService;
    }

    public void setNumberofService(String numberofService) {
        this.numberofService = numberofService;
    }

//    public Services(String nameService, String nameLaundry, String email,
//                    ArrayList<ItemServies> itemsservies, String eidtetxt ,String pricetext) {
//        this.nameService = nameService;
//        this.nameLaundry = nameLaundry;
//        Email = email;
//        this.itemsservies = itemsservies;
//        this.eidtetxt = eidtetxt;
//        this.pricetext=pricetext;
//    }


    public Services(String nameService, String nameLaundry, String email,
                    ArrayList<ItemServies> itemsservies, String selectedPrice,
                    String eidtetxt, String numberOfday) {
        this.nameService = nameService;
        this.nameLaundry = nameLaundry;
        Email = email;
        this.itemsservies = itemsservies;
        this.selectedPrice = selectedPrice;
        this.eidtetxt = eidtetxt;
        NumberOfday = numberOfday;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    //
//    public services(String nameLaundry, String email, ArrayList<ItemServies> itemsservies) {
//        this.nameLaundry = nameLaundry;
//        Email = email;
//        this.itemsservies = itemsservies;
//    }

    public Services() {
    }

    public String getNumberOfday() {
        return NumberOfday;
    }

    public void setNumberOfday(String numberOfday) {
        NumberOfday = numberOfday;
    }

    public String getPricetext() {
        return pricetext;
    }

    public void setPricetext(String pricetext) {
        this.pricetext = pricetext;
    }

    public String getNameService() {
        return nameService;
    }

    public void setNameService(String nameService) {
        this.nameService = nameService;
    }

    public String getNameLaundry() {
        return nameLaundry;
    }

    public void setNameLaundry(String nameLaundry) {
        this.nameLaundry = nameLaundry;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public ArrayList<ItemServies> getItemsservies() {
        return itemsservies;
    }

    public void setItemsservies(ArrayList<ItemServies> itemsservies) {
        this.itemsservies = itemsservies;
    }

    @Override
    public String toString() {
        return "Services{" +
                "nameService='" + nameService + '\'' +
                ", nameLaundry='" + nameLaundry + '\'' +
                ", Email='" + Email + '\'' +
                ", itemsservies=" + itemsservies +
                ", selectedPrice='" + selectedPrice + '\'' +
                ", eidtetxt='" + eidtetxt + '\'' +
                ", pricetext='" + pricetext + '\'' +
                ", NumberOfday='" + NumberOfday + '\'' +
                ", emailUser='" + emailUser + '\'' +
                ", numberofService='" + numberofService + '\'' +
                ", total='" + total + '\'' +
                '}';
    }

    public String getEmailUser() {
        return emailUser;
    }
    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public void setEmailUser(String emailUser) {
        this.emailUser = emailUser;
    }
}
