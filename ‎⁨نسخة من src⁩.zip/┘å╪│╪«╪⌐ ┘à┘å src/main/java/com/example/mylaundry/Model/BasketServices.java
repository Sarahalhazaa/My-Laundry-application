package com.example.mylaundry.Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class BasketServices  implements Serializable {
    String nameLaundry;
    ArrayList<Services> services;

    public BasketServices(String nameLaundry, ArrayList<Services> services) {
        this.nameLaundry = nameLaundry;
        this.services = services;
    }

    public BasketServices() {
    }

    public String getNameLaundry() {
        return nameLaundry;
    }

    public void setNameLaundry(String nameLaundry) {
        this.nameLaundry = nameLaundry;
    }

    public ArrayList<Services> getServices() {
        return services;
    }

    public void setServices(ArrayList<Services> services) {
        this.services = services;
    }

    @Override
    public String toString() {
        return "BasketServices{" +
                "nameLaundry='" + nameLaundry + '\'' +
                ", services=" + services +
                '}';
    }
}
