package com.example.mylaundry.Model;

public class UserType {


    String Firstname , Lastname , email , phonenumber , password , confirmphone , birthday ,
    nationality , NatID , typeuser,key ;

    String cityname , Street_name ,nearest_teacher ,home_number;

//    public UserType(String firstname, String lastname, String email,
//                    String phonenumber, String password, String confirmphone, String birthday,
//                    String nationality, String natID, String typeuser, String cityname,
//                    String street_name, String nearest_teacher, String home_number) {
//        Firstname = firstname;
//        Lastname = lastname;
//        this.email = email;
//        this.phonenumber = phonenumber;
//        this.password = password;
//        this.confirmphone = confirmphone;
//        this.birthday = birthday;
//        this.nationality = nationality;
//        NatID = natID;
//        this.typeuser = typeuser;
//        this.cityname = cityname;
//        Street_name = street_name;
//        this.nearest_teacher = nearest_teacher;
//        this.home_number = home_number;
//    }







    public UserType() {
    }

//    public UserType(String firstname, String lastname, String email, String phonenumber,
//                    String password, String confirmphone,
//                    String birthday, String nationality, String natID, String typeuser) {
//        Firstname = firstname;
//        Lastname = lastname;
//        this.email = email;
//        this.phonenumber = phonenumber;
//        this.password = password;
//        this.confirmphone = confirmphone;
//        this.birthday = birthday;
//        this.nationality = nationality;
//        NatID = natID;
//        this.typeuser = typeuser;
//    }

    public String getNatID() {
        return NatID;
    }

    public void setNatID(String natID) {
        NatID = natID;
    }


//    public UserType(String firstname, String lastname, String email, String phonenumber, String password, String confirmphone, String typeuser) {
//        Firstname = firstname;
//        Lastname = lastname;
//        this.email = email;
//        this.phonenumber = phonenumber;
//        this.password = password;
//        this.confirmphone = confirmphone;
//        this.typeuser = typeuser;
//    }

///// driver

    public UserType(String firstname, String lastname, String email, String phonenumber,String key,
                    String password, String confirmphone,
                    String birthday, String nationality,
                    String natID, String typeuser) {
        Firstname = firstname;
        Lastname = lastname;
        this.email = email;
        this.phonenumber = phonenumber;
        this.password = password;
        this.confirmphone = confirmphone;
        this.birthday = birthday;
        this.nationality = nationality;
        NatID = natID;
        this.typeuser = typeuser;
        this.key=key;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    /// owner
    public UserType(String firstname, String lastname, String email, String phonenumber,
                    String password, String confirmphone , String typeuser,String key) {
        Firstname = firstname;
        Lastname = lastname;
        this.email = email;
        this.phonenumber = phonenumber;
        this.password = password;
        this.confirmphone = confirmphone;
        this.typeuser = typeuser;
        this.key=key;
    }

    /// user
    public UserType(String firstname, String lastname, String email,
                    String phonenumber, String password, String confirmphone,
                    String nationality, String typeuser, String cityname,
                    String street_name, String nearest_teacher,
                    String home_number,String key) {
        Firstname = firstname;
        Lastname = lastname;
        this.email = email;
        this.phonenumber = phonenumber;
        this.password = password;
        this.confirmphone = confirmphone;
        this.nationality = nationality;
        this.typeuser = typeuser;
        this.cityname = cityname;
        Street_name = street_name;
        this.nearest_teacher = nearest_teacher;
        this.home_number = home_number;
        this.key=key;
    }

    public void setFirstname(String firstname) {
        Firstname = firstname;
    }

    public void setLastname(String lastname) {
        Lastname = lastname;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setConfirmphone(String confirmphone) {
        this.confirmphone = confirmphone;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public void setTypeuser(String typeuser) {
        this.typeuser = typeuser;
    }

    public String getFirstname() {
        return Firstname;
    }

    public String getLastname() {
        return Lastname;
    }

    public String getEmail() {
        return email;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public String getPassword() {
        return password;
    }

    public String getConfirmphone() {
        return confirmphone;
    }

    public String getBirthday() {
        return birthday;
    }

    public String getNationality() {
        return nationality;
    }

    public String getTypeuser() {
        return typeuser;
    }

    @Override
    public String toString() {
        return "UserType{" +
                "Firstname='" + Firstname + '\'' +
                ", Lastname='" + Lastname + '\'' +
                ", email='" + email + '\'' +
                ", phonenumber='" + phonenumber + '\'' +
                ", password='" + password + '\'' +
                ", confirmphone='" + confirmphone + '\'' +
                ", birthday='" + birthday + '\'' +
                ", nationality='" + nationality + '\'' +
                ", NatID='" + NatID + '\'' +
                ", typeuser='" + typeuser + '\'' +
                ", cityname='" + cityname + '\'' +
                ", Street_name='" + Street_name + '\'' +
                ", nearest_teacher='" + nearest_teacher + '\'' +
                ", home_number='" + home_number + '\'' +
                '}';
    }

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname;
    }

    public String getStreet_name() {
        return Street_name;
    }

    public void setStreet_name(String street_name) {
        Street_name = street_name;
    }

    public String getNearest_teacher() {
        return nearest_teacher;
    }

    public void setNearest_teacher(String nearest_teacher) {
        this.nearest_teacher = nearest_teacher;
    }

    public String getHome_number() {
        return home_number;
    }

    public void setHome_number(String home_number) {
        this.home_number = home_number;
    }
}
