package com.example.mylaundry.Model;

import java.util.ArrayList;

public interface ServiesInt {

    void callbackCall( int   position);

   void namelay(String name);

}
