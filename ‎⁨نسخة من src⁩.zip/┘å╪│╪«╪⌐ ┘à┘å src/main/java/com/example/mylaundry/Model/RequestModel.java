package com.example.mylaundry.Model;

import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;

import java.io.Serializable;
import java.util.ArrayList;

public class RequestModel implements Serializable {

    String address;
    ArrayList<Services> data;
    String total;
    String addtax;
    String date;
    String amount;
    String numberRequest ;
    String time ;
    String type ;
    String email;
    String namelaundry;
    String documentId;
    String keyuser;
    String keyowner;
    String keysub;
    String city;

    public RequestModel() {
    }
//
//    public RequestModel(String address, ArrayList<Services> data, String total,
//                        String addtax, String date, String amount, String numberRequest, String time) {
//        this.address = address;
//        this.data = data;
//        this.total = total;
//        this.addtax = addtax;
//        this.date = date;
//        this.amount = amount;
//        this.numberRequest = numberRequest;
//        this.time = time;
//    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getKeysub() {
        return keysub;
    }

    public void setKeysub(String keysub) {
        this.keysub = keysub;
    }

    public RequestModel(String address, ArrayList<Services> data, String total,
                        String addtax, String date, String amount, String numberRequest,
                        String time, String type , String email , String namelaundry) {
        this.address = address;
        this.data = data;
        this.total = total;
        this.addtax = addtax;
        this.date = date;
        this.amount = amount;
        this.numberRequest = numberRequest;
        this.time = time;
        this.type = type;
        this.email=email;
        this.namelaundry=namelaundry;
    }

    public String getKeyuser() {
        return keyuser;
    }

    public void setKeyuser(String keyuser) {
        this.keyuser = keyuser;
    }

    public String getKeyowner() {
        return keyowner;
    }

    public void setKeyowner(String keyowner) {
        this.keyowner = keyowner;
    }

    public String getNamelaundry() {
        return namelaundry;
    }
    public void setNamelaundry(String namelaundry) {
        this.namelaundry = namelaundry;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public ArrayList<Services> getData() {
        return data;
    }

    public void setData(ArrayList<Services> data) {
        this.data = data;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getAddtax() {
        return addtax;
    }

    public void setAddtax(String addtax) {
        this.addtax = addtax;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getNumberRequest() {
        return numberRequest;
    }

    public void setNumberRequest(String numberRequest) {
        this.numberRequest = numberRequest;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    @Override
    public String toString() {
        return "RequestModel{" +
                "address='" + address + '\'' +
                ", data=" + data +
                ", total='" + total + '\'' +
                ", addtax='" + addtax + '\'' +
                ", date='" + date + '\'' +
                ", amount='" + amount + '\'' +
                ", numberRequest='" + numberRequest + '\'' +
                ", time='" + time + '\'' +
                ", type='" + type + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}
