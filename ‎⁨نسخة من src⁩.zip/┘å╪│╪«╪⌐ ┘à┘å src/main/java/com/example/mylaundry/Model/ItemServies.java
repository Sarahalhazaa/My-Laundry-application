package com.example.mylaundry.Model;

import java.io.Serializable;

public class ItemServies implements Serializable {

    String name_servies; /// اسم الخدمة مثلا  بدلة الاطفال
    String type_servies; // نوع الخدمة مثلا ملابس
    String price ; // سعر  كل خدمة
    String servies; //   نوع اسم الخدمة مثلا الكوي
    String id; // الاي دي للخدمة
    String email ;
    String CRo ;    //  رقم التسجيل التجاري
    String name_laundy;

    String selectedPrice;

    public ItemServies( String servies , String price) {

        this.servies = servies;
        this.price = price;
    }


    public ItemServies(  String name_servies , String name_laundy ,String servies , String price) {
    this.name_laundy=name_laundy;
        this.servies = servies;
        this.price = price;
        this.name_servies =name_servies;
    }

//    public ItemServies(String name_servies, String type_servies, String price,
//                       String servies, String id, String email, String CRo) {
//        this.name_servies = name_servies;
//        this.type_servies = type_servies;
//        this.price = price;
//        this.servies = servies;
//        this.id = id;
//        this.email = email;
//        this.CRo = CRo;
//    }

//
//    public ItemServies(String name_servies, String price, String servies) {
//        this.name_servies = name_servies;
//        this.price = price;
//        this.servies = servies;
//    }
//
//    public ItemServies(String name_servies) {
//        this.name_servies = name_servies;
//    }
//
//    public ItemServies(String name_servies, String type_servies, String price,
//                       String servies, String id, String email, String CRo) {
//        this.name_servies = name_servies;
//        this.type_servies = type_servies;
//        this.price = price;
//        this.servies = servies;
//        this.id = id;
//        this.email = email;
//        this.CRo = CRo;
//
//    }

    public String getName_laundy() {
        return name_laundy;
    }

    public void setName_laundy(String name_laundy) {
        this.name_laundy = name_laundy;
    }

    public String getName_servies() {
        return name_servies;
    }

    public void setName_servies(String name_servies) {
        this.name_servies = name_servies;
    }

    public String getType_servies() {
        return type_servies;
    }

    public void setType_servies(String type_servies) {
        this.type_servies = type_servies;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCRo() {
        return CRo;
    }

    public void setCRo(String CRo) {
        this.CRo = CRo;
    }

//    public ItemServies(String name, String price, String id) {
//        this.name_servies = name;
//        this.price = price;
//        this.id = id;
//    }
//
//    public ItemServies(String name, String price, String servies, String id) {
//        this.name_servies = name;
//        this.price = price;
//        this.servies = servies;
//        this.id = id;
//    }

    public ItemServies() {
    }

    public String getName() {
        return name_servies;
    }

    public void setName(String name) {
        this.name_servies = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getServies() {
        return servies;
    }

    public void setServies(String servies) {
        this.servies = servies;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSelectedPrice() {
        return selectedPrice;
    }

    public void setSelectedPrice(String selectedPrice) {
        this.selectedPrice = selectedPrice;
    }

    @Override
    public String toString() {
        return "ItemServies{" +
                "name_servies='" + name_servies + '\'' +
                ", type_servies='" + type_servies + '\'' +
                ", price='" + price + '\'' +
                ", servies='" + servies + '\'' +
                ", id='" + id + '\'' +
                ", email='" + email + '\'' +
                ", CRo='" + CRo + '\'' +
                ", name_laundy='" + name_laundy + '\'' +
                '}';
    }
}
