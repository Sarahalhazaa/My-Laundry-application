package com.example.mylaundry.OwnerActivitys.FragmentOwner;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.mylaundry.ActivitysMore.ModifyData;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.Laundry_accountActivity;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.ServicesOwner;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionsActivity;
import com.example.mylaundry.R;
import com.example.mylaundry.SplashActivity;


public class FragmentMore extends Fragment {

    LinearLayout linearLayout1, linearLayout2, linearLayout3, linearLayout4;

    Button logout;

    PreferencesHelper preferencesHelper;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //   return inflater.inflate(R.layout.fragment_moew, container, false);

        View rootView = inflater.inflate(R.layout.fragment_moew, container, false);


        linearLayout1 = rootView.findViewById(R.id.linera);
        linearLayout2 = rootView.findViewById(R.id.linera2);
        linearLayout3 = rootView.findViewById(R.id.linera3);
        linearLayout4 = rootView.findViewById(R.id.linera1);
        logout=rootView.findViewById(R.id.button8);
        preferencesHelper= new PreferencesHelper(getActivity());

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              getActivity().  finish();
                preferencesHelper.setPREF_USER_DOCID("Null");
              //  preferencesHelper.setIsLogin(false);
                Intent intent = new Intent(getActivity(), SplashActivity.class);
                startActivity(intent);
            }
        });


        linearLayout1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent editdata = new Intent(getActivity(), ModifyData.class);
                startActivity(editdata);

            }
        });

        linearLayout2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent editdata = new Intent(getActivity(), SubscriptionsActivity.class);
                startActivity(editdata);
            }
        });

        linearLayout3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               /// Toast.makeText(getActivity(), "linearLayout3", Toast.LENGTH_SHORT).show();
                Intent editdata = new Intent(getActivity(), ServicesOwner.class);
                startActivity(editdata);
            }
        });



        linearLayout4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

              //  Toast.makeText(getActivity(), "linearLayout3", Toast.LENGTH_SHORT).show();

                Intent editdata = new Intent(getActivity(), Laundry_accountActivity.class);
                startActivity(editdata);


            }
        });


        return rootView;
    }
}