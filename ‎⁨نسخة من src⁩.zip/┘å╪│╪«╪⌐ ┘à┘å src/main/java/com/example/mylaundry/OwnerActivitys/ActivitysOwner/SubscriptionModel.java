package com.example.mylaundry.OwnerActivitys.ActivitysOwner;

import com.example.mylaundry.Model.Services;

import java.io.Serializable;
import java.util.ArrayList;

public class SubscriptionModel implements Serializable {
    String key;
    String name;
    String phone;
    String email;
    String commercial_register_number;
    String Area, Street, duration;
    String Status;

    ArrayList<Services> services;
    String serviceCount;
    String selectedPrice;
    String Evaluation;

    String numberSubscr;

    String nowdate, endDate;

    String typeRequest;
    String type;
    String typeUser;

    String ID;
    String documentId;
    String nationality;

    public SubscriptionModel() {
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public SubscriptionModel(String name, String commercial_register_number,
                             String duration, String nowdate, String endDate, String numberSubscr, String key) {
        this.name = name;
        this.commercial_register_number = commercial_register_number;
        this.duration = duration;
        this.nowdate = nowdate;
        this.endDate = endDate;
        this.numberSubscr = numberSubscr;
        this.key=key;
    }

    public SubscriptionModel(String name, String phone, String email, String area, String duration,
                             String numberSubscr, String nowdate, String endDate, String typeRequest, String type, String ID, String typeUser) {
        this.name = name;
        this.phone = phone;
        this.email = email;
        Area = area;
        this.duration = duration;
        this.numberSubscr = numberSubscr;
        this.nowdate = nowdate;
        this.endDate = endDate;
        this.typeRequest = typeRequest;
        this.type = type;
        this.ID = ID;
        this.typeUser = typeUser;
        this.key=key;
    }

    public SubscriptionModel(String name, String phone, String email,
                             String commercial_register_number, String area,
                             String street, String duration, String status, String evaluation,
                             String nowdate
            , String endDate, String numberSubscr, String typeRequest, String type,String key) {
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.commercial_register_number = commercial_register_number;
        Area = area;
        Street = street;
        this.duration = duration;
        Status = status;
        Evaluation = evaluation;
        this.nowdate = nowdate;
        this.endDate = endDate;
        this.numberSubscr = numberSubscr;
        this.typeRequest = typeRequest;
        this.type = type;
        this.key=key;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getServiceCount() {
        return serviceCount;
    }

    public void setServiceCount(String serviceCount) {
        this.serviceCount = serviceCount;
    }

    public String getTypeRequest() {
        return typeRequest;
    }

    public void setTypeRequest(String typeRequest) {
        this.typeRequest = typeRequest;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTypeUser() {
        return typeUser;
    }

    public void setTypeUser(String typeUser) {
        this.typeUser = typeUser;
    }

    public String getNumberSubscr() {
        return numberSubscr;
    }

    public void setNumberSubscr(String numberSubscr) {
        this.numberSubscr = numberSubscr;
    }

    public String getStreet() {
        return Street;
    }

    public void setStreet(String street) {
        Street = street;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getNowdate() {
        return nowdate;
    }

    public void setNowdate(String nowdate) {
        this.nowdate = nowdate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getEvaluation() {
        return Evaluation;
    }

    public void setEvaluation(String evaluation) {
        Evaluation = evaluation;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCommercial_register_number() {
        return commercial_register_number;
    }

    public void setCommercial_register_number(String commercial_register_number) {
        this.commercial_register_number = commercial_register_number;
    }

    public String getArea() {
        return Area;
    }

    public void setArea(String area) {
        Area = area;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public ArrayList<Services> getServices() {
        return services;
    }

    public void setServices(ArrayList<Services> services) {
        this.services = services;
    }

    public String getSelectedPrice() {
        return selectedPrice;
    }

    public void setSelectedPrice(String selectedPrice) {
        this.selectedPrice = selectedPrice;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    @Override
    public String toString() {
        return "SubscriptionModel{" +
                "name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", email='" + email + '\'' +
                ", commercial_register_number='" + commercial_register_number + '\'' +
                ", Area='" + Area + '\'' +
                ", Street='" + Street + '\'' +
                ", duration='" + duration + '\'' +
                ", Status='" + Status + '\'' +
                ", services=" + services +
                ", selectedPrice='" + selectedPrice + '\'' +
                ", Evaluation='" + Evaluation + '\'' +
                ", numberSubscr='" + numberSubscr + '\'' +
                ", nowdate='" + nowdate + '\'' +
                ", endDate='" + endDate + '\'' +
                ", typeRequest='" + typeRequest + '\'' +
                ", ID='" + ID + '\'' +
                '}';
    }
}
