package com.example.mylaundry.OwnerActivitys.ActivitysOwner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mylaundry.AdapterView.AdapterItem;
import com.example.mylaundry.Model.ItemServies;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.R;
import com.example.mylaundry.SignUp;
import com.example.mylaundry.helpers.BaseActivity;
import com.example.mylaundry.helpers.Constants;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class NewSubscription extends BaseActivity {
    Button new_services;
    ArrayList<Services> serviceslist = new ArrayList<>();
    ArrayList<ItemServies> itemsservies = new ArrayList<>();
    ;

    String[] inputs = new String[]{
            "Clothing ", "carpet", " home"};
    AdapterItem adapterItem;

    Spinner spino, spinner;

    String[] duration = new String[]{"6 months", "One year"};

    String[] Area = {"Al-Suwaidi district", "Al-Nafl district", "Al-Awali district", "Al-Yasmeen district",
            "Al-Mursalat District", "Al-Sahafah district", "Al-Sahafah district", "Al-Yarmouk district"};


    AutoCompleteTextView autoCompleteTextView;
    EditText name, phone, email, Registration_No, Street;
    Button done;
    PreferencesHelper preferencesHelper;
    private FirebaseAuth mAuth;
    RecyclerView recyclerView;
    FirebaseFirestore db;

    int mintegerone = 0;
    int mintegerTwo = 0;
    int mintegerThree = 0;
    int mintegerFore = 0;
    String textposition;
    LocalDate enddate;
    EditText nameservices;
    EditText number;

    @TargetApi(Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_subscription);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        init();

        spinner = findViewById(R.id.spinner2);
        ArrayAdapter ad1
                = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, duration);//        holder.inputLayout.setAdapter(adapter);
        ad1.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(ad1);
        // duration[0] = "Select  duration";
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int mPosition, long id) {

                if (spinner.getSelectedItem().equals("6 months")) {

                    enddate = LocalDate.now().plusMonths(6);


                    Log.d("date", "onCreate: " + LocalDate.now().plusMonths(6));
                } else if (spinner.getSelectedItem().equals("One year")) {
                    Log.d("date", "onCreate:year " + LocalDate.now().plusMonths(12));

                    enddate = LocalDate.now().plusMonths(12);


                }

                // Toast.makeText(getApplicationContext(), duration.get(mPosition), Toast.LENGTH_LONG).show();
            }


            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });


        spino = findViewById(R.id.spinner);

        ArrayAdapter ad
                = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, Area);//        holder.inputLayout.setAdapter(adapter);
        ad.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        spino.setAdapter(ad);
        Area[0] = "Select  Neighborhood";
        spino.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int mPosition, long id) {

                // Toast.makeText(getApplicationContext(), Area.get(mPosition), Toast.LENGTH_LONG).show();
            }


            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        recyclerView = findViewById(R.id.recycler);


        new_services = findViewById(R.id.button11);

        new_services.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dialog = new Dialog(NewSubscription.this, R.style.WideDialog);
                dialog.setContentView(R.layout.new_servicesitem);
                ColorDrawable dialogColor = new ColorDrawable(Color.WHITE);
                dialogColor.setAlpha(50);
                dialog.getWindow().setBackgroundDrawable(dialogColor);
                nameservices = dialog.findViewById(R.id.edit_passconfirm);
                number = dialog.findViewById(R.id.editTextTextPersonName2);
                Spinner spino = dialog.findViewById(R.id.spinner);

                ArrayAdapter ad
                        = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, inputs);//        holder.inputLayout.setAdapter(adapter);
                ad.setDropDownViewResource(
                        android.R.layout.simple_spinner_dropdown_item);

                spino.setAdapter(ad);
                spino.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        Toast.makeText(getApplicationContext(), inputs[position], Toast.LENGTH_LONG).show();
                        textposition = inputs[position];
                        textposition = spino.getSelectedItem().toString();

                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });


                TextView number_laundry = dialog.findViewById(R.id.number_laundry);
                TextView number_presser = dialog.findViewById(R.id.number_presser);
                TextView number_IiRON = dialog.findViewById(R.id.number_IiRON);
                TextView number_steam = dialog.findViewById(R.id.number_steam);


                CheckBox checklaundry = dialog.findViewById(R.id.checklaundry);
                CheckBox checkpresser = dialog.findViewById(R.id.checkpresser);
                CheckBox checkIron = dialog.findViewById(R.id.checkIron);
                CheckBox checkIron2 = dialog.findViewById(R.id.checkIron2);
                //one
                Button increase = dialog.findViewById(R.id.increase);
                Button decrease = dialog.findViewById(R.id.decrease);
                //two
                Button increase2 = dialog.findViewById(R.id.increase2);
                Button decrease1 = dialog.findViewById(R.id.decrease1);
                // three
                Button decrease2 = dialog.findViewById(R.id.decrease2);
                Button increase3 = dialog.findViewById(R.id.increase3);
               // foree
                Button decrease3 = dialog.findViewById(R.id.decrease3);
                Button increase4 = dialog.findViewById(R.id.increase4);


                increase.setOnClickListener(v1 -> {
                    mintegerone = mintegerone + 1;
                    number_laundry.setText("" + mintegerone);
                });
                decrease.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mintegerone = mintegerone - 1;
                        number_laundry.setText("" + mintegerone);
                    }
                });

                increase2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mintegerTwo = mintegerTwo + 1;
                        number_presser.setText("" + mintegerTwo);
                    }
                });

                decrease1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mintegerTwo = mintegerTwo - 1;
                        number_presser.setText("" + mintegerTwo);
                    }
                });


                decrease2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mintegerThree = mintegerThree - 1;
                        number_IiRON.setText("" + mintegerThree);
                    }
                });

                increase3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mintegerThree = mintegerThree + 1;
                        number_IiRON.setText("" + mintegerThree);
                    }
                });


                decrease3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mintegerFore = mintegerFore - 1;
                        number_steam.setText("" + mintegerFore);
                    }
                });

                increase4.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mintegerFore = mintegerFore + 1;
                        number_steam.setText("" + mintegerFore);
                    }
                });


                Button ok = dialog.findViewById(R.id.edit);
                ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (nameservices.getText().toString().isEmpty()||number.getText().toString().isEmpty()){
                      Toast.makeText(NewSubscription.this, " Enter Your Data", Toast.LENGTH_SHORT).show();
                        }
                        else {

                            if (checklaundry.isChecked()) {
                                //itemsservies.add();

                                ItemServies itemServiesobject = new ItemServies(

                                        nameservices.getText().toString(), name.getText().toString(), checklaundry.getText().toString(), number_laundry.getText().toString()
                                );
                                itemServiesobject.setType_servies(spino.getSelectedItem().toString());

                                itemsservies.add(itemServiesobject);


                            }
                            if (checkpresser.isChecked()) {


                                ItemServies itemServiesobject = new ItemServies(
                                        nameservices.getText().toString(), name.getText().toString(), checkpresser.getText().toString(), number_presser.getText().toString()
                                );
                                itemServiesobject.setType_servies(spino.getSelectedItem().toString());

                                itemsservies.add(itemServiesobject);


                            }
                            if (checkIron.isChecked()) {

                                ItemServies itemServiesobject = new ItemServies(
                                        nameservices.getText().toString(), name.getText().toString(),
                                        checkIron.getText().toString()
                                        , number_IiRON.getText().toString()

                                );
//                            ItemServies itemServiesobject = new ItemServies(nameservices.getText().toString(),
//                                    textposition,
//                                    number_IiRON.getText().toString(),
//                                    checkIron.getText().toString(),
//                                    " ",
//                                    email.getText().toString(),
//                                    Registration_No.getText().toString() );

//                            ItemServies itemServies = new ItemServies(nameservices.getText().toString(),
//                                    number_IiRON.getText().toString(), checkIron.getText().toString(), textposition);
                                itemServiesobject.setType_servies(spino.getSelectedItem().toString());

                                itemsservies.add(itemServiesobject);


//                            db.collection("ItemServies")
//                                    .add(itemServiesobject)
//                                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
//                                        @Override
//                                        public void onSuccess(DocumentReference documentReference) {
//
//                                            Log.d("TAG", "DocumentSnapshot written with ID: " + documentReference.getId());
//
//                                        }
//                                    })
//                                    .addOnFailureListener(new OnFailureListener() {
//                                        @Override
//                                        public void onFailure(@NonNull Exception e) {
//                                            Log.w("TAG", "Error adding document", e);
//
//
//                                        }
//                                    });


                            }
                            if (checkIron2.isChecked()) {
                                ItemServies itemServiesobject = new ItemServies(
                                        nameservices.getText().toString(),
                                        name.getText().toString(),
                                        checkIron2.getText().toString(),
                                        number_steam.getText().toString()
                                );
                                itemServiesobject.setType_servies(spino.getSelectedItem().toString());

                                itemsservies.add(itemServiesobject);

                            }


                            recyclerView.setHasFixedSize(true);
                            recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                            adapterItem = new AdapterItem(NewSubscription.this, itemsservies);
                            recyclerView.setAdapter(adapterItem);
                            dialog.cancel();
                        }

                    }
                });

                dialog.show();

            }
        });


        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (name.getText().toString().isEmpty()) {
                    name.setError("name is empty");
                    return;
                }
                if (phone.getText().toString().isEmpty()){
                    phone.setError("phone is empty");
                    return;
                }
                if (phone.getText().toString().length()<8){
                    phone.setError("You must enter 8 numbers");
                    return;
                }
                if (email.getText().toString().isEmpty()){
                    email.setError("email is empty");
                    return;
                }
                if (Registration_No.getText().toString().isEmpty()){
                    Registration_No.setError("enter Registration No ");
                   return;
                }
                if (Registration_No.getText().toString().length()<10){
                    Registration_No.setError("You must enter 10 numbers");
                    return;
                }
                 if (!Patterns.EMAIL_ADDRESS.matcher(email.getText().toString().trim()).matches()) {
                    email.setError("Not valid email");
                    return;
                }  if (itemsservies.isEmpty()) {
                    Toast.makeText(NewSubscription.this, "Please enter the required services", Toast.LENGTH_SHORT).show();
                    return;
                 }
                  if (spinner.getSelectedItem().equals("Select  duration")) {
                    new SweetAlertDialog(NewSubscription.this)
                            .setTitleText("Sorry, Select  duration ")
                            .show();
                        return;

                }  if (spino.getSelectedItem().equals("Select  Neighborhood")) {
                    new SweetAlertDialog(NewSubscription.this)
                            .setTitleText("Sorry, Select  Area ")
                            .show();
                    return;
                }
                  else {

                    Random r = new Random();
                    int randomNumber = r.nextInt(100);
                    String random = Integer.toString(randomNumber);
                    LocalDate date = LocalDate.now();
                    Log.d("date", "onClick: " + date.toString());

                    SubscriptionModel subscriptionModel = new SubscriptionModel(
                            name.getText().toString(),
                            phone.getText().toString(),
                            email.getText().toString(),
                            Registration_No.getText().toString(),
                            spino.getSelectedItem().toString(),
                            Street.getText().toString(),
                            spinner.getSelectedItem().toString(),
                            "not available",
                            "0",
                            LocalDate.now().toString(),
                            enddate.toString(),
                            random,
                            "wait",
                            Constants.NEW,mAuth.getUid()
                    );
                    subscriptionModel.setServiceCount("1");
                    subscriptionModel.setType("NEW");
                    //db.collection(spino.getSelectedItem().toString()+"Subscription").add(subscriptionModel);
                    db.collection("Subscription")
                            .add(subscriptionModel)
                            .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                @Override
                                public void onSuccess(DocumentReference documentReference) {
                                    Log.d("TAG", "DocumentSnapshot written with ID: " + documentReference.getId());
                                    Map<String, Object> Subscription = new HashMap<>();
                                    Subscription.put("documentId", documentReference.getId());
                                    db.collection("Subscription").document(documentReference.getId())
                                                    .set(Subscription, SetOptions.merge())
                                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@androidx.annotation.NonNull Task<Void> task) {

                                                }
                                            });

                                    preferencesHelper.setPREF_subscription_DOCID(documentReference.getId());
                                    Services serviceser = new Services(textposition
                                            , name.getText().toString(),
                                            email.getText().toString(),
                                            itemsservies
                                            , nameservices.getText().toString()
                                            , number.getText().toString());
                                            serviceser.setKeysub(documentReference.getId());

                                   // db.collection(spino.getSelectedItem().toString()+"Services").add(serviceser);
                                    db.collection("Services")
                                            .add(serviceser).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                                @Override
                                                public void onSuccess(DocumentReference documentReference) {
                                                    Map<String, Object> servies = new HashMap<>();
                                                    servies.put("documentId", documentReference.getId());
                                                    db.collection("Services").document(documentReference.getId())
                                                            .set(servies, SetOptions.merge())
                                                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                @Override
                                                                public void onComplete(@androidx.annotation.NonNull Task<Void> task) {
                                                                    Intent intent = new Intent(getApplicationContext(), SubscriptionsActivity.class);
                                                                    startActivity(intent);
                                                                    finish();
                                                                    Toast.makeText(NewSubscription.this, " DONE", Toast.LENGTH_SHORT).show();

                                                                }
                                                            });

                                                }
                                            });



                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.w("TAG", "Error adding document", e);


                                }
                            });


                }


            }
        });


//


    }


    void init() {
        name = findViewById(R.id.edit_name);
        phone = findViewById(R.id.edtiphone);
        email = findViewById(R.id.edit_mail);
        Registration_No = findViewById(R.id.edit_mail2);
        preferencesHelper = new PreferencesHelper(getApplicationContext());
        done = findViewById(R.id.button12);
        Street = findViewById(R.id.editTextTextPersonName);

    }


}