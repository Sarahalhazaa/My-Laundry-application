package com.example.mylaundry.OwnerActivitys;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;

import com.example.mylaundry.OwnerActivitys.FragmentOwner.FragmentStatus;
import com.example.mylaundry.OwnerActivitys.FragmentOwner.FragmentHome;
import com.example.mylaundry.OwnerActivitys.FragmentOwner.FragmentMore;
import com.example.mylaundry.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainOwner extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_owner);


        BottomNavigationView bottomNav = findViewById(R.id.Owner_navigatin_view);
        bottomNav.setOnNavigationItemSelectedListener(navListener);

        getSupportFragmentManager().beginTransaction().replace(R.id.Owner_container, new FragmentHome()).commit();

    }


    private final BottomNavigationView.OnNavigationItemSelectedListener navListener = item -> {
        // By using switch we can easily get
        // the selected fragment
        // by using there id.
        Fragment selectedFragment = null;
        int itemId = item.getItemId();
        if (itemId == R.id.homeowner) {
            selectedFragment = new FragmentHome();
        } else if (itemId == R.id.status) {
            selectedFragment = new FragmentStatus();
        } else if (itemId == R.id.moreowner) {
            selectedFragment = new FragmentMore();
        }
        // It will help to replace the
        // one fragment to other.
        if (selectedFragment != null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.Owner_container, selectedFragment).commit();
        }
        return true;
    };


}