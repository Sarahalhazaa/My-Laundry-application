package com.example.mylaundry.OwnerActivitys.ActivitysOwner;

public interface onClickadd {
    public void onclickadd(String key,String name,String email);




}
