package com.example.mylaundry.OwnerActivitys.ActivitysOwner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.mylaundry.Model.Services;
import com.example.mylaundry.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;
import java.util.List;

public class ServicesActivity extends AppCompatActivity {
    String  name  , email;
    ArrayList<Services> servicesArrayList;
    FirebaseFirestore db;
    FirebaseAuth auth ;
    RecyclerView recyclerview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services);
            auth=FirebaseAuth.getInstance();
          name = getIntent().getStringExtra("name");
          email = getIntent().getStringExtra("email");
        db = FirebaseFirestore.getInstance();
        recyclerview=findViewById(R.id.recyclerview);


        db.collection(auth.getUid()+"Services").get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        if (!queryDocumentSnapshots.isEmpty()) {
                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                            for (DocumentSnapshot d : list) {
                                 Services s = d.toObject(Services.class);
                                servicesArrayList.add(s);
                                Log.d("TAG", "onSuccess: " + s.getItemsservies());

                            }
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // if we do not get any data or any error we are displaying
                        // a toast message that we do not get any data
                        Toast.makeText(getApplicationContext(), "Fail to get the data.", Toast.LENGTH_SHORT).show();
                    }
                });


//
//        recyclerview.setHasFixedSize(true);
//        recyclerview.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
//        servicesadapter =new AdaperServices(ServicesOwner.this, st);
//
//        recyclerview.setAdapter(servicesadapter);











    }
}