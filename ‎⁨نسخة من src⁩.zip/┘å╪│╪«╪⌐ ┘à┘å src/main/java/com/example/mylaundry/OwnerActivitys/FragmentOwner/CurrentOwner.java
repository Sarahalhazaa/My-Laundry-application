package com.example.mylaundry.OwnerActivitys.FragmentOwner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Toast;

import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.NewOrdersOwner;
import com.example.mylaundry.R;
import com.example.mylaundry.databinding.ActivityCurrentOwnerBinding;
import com.example.mylaundry.databinding.ActivityNewOrdersOwnerBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class CurrentOwner extends AppCompatActivity {
ActivityCurrentOwnerBinding binding;
    AdapterNewOrderOwner adapterNewOrderOwner;
    ArrayList<RequestModel> st;
    FirebaseFirestore db;
    RequestModel requestModel;
    FirebaseAuth auth=FirebaseAuth.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= DataBindingUtil.setContentView(this,R.layout.activity_current_owner);

        db = FirebaseFirestore.getInstance();
        st = new ArrayList<>();
        binding.rec.setHasFixedSize(true);
        binding.rec.setLayoutManager(new LinearLayoutManager(this));
        adapterNewOrderOwner = new AdapterNewOrderOwner(this,st,1);
        binding.rec.setAdapter(adapterNewOrderOwner);
    }


    void getData() {
        db.collection("RequestModel").whereEqualTo("keyowner",auth.getUid()).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        if (!queryDocumentSnapshots.isEmpty()) {
                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                            for (DocumentSnapshot d : list) {
                                // preferencesHelper.setPREF_Item_Update(d.getId());

                                requestModel = d.toObject(RequestModel.class);
                                if (requestModel.getType().equals("request received")){
                                    st.add(requestModel);

                                }
                                else {

                                }
                            }
                            adapterNewOrderOwner.update(st);

                        } else {

                            Toast.makeText(CurrentOwner.this, "No data found ", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(e -> {
                    // if we do not get any data or any error we are displaying
                    // a toast message that we do not get any data
                    Toast.makeText(CurrentOwner.this, "Fail to get the data.", Toast.LENGTH_SHORT).show();
                });


    }

    @Override
    protected void onStart() {
        super.onStart();
        getData();
    }
}