package com.example.mylaundry.OwnerActivitys.FragmentOwner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mylaundry.AdapterView.AdapterOrder;
import com.example.mylaundry.AdapterView.ModelArray;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.R;
import com.example.mylaundry.databinding.ActivityAcceptedOwnerBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.kofigyan.stateprogressbar.StateProgressBar;
import com.kofigyan.stateprogressbar.components.StateItem;
import com.kofigyan.stateprogressbar.listeners.OnStateItemClickListener;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;

public class AcceptedOwner extends AppCompatActivity {
ActivityAcceptedOwnerBinding binding;
    ArrayList<RequestModel> requestModels;


    ArrayList<Services> services;
    AdapterOrder adapterCon;
    FirebaseFirestore firestore;
    ModelArray model;
    AdapterOrder adapterOrder;
    PreferencesHelper preferencesHelper;
    String[] descriptionData = {"Waiting for request", "request accepted",
            "Items received", "Items have been delivered to the laundromat", "Delivered"};
    String EMAIL,NAME;
    ModelArray modelArray;
    String Status_Order;
    int TypeOrder ;
    String decomentid;
    String keyuser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= DataBindingUtil.setContentView(this,R.layout.activity_accepted_owner);

        EMAIL =getIntent().getStringExtra("EMAIL");
        firestore = FirebaseFirestore.getInstance();
        decomentid=getIntent().getStringExtra("dec");
        keyuser=getIntent().getStringExtra("keyuser");
        NAME=getIntent().getStringExtra("NAME");

        TypeOrder=getIntent().getIntExtra("TypeOrder",0);


        switch(TypeOrder) {
            case 0:
                binding.button18.setVisibility(View.VISIBLE);
                binding.button19.setVisibility(View.GONE);
                binding.button20.setVisibility(View.GONE);

                break;
            case 1:
               binding.button18.setVisibility(View.GONE);
                binding.button19.setVisibility(View.VISIBLE);
                binding.button19.setText("Done Service");
                binding.button20.setVisibility(View.GONE);
                break;
            case 2:
                binding.button18.setVisibility(View.GONE);
                binding.button19.setVisibility(View.GONE);
                binding.button20.setVisibility(View.GONE);

                break;
        }

        binding.button18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                firestore.collection("RequestModel").document(decomentid)
                        .update("type","request received" );

                onBackPressed();
            }
        });
        binding.button19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                firestore.collection("RequestModel").document(decomentid)
                        .update("type","request finished" );


                onBackPressed();
//                TypeOrder = 2 ;
//                finish();
//                startActivity(getIntent());



            }
        });

        binding.button20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firestore.collection("RequestModel").document(decomentid)
                        .update("type","Delivered" );

                onBackPressed();

            }
        });






        modelArray = (ModelArray) getIntent().getSerializableExtra("DataOrder");
        Log.d("order", "onCreate: " + modelArray.getOrder());

      //  Toast.makeText(this, ""+NAME, Toast.LENGTH_SHORT).show();



        preferencesHelper = new PreferencesHelper(this);

        binding.recyclerView.setHasFixedSize(true);

        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapterOrder = new AdapterOrder(this, modelArray.getOrderData());

        binding.recyclerView.setAdapter(adapterOrder);

        binding.textView70.setText("request accepted");
        StateProgressBar stateProgressBar = findViewById(R.id.your_state_progress_bar_id);
        stateProgressBar.setOnStateItemClickListener(new OnStateItemClickListener() {
            @Override
            public void onStateItemClick(StateProgressBar stateProgressBar, StateItem stateItem, int stateNumber, boolean isCurrentState) {
                Toast.makeText(getApplicationContext(), "state Clicked Number is "
                        + stateNumber, Toast.LENGTH_LONG).show();
            }
        });



        String name = getIntent().getStringExtra("namela");
        binding.namelaundryorder.setText(name);
        String totall = getIntent().getStringExtra("total");
        binding.totalnumber.setText(totall);
        String Addtax = getIntent().getStringExtra("addtax");
        binding.totalprice.setText(Addtax);
        String Amount = getIntent().getStringExtra("amount");
        binding.totalp.setText(Amount);
        String Nu = getIntent().getStringExtra("number");
        binding.textView33.setText(Nu);
        model = (ModelArray) getIntent().getSerializableExtra("getdata");

        firestore.collection("user")
                .whereEqualTo("key", keyuser)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (DocumentSnapshot document : task.getResult()) {
                                String street_name = document.getString("street_name");
                                String nearest_teacher = document.getString("nearest_teacher");
                                String cityname = document.getString("cityname");
                                Status_Order=document.getString("type");
                                Log.d("khadijat", "onCreate: "+ street_name );
                                Log.d("khadijat", "onCreate: "+ nearest_teacher );

                                binding.textView76.setText("Neighborhood :" +cityname);
                                binding.textView81.setText("Street name  :" +street_name);
                                binding.textView82.setText("nearest_teacher :" +nearest_teacher);
                                binding.textView78.setText("name :" +name);

//                                password = document.getString("password");
//                                pass = Integer.parseInt(password);

//                                Log.d("date", "onComplete: " + email);
//                                Log.d("date", "onComplete: " + numberphone);
//                                Log.d("date", "onComplete: " + name);
//                                et_name.setHint(name + "" + namelast);
//                                et_email.setHint(email);
//                                et_phone.setHint(numberphone);


                            }
                        } else {
                            Log.d("TAG", "Error getting documents: ", task.getException());
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("INDEXXX", e.toString());
                    }
                });




        firestore.collection("Subscription")
                .whereEqualTo("name", NAME)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (DocumentSnapshot document : task.getResult()) {
                                String name = document.getString("name");
                                String area = document.getString("area");
                                String street = document.getString("street");
                                Toast.makeText(AcceptedOwner.this, ""+name, Toast.LENGTH_SHORT).show();
                                binding.textView78.setText("Neighborhood :" +name);
                                binding.textView79.setText("Street name  :" +area);
                                binding.textView80.setText("nearest_teacher :" +street);

//                                password = document.getString("password");
//                                pass = Integer.parseInt(password);
//
//                                Log.d("date", "onComplete: " + email);
//                                Log.d("date", "onComplete: " + numberphone);
//                                Log.d("date", "onComplete: " + name);
//                                et_name.setHint(name + "" + namelast);
//                                et_email.setHint(email);
//                                et_phone.setHint(numberphone);


                            }
                        } else {
                            Log.d("TAG", "Error getting documents: ", task.getException());
                            Toast.makeText(AcceptedOwner.this, ""+task.getException(), Toast.LENGTH_SHORT).show();

                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("INDEXXX", e.toString());
                        Toast.makeText(AcceptedOwner.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });




    }



}