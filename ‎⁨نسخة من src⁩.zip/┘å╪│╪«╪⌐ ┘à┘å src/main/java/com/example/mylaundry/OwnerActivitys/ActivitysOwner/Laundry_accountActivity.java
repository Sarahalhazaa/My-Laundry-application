package com.example.mylaundry.OwnerActivitys.ActivitysOwner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.mylaundry.AdapterOwner.AdapterAccountLaundry;
import com.example.mylaundry.AdapterView.AdapterServices;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;
import java.util.List;

public class Laundry_accountActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    AdapterAccountLaundry adapterAccountLaundry;
    FirebaseFirestore db;
    FirebaseAuth auth;
    ArrayList<SubscriptionModel> st;
    PreferencesHelper preferencesHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_laundry_account);
        auth =FirebaseAuth.getInstance();

        recyclerView = findViewById(R.id.RecyclerView);
        db = FirebaseFirestore.getInstance();
        st = new ArrayList<>();
        preferencesHelper =new PreferencesHelper(this);

        getData();
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(Laundry_accountActivity.this));
        adapterAccountLaundry = new AdapterAccountLaundry(Laundry_accountActivity.this, st);
        recyclerView.setAdapter(adapterAccountLaundry);


        

      



    }
    
    
   void  getData(){
       db.collection("Subscription").whereEqualTo("key",auth.getUid()).get()
               .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                   @SuppressLint("NotifyDataSetChanged")
                   @Override
                   public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                       if (!queryDocumentSnapshots.isEmpty()) {
                           List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                           for (DocumentSnapshot d : list) {
                               SubscriptionModel subscriptionModel = d.toObject(SubscriptionModel.class);
                               //  Log.d("Data", "onSuccess: " + deviceDetails.getUsername());
                               preferencesHelper.setPREF_Item_Update(d.getId());
                               st.add(subscriptionModel);
                               //recyclerView.setHasFixedSize(true);
                           }
                           adapterAccountLaundry.update2(st);
                       } else {
                           Log.d("TAG", "onSuccess: ");}}
               }).addOnFailureListener(new OnFailureListener() {
                   @Override
                   public void onFailure(@NonNull Exception e) {
                       // if we do not get any data or any error we are displaying
                       // a toast message that we do not get any data
                       Toast.makeText(Laundry_accountActivity.this, "Fail to get the data.", Toast.LENGTH_SHORT).show();
                   }
               });

   }
}