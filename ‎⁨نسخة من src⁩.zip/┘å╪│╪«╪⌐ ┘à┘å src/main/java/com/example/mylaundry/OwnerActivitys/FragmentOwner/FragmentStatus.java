package com.example.mylaundry.OwnerActivitys.FragmentOwner;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.mylaundry.AdapterOwner.AdapterAccountLaundry;
import com.example.mylaundry.AdapterOwner.AdapterStauts;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.Laundry_accountActivity;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;
import java.util.List;


public class FragmentStatus extends Fragment {

    RecyclerView recyclerView;
    AdapterStauts adapterStauts;
    FirebaseFirestore db;
    PreferencesHelper preferencesHelper;
    ArrayList<SubscriptionModel> st;
    FirebaseAuth auth;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_basket_owner, container, false);
        recyclerView = rootView.findViewById(R.id.recyclerviewon);
        db = FirebaseFirestore.getInstance();
        auth=FirebaseAuth.getInstance();
        preferencesHelper = new PreferencesHelper(getActivity());
        st = new ArrayList<>();
        getData();
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapterStauts = new AdapterStauts(getActivity(), st);
        recyclerView.setAdapter(adapterStauts);

        return rootView;
    }


    void getData() {
        db.collection("Subscription").whereEqualTo("key",auth.getUid()).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        if (!queryDocumentSnapshots.isEmpty()) {
                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                            for (DocumentSnapshot d : list) {
                                SubscriptionModel subscriptionModel = d.toObject(SubscriptionModel.class);
                                subscriptionModel.setID(d.getId());
                                preferencesHelper.setPREF_Stuts_DOCID(d.getId());
                                if (subscriptionModel.getType().equals("PREVIOUS")){

                                }
                                else {
                                    st.add(subscriptionModel);
                                }
                            }
                            adapterStauts.update2(st);
                        } else {
                            Log.d("TAG", "onSuccess: ");
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // if we do not get any data or any error we are displaying
                        // a toast message that we do not get any data
                        Toast.makeText(getActivity(), "Fail to get the data.", Toast.LENGTH_SHORT).show();
                    }
                });

    }


}