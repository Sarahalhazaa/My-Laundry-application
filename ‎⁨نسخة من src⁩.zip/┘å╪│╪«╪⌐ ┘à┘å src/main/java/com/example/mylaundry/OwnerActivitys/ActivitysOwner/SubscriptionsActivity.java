package com.example.mylaundry.OwnerActivitys.ActivitysOwner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.mylaundry.AdapterView.AdapterViewSubscription;
import com.example.mylaundry.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;
import java.util.List;

public class SubscriptionsActivity extends AppCompatActivity {

    Button Subscription;
    RecyclerView recyclerView;
AdapterViewSubscription adapterViewSubscription ;
    FirebaseFirestore db;
    ArrayList<SubscriptionModel> st;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_data);
        mAuth = FirebaseAuth.getInstance();
        recyclerView =findViewById(R.id.recycler);
        Subscription = findViewById(R.id.button9);
        Subscription.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Subscription = new Intent(getApplicationContext(), NewSubscription.class);
                startActivity(Subscription);
            }
        });

        db = FirebaseFirestore.getInstance();



        st = new ArrayList<>();


        db.collection("Subscription").whereEqualTo("key",mAuth.getUid()).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        if (!queryDocumentSnapshots.isEmpty()) {
                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                            for (DocumentSnapshot d : list) {
                                SubscriptionModel subscriptionModel = d.toObject(SubscriptionModel.class);
                              //  Log.d("Data", "onSuccess: " + deviceDetails.getUsername());
                           //     st.clear();
                                if(subscriptionModel.getType().equals("PREVIOUS")){

                                }
                                else {
                                    st.add(subscriptionModel);
                                    //recyclerView.setHasFixedSize(true);
                                }
                            }
                            adapterViewSubscription.notifyDataSetChanged();
                        } else {
                            Toast.makeText(getApplicationContext(), "No data found ", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // if we do not get any data or any error we are displaying
                        // a toast message that we do not get any data
                        Toast.makeText(getApplicationContext(), "Fail to get the data.", Toast.LENGTH_SHORT).show();
                    }
                });


        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        adapterViewSubscription =new AdapterViewSubscription(SubscriptionsActivity.this, st);
        recyclerView.setAdapter(adapterViewSubscription);

















    }
}