package com.example.mylaundry.OwnerActivitys.ActivitysOwner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.PerformanceHintManager;
import android.util.Log;
import android.widget.Toast;

import com.example.mylaundry.AcivitysOfLaundry.ViewAllOfLaundry;
import com.example.mylaundry.AdapterView.AdapterOfServices;
import com.example.mylaundry.AdapterView.AdapterServices;
import com.example.mylaundry.AdapterView.AdapterViewSubscription;
import com.example.mylaundry.AdapterView.AdpterOfownerLaundry;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;
import java.util.List;

public class ServicesOwner extends AppCompatActivity {

    RecyclerView recyclerView;
    FirebaseAuth auth;
    AdpterOfownerLaundry adpterOfownerLaundry;
    FirebaseFirestore db;
    ArrayList<SubscriptionModel> st;
    PreferencesHelper preferencesHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services_owner);
    auth=FirebaseAuth.getInstance();

        recyclerView = findViewById(R.id.recyclerview);
        db = FirebaseFirestore.getInstance();

        st = new ArrayList<>();

        preferencesHelper = new PreferencesHelper(this);


        db.collection("Subscription").whereEqualTo("key",auth.getUid()).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        if (!queryDocumentSnapshots.isEmpty()) {
                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                            for (DocumentSnapshot d : list) {
                                SubscriptionModel subscriptionModel = d.toObject(SubscriptionModel.class);
                                //  Log.d("Data", "onSuccess: " + deviceDetails.getUsername());
                                //     st.clear();
                                if (subscriptionModel.getType().equals("PREVIOUS")){

                                }else {
                                    st.add(subscriptionModel);
                                }
                                //recyclerView.setHasFixedSize(true);

                            }
                            adpterOfownerLaundry.notifyDataSetChanged();
                        } else {
                            Toast.makeText(getApplicationContext(), "No data found ", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // if we do not get any data or any error we are displaying
                        // a toast message that we do not get any data
                        Toast.makeText(getApplicationContext(), "Fail to get the data.", Toast.LENGTH_SHORT).show();
                    }
                });



        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(ServicesOwner.this));
        adpterOfownerLaundry = new AdpterOfownerLaundry(ServicesOwner.this, st);
        recyclerView.setAdapter(adpterOfownerLaundry);
//


    }
}