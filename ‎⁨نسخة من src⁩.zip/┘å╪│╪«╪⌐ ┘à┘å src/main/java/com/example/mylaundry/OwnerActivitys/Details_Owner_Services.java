package com.example.mylaundry.OwnerActivitys;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mylaundry.AdapterView.AdapterItem;
import com.example.mylaundry.AdapterView.AdapterOfServices;
import com.example.mylaundry.AdapterView.AdpterOfownerLaundry;
import com.example.mylaundry.Model.ItemServies;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.NewSubscription;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.ServicesOwner;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionsActivity;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.onClickadd;
import com.example.mylaundry.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.SetOptions;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Details_Owner_Services extends AppCompatActivity implements onClickadd {

    RecyclerView recyclerView;
    ArrayList<Services> servicesArrayList;
    String email;
    FirebaseAuth auth;
    int mintegerTwo = 0;
    int mintegerThree = 0;
    int mintegerFore = 0;
    int mintegerone = 0;
    FirebaseFirestore db;
    PreferencesHelper preferencesHelper;
    AdapterOfServices adapterOfServices;
    String textposition;
    ArrayList<ItemServies> itemsservies = new ArrayList<>();
    String numberphone;
    String[] inputs = new String[]{
            "Clothing ", "carpet", " home"};
    Button button14;
    String num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_owner_services);
        auth=FirebaseAuth.getInstance();
        email = getIntent().getStringExtra("email");
         num=getIntent().getStringExtra("num");
        String name=getIntent().getStringExtra("name");
        numberphone=getIntent().getStringExtra("numberphone");
        db = FirebaseFirestore.getInstance();
        preferencesHelper = new PreferencesHelper(this);
        servicesArrayList = new ArrayList<>();
        Log.d("TAGtest", "onCreate:  email " + email);

        button14=findViewById(R.id.button14);

        recyclerView = findViewById(R.id.RecyclerView);
        adapterOfServices = new AdapterOfServices( servicesArrayList,this);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false));
        recyclerView.setAdapter(adapterOfServices);
        button14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openserv(num,name,email);
            }
        });

        db.collection("Services").whereEqualTo("keysub",num)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        for (DocumentSnapshot documentSnapshot : queryDocumentSnapshots.getDocuments()) {
                            Services services = documentSnapshot.toObject(Services.class);
                            //Log.e("response", "services: " + services);
                          //  preferencesHelper.setPREF_Owner_del(documentSnapshot.getId());
                            //servicesArrayList.clear();
                            servicesArrayList.add(services);
                        }
                        adapterOfServices.update(servicesArrayList);
                    } else {
                        Toast.makeText(this, "No data found ", Toast.LENGTH_SHORT).show();
                    }
                }).addOnFailureListener(e -> {
                    Toast.makeText(this, "Fail to get the data.", Toast.LENGTH_SHORT).show();
                });






    }

    @Override
    public void onclickadd(String key,String name,String emails) {
        openserv(key,name,emails);
    }

    private void openserv(String key,String name,String email) {

        final Dialog dialog = new Dialog(Details_Owner_Services.this, R.style.WideDialog);
        dialog.setContentView(R.layout.new_servicesitem);
        ColorDrawable dialogColor = new ColorDrawable(Color.WHITE);
        dialogColor.setAlpha(50);
        dialog.getWindow().setBackgroundDrawable(dialogColor);
        EditText nameservices = dialog.findViewById(R.id.edit_passconfirm);
        EditText number = dialog.findViewById(R.id.editTextTextPersonName2);
        Spinner spino = dialog.findViewById(R.id.spinner);

        ArrayAdapter ad = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, inputs);//        holder.inputLayout.setAdapter(adapter);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spino.setAdapter(ad);
        spino.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), inputs[position], Toast.LENGTH_LONG).show();
                textposition = inputs[position];
                textposition = spino.getSelectedItem().toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });


        TextView number_laundry = dialog.findViewById(R.id.number_laundry);
        TextView number_presser = dialog.findViewById(R.id.number_presser);
        TextView number_IiRON = dialog.findViewById(R.id.number_IiRON);
        TextView number_steam = dialog.findViewById(R.id.number_steam);


        CheckBox checklaundry = dialog.findViewById(R.id.checklaundry);
        CheckBox checkpresser = dialog.findViewById(R.id.checkpresser);
        CheckBox checkIron = dialog.findViewById(R.id.checkIron);
        CheckBox checkIron2 = dialog.findViewById(R.id.checkIron2);
        //one
        Button increase = dialog.findViewById(R.id.increase);
        Button decrease = dialog.findViewById(R.id.decrease);
        //two
        Button increase2 = dialog.findViewById(R.id.increase2);
        Button decrease1 = dialog.findViewById(R.id.decrease1);
        // three
        Button decrease2 = dialog.findViewById(R.id.decrease2);
        Button increase3 = dialog.findViewById(R.id.increase3);
        // foree
        Button decrease3 = dialog.findViewById(R.id.decrease3);
        Button increase4 = dialog.findViewById(R.id.increase4);


        increase.setOnClickListener(v1 -> {
            mintegerone = mintegerone + 1;
            number_laundry.setText("" + mintegerone);
        });
        decrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mintegerone = mintegerone - 1;
                number_laundry.setText("" + mintegerone);
            }
        });

        increase2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mintegerTwo = mintegerTwo + 1;
                number_presser.setText("" + mintegerTwo);
            }
        });

        decrease1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mintegerTwo = mintegerTwo - 1;
                number_presser.setText("" + mintegerTwo);
            }
        });


        decrease2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mintegerThree = mintegerThree - 1;
                number_IiRON.setText("" + mintegerThree);
            }
        });

        increase3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mintegerThree = mintegerThree + 1;
                number_IiRON.setText("" + mintegerThree);
            }
        });


        decrease3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mintegerFore = mintegerFore - 1;
                number_steam.setText("" + mintegerFore);
            }
        });

        increase4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mintegerFore = mintegerFore + 1;
                number_steam.setText("" + mintegerFore);
            }
        });


        Button ok = dialog.findViewById(R.id.edit);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (checklaundry.isChecked()) {
                    //itemsservies.add();

                    ItemServies itemServiesobject = new ItemServies(

                            nameservices.getText().toString(), name, checklaundry.getText().toString(), number_laundry.getText().toString()
                    );
//

                    itemsservies.add(itemServiesobject);


                }
                if (checkpresser.isChecked()) {


                    ItemServies itemServiesobject = new ItemServies(
                            nameservices.getText().toString(), name, checkpresser.getText().toString(), number_presser.getText().toString()
                    );
                    itemsservies.add(itemServiesobject);


                }
                if (checkIron.isChecked()) {

                    ItemServies itemServiesobject = new ItemServies(
                            nameservices.getText().toString(), name,
                            checkIron.getText().toString()
                            , number_IiRON.getText().toString()

                    );
//                            ItemServies itemServiesobject = new ItemServies(nameservices.getText().toString(),
//                                    textposition,
//                                    number_IiRON.getText().toString(),
//                                    checkIron.getText().toString(),
//                                    " ",
//                                    email.getText().toString(),
//                                    Registration_No.getText().toString() );

//                            ItemServies itemServies = new ItemServies(nameservices.getText().toString(),
//                                    number_IiRON.getText().toString(), checkIron.getText().toString(), textposition);
//
                    itemsservies.add(itemServiesobject);


//                            db.collection("ItemServies")
//                                    .add(itemServiesobject)
//                                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
//                                        @Override
//                                        public void onSuccess(DocumentReference documentReference) {
//
//                                            Log.d("TAG", "DocumentSnapshot written with ID: " + documentReference.getId());
//
//                                        }
//                                    })
//                                    .addOnFailureListener(new OnFailureListener() {
//                                        @Override
//                                        public void onFailure(@NonNull Exception e) {
//                                            Log.w("TAG", "Error adding document", e);
//
//
//                                        }
//                                    });


                }
                if (checkIron2.isChecked()) {
                    ItemServies itemServiesobject = new ItemServies(
                            nameservices.getText().toString(),
                            name,
                            checkIron2.getText().toString(),
                            number_steam.getText().toString()
                    );
                    itemsservies.add(itemServiesobject);

                }

                Services serviceser = new Services(textposition
                        , name,
                        email,
                        itemsservies
                        , nameservices.getText().toString()
                        , number.getText().toString());
                serviceser.setKeysub(key);

                // db.collection(spino.getSelectedItem().toString()+"Services").add(serviceser);
                db.collection("Services")
                        .add(serviceser).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                Map<String, Object> servies = new HashMap<>();
                                servies.put("documentId", documentReference.getId());
                                db.collection("Services").document(documentReference.getId())
                                        .set(servies, SetOptions.merge())
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@androidx.annotation.NonNull Task<Void> task) {
//                                                Intent intent = new Intent(getApplicationContext(), SubscriptionsActivity.class);
//                                                startActivity(intent);
//                                                finish();
                                                dialog.dismiss();
                                                db.collection("Services").whereEqualTo("keysub",num)
                                                        .get()
                                                        .addOnSuccessListener(queryDocumentSnapshots -> {
                                                            if (!queryDocumentSnapshots.isEmpty()) {
                                                                for (DocumentSnapshot documentSnapshot : queryDocumentSnapshots.getDocuments()) {
                                                                    Services services = documentSnapshot.toObject(Services.class);
                                                                    //Log.e("response", "services: " + services);
                                                                    //  preferencesHelper.setPREF_Owner_del(documentSnapshot.getId());
                                                                    //servicesArrayList.clear();
                                                                    servicesArrayList.add(services);
                                                                }
                                                                adapterOfServices.update(servicesArrayList);
                                                            } else {
                                                                Toast.makeText(Details_Owner_Services.this, "No data found ", Toast.LENGTH_SHORT).show();
                                                            }
                                                        }).addOnFailureListener(e -> {
                                                            Toast.makeText(Details_Owner_Services.this, "Fail to get the data.", Toast.LENGTH_SHORT).show();
                                                        });

                                                Toast.makeText(Details_Owner_Services.this, " DONE", Toast.LENGTH_SHORT).show();

                                            }
                                        });

                            }
                        });


            }
        });

//                recyclerView.setHasFixedSize(true);
//                recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
//                adapterItem = new AdapterItem(NewSubscription.this, itemsservies);
//                recyclerView.setAdapter(adapterItem);
//                dialog.cancel();

        dialog.show();
    }




    }



