package com.example.mylaundry.OwnerActivitys.FragmentOwner;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import com.example.mylaundry.OwnerActivitys.ActivitysOwner.NewOrdersOwner;
import com.example.mylaundry.R;


public class FragmentHome extends Fragment {

    ImageView request_Current , request_Previous  ;
    Button request_New;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       // return inflater.inflate(R.layout.fragment_home, container, false);
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        request_Current=rootView.findViewById(R.id.imageView8);
        request_Previous=rootView.findViewById(R.id.imageView6);
        request_New=rootView.findViewById(R.id.button7);



        request_Current.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getContext(), CurrentOwner.class);
                startActivity(intent);

            }
        });

        request_Previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getContext(), PreviousOrders.class);
                startActivity(intent);
            }
        });

        request_New.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getContext(), NewOrdersOwner.class);
                startActivity(intent);
            }
        });














        return  rootView;
    }
}