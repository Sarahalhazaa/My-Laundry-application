package com.example.mylaundry.AcivitysOfLaundry;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.dhims.timerview.TimerTextView;
import com.example.mylaundry.AdapterView.AdapterBasket;
import com.example.mylaundry.AdapterView.AdapterOrder;
import com.example.mylaundry.AdapterView.ModelArray;
import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.R;
import com.google.firebase.firestore.FirebaseFirestore;
import com.kofigyan.stateprogressbar.StateProgressBar;

import java.util.ArrayList;
import java.util.Calendar;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class OrderTracking extends AppCompatActivity {

    ArrayList<RequestModel> requestModels;
FirebaseFirestore db;
    RecyclerView recyclerView;

    TextView totalnumber, totalp, totalprice , namela;

    AdapterOrder adapterOrder;
    ModelArray modelArray;
    TextView time;
    TextView requsettst;
    Button back;
    String[] descriptionData = {"Waiting for request", "request accepted",
            "Items received", "Items have been delivered to the laundromat", "Delivered"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ordertracking);
        String iddecoment=getIntent().getStringExtra("decomentorders");
        Toast.makeText(this, ""+iddecoment, Toast.LENGTH_SHORT).show();
        totalprice = findViewById(R.id.totalprice);
        namela=findViewById(R.id.namelaundryorder);
        StateProgressBar stateProgressBar = findViewById(R.id.your_state_progress_bar_id);
        // stateProgressBar.setStateDescriptionData(descriptionData);
        back = findViewById(R.id.back);
        db=FirebaseFirestore.getInstance();
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        recyclerView = findViewById(R.id.recyclerView);
        requsettst = findViewById(R.id.textView70);
        requsettst.setText("Waiting for Acceptance");

        totalnumber = findViewById(R.id.totalnumber);
        time = findViewById(R.id.textView77);
        totalp = findViewById(R.id.totalp);
        long futureTimestamp = System.currentTimeMillis() + (5 * 60 * 1000);
        TimerTextView timerText = findViewById(R.id.timerText);
        timerText.setEndTime(futureTimestamp);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

        db.collection("RequestModel").document(iddecoment).update("type","request Rejected");
            onBackPressed();
            }
        }, 300000);



        modelArray = (ModelArray) getIntent().getSerializableExtra("dataorder");
        String totall = getIntent().getStringExtra("total");
        String addtax = getIntent().getStringExtra("addtax");
        String totalamount = getIntent().getStringExtra("amount");
        String name = getIntent().getStringExtra("namela");

        namela.setText(name);

        totalnumber.setText(totall );

        totalprice.setText(addtax );

        totalp.setText(totalamount );

        recyclerView.setHasFixedSize(true);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapterOrder = new AdapterOrder(this, modelArray.getOrder());

        recyclerView.setAdapter(adapterOrder);

        Log.d("order", "onCreate: " + modelArray.getOrder());

        Calendar now = Calendar.getInstance();
        Calendar nextHour = Calendar.getInstance();
        nextHour.add(Calendar.HOUR, 0);
        nextHour.set(Calendar.MINUTE, 5);
        nextHour.set(Calendar.SECOND, 0);

//        long difference = nextHour.getTimeInMillis() - now.getTimeInMillis();
//
//        new CountDownTimer(difference, 1000) {
//
//            public void onTick(long millisUntilFinished) {
//                //mTextField.setText("seconds remaining: " + millisUntilFinished / 1000);
//                //  time.setText(nextHour.getTime().toString());
//                Log.d("time11", "onTick: 1" + difference);
//            }
//
//            public void onFinish() {
//                // mTextField.setText("done!");
//            }
//        }.start();


    }
}