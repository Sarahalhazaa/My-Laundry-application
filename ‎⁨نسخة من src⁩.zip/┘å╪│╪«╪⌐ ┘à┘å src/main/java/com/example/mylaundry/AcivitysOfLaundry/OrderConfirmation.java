package com.example.mylaundry.AcivitysOfLaundry;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mylaundry.AdapterView.ModelArray;
import com.example.mylaundry.AdapterView.OrderAdapterCon;
import com.example.mylaundry.Model.ItemServies;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.Model.ServiesInt;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.NewSubscription;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionsActivity;
import com.example.mylaundry.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.SetOptions;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class OrderConfirmation extends AppCompatActivity implements ServiesInt {

    RecyclerView recyclerView;

    TextView textView;
    Button execution;
    FirebaseFirestore db;
    ArrayList<RequestModel> requestModels;
    //  ArrayList<ArrayList<Services>> dataOrder;
    ArrayList<Services> dataOrder;
    ArrayList<ItemServies> itemServies;
    OrderAdapterCon orderAdapterCon;
    TextView Subtotal, amount, day, addtax;
    PreferencesHelper preferencesHelper;
    //  AdapterBasket adapterOrder;
    String NameService, getEidtetxt;
    Intent intent;
String namelay;
    int total;
    float tt;
    Button back;
    int count;

    int totalamount = 0;
    String email;
    String Status;
    ModelArray model;
    TextView address;
    int minteger;
    String text;
    String keysub;
    FirebaseAuth auth;
    String keyowner;
    String city;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_confirmation);
        recyclerView = findViewById(R.id.recyclerview);
        minteger=getIntent().getIntExtra("minteger",0);
        text=getIntent().getStringExtra("textser");
        keysub=getIntent().getStringExtra("keysub");
        keyowner=getIntent().getStringExtra("keyowner");
        auth =FirebaseAuth.getInstance();
     //   Toast.makeText(this, ""+minteger, Toast.LENGTH_SHORT).show();
        Toast.makeText(this, ""+keysub, Toast.LENGTH_SHORT).show();
        Random r = new Random();
        int randomNumber = r.nextInt(100);
        String random = Integer.toString(randomNumber);
        back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        amount = findViewById(R.id.totalp);
        Subtotal = findViewById(R.id.totalprice);
        day = findViewById(R.id.numberof);
        addtax = findViewById(R.id.addtax);
        address = findViewById(R.id.textView58);
        execution = findViewById(R.id.execution);
        textView=findViewById(R.id.textView00);
        preferencesHelper = new PreferencesHelper(this);
        db = FirebaseFirestore.getInstance();
        address.setText(""+random);
        db.collection("user").document(auth.getUid()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                 city=documentSnapshot.getString("cityname");
                textView.setText("Address : "+city+" - "+preferencesHelper.getPREF_User_adreess());

            }
        });
        model = (ModelArray) getIntent().getSerializableExtra("model");

        count = getIntent().getIntExtra("total", 0);


        int addta = (int) (count * 0.15);

        Subtotal.setText(count + "");

        addtax.setText(Math.ceil(addta) + " SR");

        int payamount = (int) (count + 10 + Math.ceil(addta));

        amount.setText("" + payamount);

        //     Log.e("total", String.valueOf(count));

        email = getIntent().getStringExtra("email");

       // Toast.makeText(this, "" + count, Toast.LENGTH_SHORT).show();

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        orderAdapterCon = new OrderAdapterCon(this, model.getData(),minteger,text);
        recyclerView.setAdapter(orderAdapterCon);


        int maxNumber = 0;
        for (int i = 0; i < model.getData().size(); i++) {
            if (Integer.parseInt(model.getData().get(i).getNumberOfday()) > maxNumber) {
                maxNumber = Integer.parseInt(model.getData().get(i).getNumberOfday()); // Update the maximum value
            }
        }
        day.setText(String.valueOf(maxNumber) + "day");

        db.collection("Subscription").whereEqualTo("documentId", keysub).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {

                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        if (!queryDocumentSnapshots.isEmpty()) {
                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                            for (DocumentSnapshot d : list) {
                                SubscriptionModel subscriptionModel = d.toObject(SubscriptionModel.class);
                                if(subscriptionModel.getType().equals("RENEWAL")){
                                    Status=" not available";
                                }
                                else {
                                Status = subscriptionModel.getStatus();
                                String name=subscriptionModel.getName();
                                Toast.makeText(OrderConfirmation.this, ""+Status +name, Toast.LENGTH_SHORT).show();
                                Log.d("Status", "onSuccess: " + Status);
                            }}
                        } else {
                            Toast.makeText(OrderConfirmation.this, "No data found ", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // if we do not get any data or any error we are displaying
                        // a toast message that we do not get any data
                        Toast.makeText(OrderConfirmation.this, "Fail to get the data.", Toast.LENGTH_SHORT).show();
                    }
                });


        execution.setOnClickListener(new View.OnClickListener() {
            @TargetApi(Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {


                if (Status.equals("available")) {

                    intent = new Intent(getApplicationContext(), OrderTracking.class);
                    orderAdapterCon.AddData();
                    intent.putExtra("total", Subtotal.getText().toString());
                    intent.putExtra("addtax", addtax.getText().toString());
                    intent.putExtra("amount", amount.getText().toString());
                    intent.putExtra("namela",namelay);
                    ModelArray modelArray = new ModelArray();
                    intent.putExtra("dataorder", orderAdapterCon.getModelArray());

                    RequestModel requestModel = new RequestModel(preferencesHelper.getPREF_User_adreess(),
                            orderAdapterCon.getModelArray().getOrder()
                            , Integer.toString(total)
                            , addtax.getText().toString(),
                            LocalDate.now().toString(),
                            amount.getText().toString(),
                            random + "fb" + random + "fB", "", "loading", email ,namelay);
                        requestModel.setKeyuser(auth.getUid());
                        requestModel.setKeyowner(keyowner);
                        requestModel.setKeysub(keysub);
                        requestModel.setCity(city);

                    Log.d("RequestModel", "onClick: " + requestModel);

                    db.collection("RequestModel")
                            .add(requestModel)
                            .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                @Override
                                public void onSuccess(DocumentReference documentReference) {

                                    Map<String, Object> requestModel = new HashMap<>();
                                    requestModel.put("documentId", documentReference.getId());
                                    db.collection("RequestModel").document(documentReference.getId())
                                            .set(requestModel, SetOptions.merge())
                                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@androidx.annotation.NonNull Task<Void> task) {

                                                }
                                            });
                                    Log.d("TAG", "DocumentSnapshot written with ID: " + documentReference.getId());
                                        intent.putExtra("decomentorders",documentReference.getId());
                                    startActivity(intent);
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.w("TAG", "Error adding document", e);


                                }
                            });


                } else {
                    new SweetAlertDialog(OrderConfirmation.this)
                            .setTitleText("Sorry, the laundry is not available at the moment, " +
                                    "please order later!")
                            .show();
                }

//                RequestModel requestModel = new RequestModel("wait" ,requestModels , "1" );
//
//                db.collection("RequestModel")
//                        .add(requestModel )
//                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
//                            @Override
//                            public void onSuccess(DocumentReference documentReference) {
//
//                                Log.d("TAG", "DocumentSnapshot written with ID: " + documentReference.getId());
//                                finish();

//
//                                String price = getIntent().getStringExtra("price");
//                                String numberofservies = getIntent().getStringExtra("pricetext");
//                                String nameserv = getIntent().getStringExtra("nameserv");
//                                String totall = getIntent().getStringExtra("total1");


            }
            //   })
//                        .addOnFailureListener(new OnFailureListener() {
//                            @Override
//                            public void onFailure(@NonNull Exception e) {
//                                Log.w("TAG", "Error adding document", e);
//
//
//                            }
//                        });
            //  }
        });

    }

    @Override
    public void callbackCall(int position) {
        // count =position ;

        Subtotal.setText(position + " SR");
        total = position;

        double totalountam = position * 0.15;
        tt = (float) totalountam;

        Log.d("Math", "callbackCall: " + Math.ceil(tt));
        addtax.setText(Math.ceil(tt) + " SR");


//        Log.d("data", "callbackCall: " +  Math.floor(tt));
//        Log.d("data", "callbackCall: " +  Math.ceil(tt));


        totalamount = (int) (position + 10 + Math.ceil(tt));

        amount.setText(totalamount + " SR");
    }

    @Override
    public void namelay(String name) {
        namelay =name;

    }



    //@Override
//    public void callbackCall(int position) {
//
//        Subtotal.setText(position + " SR");
//
//        total = position;
//
//        double totalountam = position * 0.15;
//
//        tt = (float) totalountam;
//
//        //Log.d("Math", "callbackCall: " +  Math.floor(tt));
//
//        Log.d("Math", "callbackCall: " + Math.ceil(tt));
//
//
//        //float t =(float)totalountam;
//
//        addtax.setText(Math.ceil(tt) + " SR");
//
//        totalamount = (int) (position + 10 + 0.15);
//
//        amount.setText(totalamount + " SR");
//
//
//    }


}