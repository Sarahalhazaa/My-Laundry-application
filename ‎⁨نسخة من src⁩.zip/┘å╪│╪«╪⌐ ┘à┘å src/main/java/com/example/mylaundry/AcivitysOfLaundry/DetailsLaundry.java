package com.example.mylaundry.AcivitysOfLaundry;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mylaundry.AdapterView.AdapterDetails;
import com.example.mylaundry.MainActivity;
import com.example.mylaundry.Model.ItemServies;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.Model.ServiesInt;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;
import java.util.List;

public class DetailsLaundry extends AppCompatActivity {

    String name, type, price;
    RecyclerView recyclerView, recyclerView1, recyclerView2;
    // ArrayList<SubscriptionModel> st;

    //ArrayList<ItemServies> itemArray;
    ArrayList<Services> servicesArrayList;


    ArrayList<Services> servicesClothing;
    ArrayList<Services> services;

    ArrayList<Services> servicesHome;


    FirebaseFirestore db;

    RadioButton bt_clothing, bt_home, bt_Carpet;
    RadioGroup group;
    Button cart;
    TextView tvname;
    int positionradio;
    AdapterDetails adapterDetails;
    PreferencesHelper preferencesHelper;
    String evaluation;
    FirebaseAuth auth;
    Services s;
    String keysub;
    String keyowner;
    String keyserves;
    String keyuser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_laundry);
        preferencesHelper = new PreferencesHelper(this);
        db = FirebaseFirestore.getInstance();
        keysub=getIntent().getStringExtra("keysub");
        keyowner=getIntent().getStringExtra("keyowner");
        auth=FirebaseAuth.getInstance();
        keyuser=auth.getUid();
        bt_clothing = findViewById(R.id.bt_clothing);
        bt_home = findViewById(R.id.bt_home);
        bt_Carpet = findViewById(R.id.bt_Carpet);
        group = findViewById(R.id.group1);
        cart = findViewById(R.id.cart);
        recyclerView = findViewById(R.id.recycleritem); ////
        recyclerView1 = findViewById(R.id.recycler1); ////
        recyclerView2 = findViewById(R.id.recycler2); ///

        //st = new ArrayList<>();
        servicesArrayList = new ArrayList<>();
        servicesClothing = new ArrayList<>();
        servicesHome = new ArrayList<>();
        services = new ArrayList<>();

        //itemArray =new ArrayList<>();
        RatingBar simpleRatingBar = findViewById(R.id.simpleRatingBar);


//        SubscriptionModel subscriptionModel = (SubscriptionModel) getIntent().
//                getSerializableExtra("Data");
//        //  st.add(subscriptionModel);


        name = getIntent().getStringExtra("name");
        evaluation = getIntent().getStringExtra("evaluation");
        int evalutionnumber = Integer.parseInt(evaluation);
        simpleRatingBar.setRating(evalutionnumber);

        tvname = findViewById(R.id.namelaundry);
        tvname.setText(name);

        // servicesArrayList.clear();

        group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                int radioBtnID = group.getCheckedRadioButtonId();
                View radioB = group.findViewById(radioBtnID);

                RadioButton radioButton = (RadioButton) group.findViewById(radioBtnID);

                //     selectedText = (String) radioButton.getText();
                int position = group.indexOfChild(radioB);

                if (position == 0) {
                    positionradio = 0;
                    recyclerView1.setVisibility(View.GONE);
                    recyclerView2.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.VISIBLE);

                    recyclerView.setLayoutManager(new LinearLayoutManager(DetailsLaundry.this));
                    adapterDetails = new AdapterDetails(DetailsLaundry.this, servicesClothing,keyowner,keyuser,keysub);
                    recyclerView.setAdapter(adapterDetails);
                    adapterDetails.notifyDataSetChanged();


                } else if (position == 1) {
                  //  Log.d("home", "onCheckedChanged: " + servicesHome.get(0).getNameService());
                    positionradio = 1;

                    recyclerView.setVisibility(View.GONE);
                    recyclerView1.setVisibility(View.GONE);
                    recyclerView2.setVisibility(View.VISIBLE);
                    recyclerView2.setLayoutManager(new LinearLayoutManager(DetailsLaundry.this));
                    AdapterDetails adapterDetails1 = new AdapterDetails(DetailsLaundry.this, servicesHome,keyowner,keyuser,keysub);
                    recyclerView2.setAdapter(adapterDetails1);
                    adapterDetails1.notifyDataSetChanged();
                } else if (position == 2) {
                    positionradio = 2;
                    recyclerView.setVisibility(View.GONE);
                    recyclerView2.setVisibility(View.GONE);
                    recyclerView1.setVisibility(View.VISIBLE);
                    recyclerView1.setLayoutManager(new LinearLayoutManager(DetailsLaundry.this));
                    adapterDetails = new AdapterDetails(DetailsLaundry.this, servicesArrayList,keyowner,keyuser,keysub);
                    recyclerView1.setAdapter(adapterDetails);
                    adapterDetails.notifyDataSetChanged();

                }
            }
        });

        db.collection("Services").whereEqualTo("keysub", keysub).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        if (!queryDocumentSnapshots.isEmpty()) {
                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                            for (DocumentSnapshot d : list) {
                                s = d.toObject(Services.class);
//                                Log.d("TAG", "onSuccess: " + s.getItemsservies());
                                Log.d("getNameService", "onSuccess: " + s.getNameService());

                                services.add(s);
                                servicesHome.clear();
                                servicesClothing.clear();
                                servicesArrayList.clear();

                                for (int i = 0; i < services.size(); i++) {
                                    Log.d("type", "onCreate: " + services.size());
                                    if (services.get(i).getNameService().equals("Clothing ")) {
                                        Log.d("type", "onCreate:Clothing ");
                                        //servicesClothing.clear();
                                        Toast.makeText(DetailsLaundry.this, "Clothing", Toast.LENGTH_SHORT).show();
                                        Log.d("data", "onSuccess: " + s);
                                        Services s = new Services(services.get(i).getNameService(),
                                                services.get(i).getNameLaundry(),
                                                services.get(i).getEmail(),
                                                services.get(i).getItemsservies(),
                                                services.get(i).getEidtetxt(),
                                                services.get(i).getNumberOfday());

                                        servicesClothing.add(s);

                                    }
                                    if (services.get(i).getNameService().equals(" home")) {
                                        Log.d("type", "onCreate:home ");

                                       // servicesHome.clear();
                                        Toast.makeText(DetailsLaundry.this, "home", Toast.LENGTH_SHORT).show();
                                        Log.d("data", "onSuccess: " + s);
                                        Services shome = new Services(
                                                services.get(i).getNameService()+"",
                                                services.get(i).getNameLaundry(),services.get(i).getEmail(),
                                                services.get(i).getItemsservies()
                                                ,services.get(i).getEidtetxt(),
                                                services.get(i).getNumberOfday());

                                        servicesHome.add(shome);
//                                            recyclerView2.setLayoutManager(new LinearLayoutManager(DetailsLaundry.this));
//                                            adapterDetails = new AdapterDetails(DetailsLaundry.this, servicesHome);
//                                            Log.d("data", "onSuccess: " + s);
//                                            recyclerView2.setAdapter(adapterDetails);
                                        //  adapterDetails.notifyDataSetChanged();
                                        // break;
                                    }
                                    if (services.get(i).getNameService().equals("carpet")) {
                                        Log.d("type", "onCreate:carpet ");
                                       // servicesArrayList.clear();
                                        Services scarpet = new Services(services.get(i).getNameService(),
                                                services.get(i).getNameLaundry(),
                                                services.get(i).getEmail(),
                                                services.get(i).getItemsservies(),
                                                services.get(i).getEidtetxt(),
                                                services.get(i).getNumberOfday());

                                        servicesArrayList.add(scarpet);
//                                            recyclerView.setLayoutManager(new LinearLayoutManager(DetailsLaundry.this));
//                                            //    st.add(subscriptionModel);
//                                            adapterDetails = new AdapterDetails(DetailsLaundry.this, servicesArrayList);
//                                            Log.d("data", "onSuccess: " + s);
//                                            recyclerView.setAdapter(adapterDetails);
                                        //   adapterDetails.notifyDataSetChanged();


                                    }
                                }


                                //  servicesArrayList.add(s);
//                                adapterDetails.notifyDataSetChanged();

                                //   recyclerView.setHasFixedSize(true);
                            }
//                            adapterDetails.notifyDataSetChanged();
                        } else {
                            Toast.makeText(getApplicationContext(), "No data found ", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // if we do not get any data or any error we are displaying
                        // a toast message that we do not get any data
                        Toast.makeText(getApplicationContext(), "Fail to get the data.", Toast.LENGTH_SHORT).show();
                    }
                });


//        switch (services.) {
//            case "Clothing ":
//                // servicesArrayList.clear();
//                Toast.makeText(DetailsLaundry.this, "Clothing", Toast.LENGTH_SHORT).show();
//                Log.d("data", "onSuccess: " + s);
//                servicesClothing.add(s);
//                recyclerView1.setLayoutManager(new LinearLayoutManager(DetailsLaundry.this));
//                adapterDetails = new AdapterDetails(DetailsLaundry.this, servicesClothing);
//                //adapterDetails.notifyDataSetChanged();
//                recyclerView1.setAdapter(adapterDetails);
//                break;
//            case "Home":
//                //  servicesArrayList.clear();
//                Toast.makeText(DetailsLaundry.this, "Home", Toast.LENGTH_SHORT).show();
//                //servicesArrayList.add(s);
//                servicesHome.add(s);
//                recyclerView2.setLayoutManager(new LinearLayoutManager(DetailsLaundry.this));
//                adapterDetails = new AdapterDetails(DetailsLaundry.this, servicesHome);
//                Log.d("data", "onSuccess: " + s);
//                recyclerView2.setAdapter(adapterDetails);
//                break;
//            case "carpet":
//                // servicesArrayList.clear();
//                Toast.makeText(DetailsLaundry.this, "carpt", Toast.LENGTH_SHORT).show();
//                servicesArrayList.add(s);
//                recyclerView.setLayoutManager(new LinearLayoutManager(DetailsLaundry.this));
//                //    st.add(subscriptionModel);
//                adapterDetails = new AdapterDetails(DetailsLaundry.this, servicesArrayList);
//                Log.d("data", "onSuccess: " + s);
//                recyclerView.setAdapter(adapterDetails);
//                break;
//        }
//

//
//
//
////
//
//        // st.clear();
//
//       // st.add(subscriptionModel);
//        for (int i = 0; i < s.size(); i++) {

        //  Log.d("khadija", "onCreate: " + subscriptionModel.getServices().get(i).getItemsservies().get(i).getId());
        if (positionradio == 0) {
//            recyclerView1.setLayoutManager(new LinearLayoutManager(DetailsLaundry.this));
//            adapterDetails = new AdapterDetails(DetailsLaundry.this, servicesClothing);


            // recyclerView1.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.VISIBLE);
            //  recyclerView2.setVisibility(View.VISIBLE);

        } else if (positionradio == 1) {
            //  st.add(subscriptionModel);
//            recyclerView2.setLayoutManager(new LinearLayoutManager(DetailsLaundry.this));
//            adapterDetails = new AdapterDetails(DetailsLaundry.this, servicesHome);
            //   recyclerView2.setAdapter(adapterDetails);
            //  adapterDetails.notifyDataSetChanged();
            //  recyclerView2.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.VISIBLE);
            //  recyclerView1.setVisibility(View.VISIBLE);
        } else if (positionradio == 2) {
//            recyclerView.setLayoutManager(new LinearLayoutManager(DetailsLaundry.this));
//            //    st.add(subscriptionModel);
//            adapterDetails = new AdapterDetails(DetailsLaundry.this, servicesArrayList);
            //   recyclerView.setAdapter(adapterDetails);
            //  adapterDetails.notifyDataSetChanged();
            //recyclerView.setVisibility(View.VISIBLE);
            recyclerView1.setVisibility(View.VISIBLE);
            //  recyclerView2.setVisibility(View.VISIBLE);
        }
        //    }

        //  }
//


//        st.add(subscriptionModel);
//        adapterDetails = new AdapterDetails(DetailsLaundry.this, st);
//        recyclerView.setAdapter(adapterDetails);


//
////        Log.d("User", "onCreate: " + preferencesHelper.getPREF_Position());
////        position  = preferencesHelper.getPREF_Position();
////
//        if(subscriptionModel.getServices().get(position).getItemsservies().get(position).getId().
//        equals("Clothing")){
//        } else {
//            Toast.makeText(this, " NO thinge", Toast.LENGTH_SHORT).show();
//            recyclerView.setVisibility(View.INVISIBLE);
//        }


//        adapterDetails = new AdapterDetails (DetailsLaundry.this,
//                subscriptionModel.getServices().get(0).getItemsservies());


        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Intent intent = new Intent(getApplicationContext(), OrderConfirmation.class);


//                db.collection("Basket")
//                        .add(s)
//                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
//                            @Override
//                            public void onSuccess(DocumentReference documentReference) {
//                                Log.d("TAG", "DocumentSnapshot written with ID: " + documentReference.getId());
//
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("code", 3);
                //     intent.putExtra("Data2", s);
                startActivity(intent);
//                            }
//                        })
//                        .addOnFailureListener(new OnFailureListener() {
//                            @Override
//                            public void onFailure(@NonNull Exception e) {
//                                Log.w("TAG", "Error adding document", e);
//
//
//                            }
//                        });


            }
        });

    }


}