package com.example.mylaundry.AcivitysOfLaundry;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.mylaundry.R;

public class AcivityLaundriesNearby extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acivity_laundries_nearby);



    }
}