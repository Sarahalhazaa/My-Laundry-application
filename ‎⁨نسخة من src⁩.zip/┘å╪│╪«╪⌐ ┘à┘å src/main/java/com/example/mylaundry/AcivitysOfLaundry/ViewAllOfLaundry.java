package com.example.mylaundry.AcivitysOfLaundry;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.widget.SearchView;
import android.widget.Toast;

import com.example.mylaundry.AdapterView.AdapterServices;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;
import java.util.List;

public class ViewAllOfLaundry extends AppCompatActivity {


    ArrayList<SubscriptionModel> st;

    AdapterServices adapterServices;
    RecyclerView recyclerView;
    FirebaseFirestore db;
    FirebaseAuth auth = FirebaseAuth.getInstance();
    String cityname;
    SearchView searchView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all_of_laundry);


        recyclerView = findViewById(R.id.recyclerviewall);


        searchView =findViewById(R.id.searchView);

        db = FirebaseFirestore.getInstance();

        st = new ArrayList<>();
        db.collection("user").document(auth.getUid()).get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@androidx.annotation.NonNull Task<DocumentSnapshot> task) {
                        DocumentSnapshot snapshot=task.getResult();
                        cityname=snapshot.getString("cityname");
                        Log.d("date", "onComplete:Amed " + cityname);
                        getData();
                        //Toast.makeText(getContext(), ""+citynamee, Toast.LENGTH_SHORT).show();


                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@androidx.annotation.NonNull Exception e) {
                        Toast.makeText(ViewAllOfLaundry.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });




        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(ViewAllOfLaundry.this));

        adapterServices = new AdapterServices(ViewAllOfLaundry.this, st);

        recyclerView.setAdapter(adapterServices);


        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return false;

            }

            @Override
            public boolean onQueryTextChange(String newText) {

                filter(newText);

                return false;

            }
        });


    }


    private void filter(String text) {
        // creating a new array list to filter our data.
        ArrayList<SubscriptionModel> filteredlist = new ArrayList<SubscriptionModel>();

        // running a for loop to compare elements.
        for (SubscriptionModel item : st) {
            // checking if the entered string matched with any item of our recycler view.
            if (item.getName().toLowerCase().contains(text.toLowerCase())) {
                // if the item is matched we are
                // adding it to our filtered list.
                filteredlist.add(item);
            }
        }
        if (filteredlist.isEmpty()) {
            // if no item is added in filtered list we are
            // displaying a toast message as no data found.
            Toast.makeText(this, "No Data Found..", Toast.LENGTH_SHORT).show();
        } else {
            // at last we are passing that filtered
            // list to our adapter class.
            adapterServices.filterList(filteredlist);
        }
    }





    void getData() {
        Log.d("date", "onComplete:city " + cityname);

        db.collection("Subscription").whereEqualTo("area",cityname).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        if (!queryDocumentSnapshots.isEmpty()) {
                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                            for (DocumentSnapshot d : list) {
                                //Toast.makeText(getContext(), ""+list.size(), Toast.LENGTH_SHORT).show();
                                SubscriptionModel subscriptionModel = d.toObject(SubscriptionModel.class);
                                if (subscriptionModel.getType().equals("CURRENT")){
                                    st.add(subscriptionModel);
                                }else {
                                    //  Toast.makeText(getContext(), "not found data.", Toast.LENGTH_SHORT).show();

                                }

                                Log.d("date", "onComplete:size " + st.size());

                            }
                            adapterServices.notifyDataSetChanged();
                        } else {
                            Log.d("TAG", "onSuccess: ");
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(ViewAllOfLaundry.this, "Fail to get the data.", Toast.LENGTH_SHORT).show();
                    }
                });


//        db.collection("Subscription").whereEqualTo("cityname", preferencesHelper.getPREF_uer_area()).get()
//                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
//                    @SuppressLint("NotifyDataSetChanged")
//                    @Override
//                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
//
//                        if (!queryDocumentSnapshots.isEmpty()) {
//                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
//                            for (DocumentSnapshot d : list) {
//                                SubscriptionModel subscriptionModel = d.toObject(SubscriptionModel.class);
//                                st.add(subscriptionModel);
//                            }
//                            adapterServices.notifyDataSetChanged();
//
//                        } else {
//
//                            Toast.makeText(getContext(), "No data found ", Toast.LENGTH_SHORT).show();
//                        }
//                    }
//                }).addOnFailureListener(e -> {
//                    // if we do not get any data or any error we are displaying
//                    // a toast message that we do not get any data
//                    Toast.makeText(getActivity(), "Fail to get the data.", Toast.LENGTH_SHORT).show();
//                });


    }




}