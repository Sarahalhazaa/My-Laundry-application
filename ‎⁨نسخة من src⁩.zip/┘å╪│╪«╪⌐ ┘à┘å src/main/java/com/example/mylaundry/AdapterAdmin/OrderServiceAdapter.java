package com.example.mylaundry.AdapterAdmin;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.R;
import com.example.mylaundry.databinding.ItemOrderServiceBinding;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;

@SuppressLint({"NotifyDataSetChanged", "SetTextI18n"})
public class OrderServiceAdapter extends RecyclerView.Adapter<OrderServiceAdapter.AdapterNewSubLaundryViewHolder> {

    Context mContext;
    ArrayList<RequestModel> list;

    public void setData(ArrayList<RequestModel> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    public ArrayList<RequestModel> getData() {
        return list;
    }

    public OrderServiceAdapter(Context mContext) {
        this.mContext = mContext;
    }


    @NonNull
    @Override
    public AdapterNewSubLaundryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order_service, parent, false);
        return new AdapterNewSubLaundryViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterNewSubLaundryViewHolder holder, int position) {
        RequestModel model = list.get(position);
        holder.bind(model);
    }

    @Override
    public int getItemCount() {
        return (list != null ? list.size() : 0);
    }


    static class AdapterNewSubLaundryViewHolder extends RecyclerView.ViewHolder {
        ItemOrderServiceBinding binding;

        private AdapterNewSubLaundryViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ItemOrderServiceBinding.bind(itemView);
        }

        private void bind(RequestModel model) {
            binding.name.setText("name : " + model.getNamelaundry());
            binding.service.setText("service : " + model.getData().get(0).getEidtetxt());
            binding.count.setText("count : " + model.getTotal());
            binding.total.setText("Total : " + model.getAmount());
            binding.SSS.setText(" Service Type : laundry");
        }
    }

}