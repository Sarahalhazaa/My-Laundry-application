package com.example.mylaundry.AdapterAdmin;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.AdapterOwner.AdapterAccountLaundry;
import com.example.mylaundry.Model.PreferencesHelper;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.R;
import com.google.common.hash.HashingOutputStream;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class AdapterNewSubLaundry extends RecyclerView.Adapter<AdapterNewSubLaundry.myViewHolder> {
    ArrayList<SubscriptionModel> data;

    Activity activity;
    // ArrayList<SubscriptionModel> dataSub;

    public AdapterNewSubLaundry(Activity activity, ArrayList<SubscriptionModel> data) {
        this.data = data;
        this.activity = activity;
//        firestore = FirebaseFirestore.getInstance();
//        preferencesHelper = new PreferencesHelper(activity);
    }

    @Override
    public AdapterNewSubLaundry.myViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(activity).inflate(R.layout.laundryitem, parent, false);
        return new AdapterNewSubLaundry.myViewHolder(root);
    }

    @Override
    public void onBindViewHolder(AdapterNewSubLaundry.myViewHolder holder, int position) {
        SubscriptionModel subscriptionModel = data.get(position);
        holder.Onbid(subscriptionModel);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {

        TextView name, type, val;
        ;


        public myViewHolder(View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.textname);
            type = itemView.findViewById(R.id.typeopen);
            val = itemView.findViewById(R.id.val);


        }

        private void Onbid(SubscriptionModel subscriptionModel) {

            name.setText(subscriptionModel.getName());
            type.setVisibility(View.GONE);
            val.setVisibility(View.GONE);

        }
    }
}
