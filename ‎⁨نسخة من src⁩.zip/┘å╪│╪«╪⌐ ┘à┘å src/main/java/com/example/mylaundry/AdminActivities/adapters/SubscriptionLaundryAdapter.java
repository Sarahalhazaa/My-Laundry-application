package com.example.mylaundry.AdminActivities.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.AdminActivities.Listener;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.R;
import com.example.mylaundry.databinding.ItemLaundromatSubscriptionBinding;

import java.util.ArrayList;

@SuppressLint("NotifyDataSetChanged")
public class SubscriptionLaundryAdapter extends RecyclerView.Adapter<SubscriptionLaundryAdapter.AdapterNewSubLaundryViewHolder> {

    Context mContext;
    ArrayList<SubscriptionModel> list;
    Listener listener;

    public void setData(ArrayList<SubscriptionModel> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    public ArrayList<SubscriptionModel> getData() {
        return list;
    }

    public SubscriptionLaundryAdapter(Context mContext) {
        this.mContext = mContext;
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public AdapterNewSubLaundryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_laundromat_subscription, parent, false);
        return new AdapterNewSubLaundryViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterNewSubLaundryViewHolder holder, int position) {
        SubscriptionModel model = list.get(position);
        holder.bind(model);
        holder.itemView.setOnClickListener(v -> listener.onClick(position));
    }

    @Override
    public int getItemCount() {
        return (list != null ? list.size() : 0);
    }


    static class AdapterNewSubLaundryViewHolder extends RecyclerView.ViewHolder {
        ItemLaundromatSubscriptionBinding binding;

        private AdapterNewSubLaundryViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ItemLaundromatSubscriptionBinding.bind(itemView);
        }

        private void bind(SubscriptionModel model) {
            binding.name.setText(model.getName());
            binding.serviceCount.setText("Service Count: " + model.getServiceCount());
            binding.city.setText("District: " + model.getArea());
        }
    }

}