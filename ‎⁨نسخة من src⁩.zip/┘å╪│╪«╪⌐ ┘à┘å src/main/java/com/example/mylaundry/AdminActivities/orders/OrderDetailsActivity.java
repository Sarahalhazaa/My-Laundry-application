package com.example.mylaundry.AdminActivities.orders;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;

import com.example.mylaundry.AdapterAdmin.OrderServiceAdapter;
import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.databinding.ActivityOrderDetailsBinding;
import com.example.mylaundry.helpers.BaseActivity;
import com.example.mylaundry.helpers.Constants;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class OrderDetailsActivity extends BaseActivity {

    ActivityOrderDetailsBinding binding;
    OrderServiceAdapter adapter;
    RequestModel model;
    FirebaseFirestore db;
    ArrayList<RequestModel> list = new ArrayList<>();
    String keysub;
    String keyuser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOrderDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initView();
    }

    @SuppressLint("SetTextI18n")
    private void initView() {
        model = (RequestModel) getIntent().getSerializableExtra(Constants.TYPE_MODEL);
        db = FirebaseFirestore.getInstance();
        list.add(model);
         keysub=model.getKeysub();
         keyuser=model.getKeyuser();
        adapter = new OrderServiceAdapter(this);
        adapter.setData(list);
        binding.recyclerview.setAdapter(adapter);
        binding.recyclerview.setHasFixedSize(true);

        binding.title.setText("order (" + model.getNumberRequest() + ")");

        binding.clientDistrict.setText(model.getAddress());
        binding.clientStreetName.setText(model.getAddress());
        binding.clientNearest.setText(model.getAddress());
        binding.clientHouseNumber.setText(model.getAddress());


        binding.laundryName.setText(model.getNamelaundry());
        binding.laundryDistrict.setText(model.getAddress());
        binding.laundryStreetName.setText(model.getAddress());

        binding.tax.setText(model.getAddtax());
        binding.orderTotal.setText(model.getTotal()+" SR ");
        binding.delivary.setText("10 SR");
        binding.totalAmount.setText(model.getAmount());

        if (model.getType().equals(Constants.PREVIOUS)) {
            binding.cancelOrder.setVisibility(View.GONE);
        } else {
            binding.cancelOrder.setVisibility(View.VISIBLE);
        }

        binding.cancelOrder.setOnClickListener(v -> {
            loadingDialog.show();
            db.collection("RequestModel")
                    .document(model.getDocumentId())
                    .update("type", "request Rejected")
                    .addOnCompleteListener(task -> {
                        loadingDialog.dismissWithAnimation();
                        onBackPressed();
                    });
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        db.collection("Subscription")
                .document(keysub)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        String distr=documentSnapshot.getString("area");
                        String street=documentSnapshot.getString("street");
                        binding.laundryDistrict.setText(distr);
                        binding.laundryStreetName.setText(street);

                    }
                });
        db.collection("user")
                .document(keyuser)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        String distr=documentSnapshot.getString("cityname");

                        String nearest_teacher=documentSnapshot.getString("nearest_teacher");
                        String street_name=documentSnapshot.getString("street_name");
                        String home_number=documentSnapshot.getString("home_number");

                        binding.clientDistrict.setText(distr);
                        binding.clientStreetName.setText(street_name);
                        binding.clientNearest.setText(nearest_teacher);
                        binding.clientHouseNumber.setText(home_number);

                    }
                });
    }
}