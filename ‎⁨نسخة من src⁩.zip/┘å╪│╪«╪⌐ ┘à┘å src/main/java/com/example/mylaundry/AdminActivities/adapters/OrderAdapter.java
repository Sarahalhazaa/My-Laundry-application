package com.example.mylaundry.AdminActivities.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.AdminActivities.Listener;
import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.R;
import com.example.mylaundry.databinding.ItemOrderBinding;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;

@SuppressLint({"NotifyDataSetChanged", "SetTextI18n"})
public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.AdapterNewSubLaundryViewHolder> {

    Context mContext;
    ArrayList<RequestModel> list;
    Listener listener;

    public void setData(ArrayList<RequestModel> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    public ArrayList<RequestModel> getData() {
        return list;
    }

    public OrderAdapter(Context mContext) {
        this.mContext = mContext;
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public AdapterNewSubLaundryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order, parent, false);
        return new AdapterNewSubLaundryViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterNewSubLaundryViewHolder holder, int position) {
        RequestModel model = list.get(position);
        holder.bind(model);
        holder.itemView.setOnClickListener(v -> listener.onClick(position));
    }

    @Override
    public int getItemCount() {
        return (list != null ? list.size() : 0);
    }


    static class AdapterNewSubLaundryViewHolder extends RecyclerView.ViewHolder {
        ItemOrderBinding binding;

        private AdapterNewSubLaundryViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ItemOrderBinding.bind(itemView);

        }

        private void bind(RequestModel model) {
            binding.number.setText("OrderNumber: " + model.getNumberRequest());
            binding.status.setText("Status: " + model.getType());
            binding.total.setText("Total: " + model.getAmount());
        }
    }

}