package com.example.mylaundry.AdminActivities.orders;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import com.example.mylaundry.AdminActivities.adapters.OrderAdapter;
import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.R;
import com.example.mylaundry.databinding.FragmentOrdersBinding;
import com.example.mylaundry.helpers.BaseFragment;
import com.example.mylaundry.helpers.Constants;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

import java.util.ArrayList;

public class OrdersFragment extends BaseFragment {

    FragmentOrdersBinding binding;
    OrderAdapter adapter;
    ArrayList<RequestModel> list = new ArrayList<>();
    FirebaseFirestore db;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentOrdersBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView();
    }

    private void initView() {
        db = FirebaseFirestore.getInstance();

        binding.title.setText(getString(R.string.orders));
        binding.back.setOnClickListener(v -> requireActivity().onBackPressed());

        adapter = new OrderAdapter(requireActivity());
        adapter.setListener(position -> {
            Intent intent = new Intent(requireActivity(), OrderDetailsActivity.class);
            intent.putExtra(Constants.TYPE_MODEL, adapter.getData().get(position));
            startActivity(intent);
        });
        binding.recyclerview.setAdapter(adapter);
        binding.recyclerview.setHasFixedSize(true);
        getOrdersRequest();
    }

    private void getOrdersRequest() {
        loadingDialog.show();
        db.collection("RequestModel")
                .addSnapshotListener((value, error) -> {

                    if (error != null) {
                        Log.e("response", "Listen failed.", error);
                        return;
                    }

                    Log.e("response", "value:" + (value != null));
                    list.clear();
                    if (value != null) {
                        if (value.isEmpty()) {
                            binding.empty.setVisibility(View.VISIBLE);
                            binding.recyclerview.setVisibility(View.GONE);
                        } else {
                            for (QueryDocumentSnapshot document : value) {
                                RequestModel model = document.toObject(RequestModel.class);
                                model.setDocumentId(document.getId());
                                list.add(model);
                            }
                            adapter.setData(list);
                            binding.recyclerview.setVisibility(View.VISIBLE);
                            binding.empty.setVisibility(View.GONE);
                        }
                    } else {
                        binding.empty.setVisibility(View.VISIBLE);
                        binding.recyclerview.setVisibility(View.GONE);
                    }
                    loadingDialog.dismissWithAnimation();
                });
    }


}