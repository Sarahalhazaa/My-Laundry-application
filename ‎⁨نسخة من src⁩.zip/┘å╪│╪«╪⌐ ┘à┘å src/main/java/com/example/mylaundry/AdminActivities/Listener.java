package com.example.mylaundry.AdminActivities;

public interface Listener {

    void onClick(int position);


}
