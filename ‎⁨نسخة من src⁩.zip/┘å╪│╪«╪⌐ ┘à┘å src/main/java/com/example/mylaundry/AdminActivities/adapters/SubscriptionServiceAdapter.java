package com.example.mylaundry.AdminActivities.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.Model.Services;
import com.example.mylaundry.R;
import com.example.mylaundry.databinding.ItemSubscriptionServiceBinding;

import java.util.ArrayList;

@SuppressLint({"NotifyDataSetChanged","SetTextI18n"})
public class SubscriptionServiceAdapter extends RecyclerView.Adapter<SubscriptionServiceAdapter.AdapterNewSubLaundryViewHolder> {

    Context mContext;
    ArrayList<Services> list;

    public void setData(ArrayList<Services> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    public ArrayList<Services> getData() {
        return list;
    }

    public SubscriptionServiceAdapter(Context mContext) {
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public AdapterNewSubLaundryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_subscription_service, parent, false);
        return new AdapterNewSubLaundryViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterNewSubLaundryViewHolder holder, int position) {
        Services model = list.get(position);

        holder.binding.name.setText("Service Name: " + model.getEidtetxt());
        holder.binding.serviceCount.setText("Length of service: " + model.getNumberOfday());

        SubscriptionServiceItemAdapter adapter = new SubscriptionServiceItemAdapter();
        adapter.setData(model.getItemsservies());
        holder.binding.recyclerview.setAdapter(adapter);
        holder.binding.recyclerview.setHasFixedSize(true);
    }

    @Override
    public int getItemCount() {
        return (list != null ? list.size() : 0);
    }


    static class AdapterNewSubLaundryViewHolder extends RecyclerView.ViewHolder {
        ItemSubscriptionServiceBinding binding;

        private AdapterNewSubLaundryViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ItemSubscriptionServiceBinding.bind(itemView);
        }
    }

}