package com.example.mylaundry.AdminActivities.laundromats;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.mylaundry.AdminActivities.adapters.SubscriptionLaundryAdapter;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.databinding.FragmentLaundromatsSubscriptionsBinding;
import com.example.mylaundry.helpers.BaseFragment;
import com.example.mylaundry.helpers.Constants;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

@SuppressLint("SetTextI18n")
public class LaundromatsSubscriptionsFragment extends BaseFragment {

    private static final String ARG_TYPE = "arg_type";
    String type;
    FragmentLaundromatsSubscriptionsBinding binding;
    SubscriptionLaundryAdapter adapter;
    ArrayList<SubscriptionModel> list = new ArrayList<>();
    FirebaseFirestore db;

    public LaundromatsSubscriptionsFragment() {
        // Required empty public constructor
    }

    public static LaundromatsSubscriptionsFragment newInstance(String type) {
        LaundromatsSubscriptionsFragment fragment = new LaundromatsSubscriptionsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_TYPE, type);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            type = getArguments().getString(ARG_TYPE);
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentLaundromatsSubscriptionsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView();
    }

    private void initView() {
        switch (type) {
            case Constants.NEW:
                binding.title.setText("New Subscriptions");
                break;
            case Constants.CURRENT:
                binding.title.setText("Current Subscriptions");
                break;
            case Constants.RENEWAL:
                binding.title.setText("Subscription Renewal Requests");
                break;
            case Constants.PREVIOUS:
                binding.title.setText("Previous Subscriptions");
                break;
        }
        binding.back.setOnClickListener(v -> requireActivity().onBackPressed());

        db = FirebaseFirestore.getInstance();
        adapter = new SubscriptionLaundryAdapter(requireActivity());
        adapter.setListener(position -> {
            Intent intent = new Intent(requireActivity(), LaundromatsSubscriptionActivity.class);
            intent.putExtra(Constants.TYPE_MODEL, adapter.getData().get(position));
            startActivity(intent);
        });
        binding.recyclerview.setAdapter(adapter);
        binding.recyclerview.setHasFixedSize(true);
        getSubscriptionRequest();

    }

    private void getSubscriptionRequest() {
        loadingDialog.show();
        db.collection("Subscription").whereEqualTo("type",type).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        list.clear();
                        if (!queryDocumentSnapshots.isEmpty()) {

                            for (QueryDocumentSnapshot d : queryDocumentSnapshots) {
                                SubscriptionModel model = d.toObject(SubscriptionModel.class);
                                list.add(model);
                            }
                            adapter.setData(list);
                            binding.recyclerview.setVisibility(View.VISIBLE);
                            binding.empty.setVisibility(View.GONE);
                            loadingDialog.dismissWithAnimation();
                        }else {
                            loadingDialog.dismissWithAnimation();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@org.checkerframework.checker.nullness.qual.NonNull Exception e) {
                        // if we do not get any data or any error we are displaying
                        // a toast message that we do not get any data
                        Toast.makeText(getActivity(), "Fail to get the data.", Toast.LENGTH_SHORT).show();
                        loadingDialog.dismissWithAnimation();
                    }
                });



    }

}