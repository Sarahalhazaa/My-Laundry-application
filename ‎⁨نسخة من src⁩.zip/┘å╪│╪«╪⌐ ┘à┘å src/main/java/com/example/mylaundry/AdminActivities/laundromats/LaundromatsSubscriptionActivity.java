package com.example.mylaundry.AdminActivities.laundromats;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.RequiresApi;

import com.example.mylaundry.AdminActivities.adapters.SubscriptionServiceAdapter;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.R;
import com.example.mylaundry.databinding.ActivityLaundromatsSubscriptionBinding;
import com.example.mylaundry.helpers.BaseActivity;
import com.example.mylaundry.helpers.Constants;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

@RequiresApi(api = Build.VERSION_CODES.O)
public class LaundromatsSubscriptionActivity extends BaseActivity {

    ActivityLaundromatsSubscriptionBinding binding;
    SubscriptionModel model;
    FirebaseFirestore db;
    SubscriptionServiceAdapter adapter;
    String newDate = "";
    String endDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLaundromatsSubscriptionBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initView();
    }

    private void initView() {
        model = (SubscriptionModel) getIntent().getSerializableExtra(Constants.TYPE_MODEL);
        db = FirebaseFirestore.getInstance();

        switch (model.getType()) {
            case Constants.NEW:
                binding.containerNew.setVisibility(View.VISIBLE);
                binding.containerRenewal.setVisibility(View.GONE);
                binding.delete.setVisibility(View.GONE);
                break;
            case Constants.CURRENT:
                binding.containerNew.setVisibility(View.GONE);
                binding.containerRenewal.setVisibility(View.GONE);
                binding.delete.setVisibility(View.VISIBLE);
                break;
            case Constants.RENEWAL:
                binding.containerNew.setVisibility(View.GONE);
                binding.containerRenewal.setVisibility(View.GONE);
                binding.delete.setVisibility(View.GONE);

                break;
            case Constants.PREVIOUS:
                binding.containerNew.setVisibility(View.GONE);
                binding.containerRenewal.setVisibility(View.GONE);
                binding.delete.setVisibility(View.GONE);
                break;
        }

        binding.back.setOnClickListener(v -> onBackPressed());
        binding.title.setText(model.getName());

        binding.name.setText(model.getName());
        binding.phone.setText("05 "+model.getPhone());
        binding.No.setText(model.getCommercial_register_number());
        binding.city.setText(model.getArea());
        binding.laundryEmail.setText(model.getEmail());
        binding.laundryPhone.setText(model.getPhone());
        binding.subscriptionStart.setText(model.getNowdate());
        binding.subscriptionEnd.setText(model.getEndDate());
        binding.subscriptionPeriod.setText(model.getDuration());
        binding.evaluation.setText(model.getEvaluation());


        adapter = new SubscriptionServiceAdapter(this);
        binding.recyclerview.setAdapter(adapter);
        binding.recyclerview.setHasFixedSize(true);

        switchType(Constants.SERVICE_CLOTHING);

        binding.clothing.setOnClickListener(v -> switchType(Constants.SERVICE_CLOTHING));
        binding.carpet.setOnClickListener(v -> switchType(Constants.SERVICE_CARPET));
        binding.home.setOnClickListener(v -> switchType(Constants.SERVICE_HOME));

        onViewClick();
    }

    private void onViewClick() {

        binding.reject.setOnClickListener(v -> {
            loadingDialog.show();
            db.collection("Subscription")
                    .document(model.getDocumentId())
                    .update("type",Constants.PREVIOUS)
                    .addOnCompleteListener(task -> {
                        loadingDialog.dismissWithAnimation();
                        onBackPressed();
                    });
        });
        binding.approval.setOnClickListener(v -> {
            loadingDialog.show();
            db.collection("Subscription")
                    .document(model.getDocumentId())
                    .update("type", Constants.CURRENT)
                    .addOnCompleteListener(task -> {
                        loadingDialog.dismissWithAnimation();
                        onBackPressed();
                    });
        });


        binding.rejectRenewal.setOnClickListener(v -> {
            loadingDialog.show();
            db.collection("Subscription")
                    .document(model.getDocumentId())
//                    .update("type", Constants.PREVIOUS)
                    .delete()
                    .addOnCompleteListener(task -> {
                        loadingDialog.dismissWithAnimation();
                        onBackPressed();
                    });
        });
        binding.approvalRenewal.setOnClickListener(v -> {
            loadingDialog.show();
            db.collection("Subscription")
                    .document(model.getDocumentId())
                    .update("type", Constants.CURRENT,
                            "endDate", endDate,
                            "nowdate", newDate
                    ).addOnCompleteListener(task -> {
                        loadingDialog.dismissWithAnimation();
                        onBackPressed();
                    });
        });


        binding.delete.setOnClickListener(v -> {
            loadingDialog.show();
            db.collection("Subscription")
                    .document(model.getDocumentId())
                    .update("type",Constants.PREVIOUS)
                    .addOnCompleteListener(task -> {
                        loadingDialog.dismissWithAnimation();
                        onBackPressed();
                    });
        });

        findDifference(model.getNowdate(), model.getEndDate());

    }

    private void findDifference(String start, String end) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
        Period diff = Period.between(LocalDate.parse(start).withDayOfMonth(1), LocalDate.parse(end).withDayOfMonth(1));
        int months = diff.getMonths();
        int years = diff.getYears();
        Calendar today = Calendar.getInstance();
        newDate = sdf.format(today.getTime());
        if (months == 6) {
            today.set(Calendar.MONTH, 6);
        } else {
            int year = Calendar.getInstance().get(Calendar.YEAR);
            year = year + 1;
            today.set(Calendar.YEAR, year);
        }
        endDate = sdf.format(today.getTime());
        Log.e("response", "months: " + months);
        Log.e("response", "years: " + years);
        Log.e("response", "newDate: " + newDate);
        Log.e("response", "endDate: " + endDate);
    }

    private void switchType(String type) {
        getServicesRequest(type);
        switch (type) {
            case Constants.SERVICE_CLOTHING:
                binding.clothing.setBackgroundResource(R.drawable.bg_blue);
                binding.carpet.setBackgroundResource(R.drawable.bg_gray);
                binding.home.setBackgroundResource(R.drawable.bg_gray);
                break;
            case Constants.SERVICE_CARPET:
                binding.clothing.setBackgroundResource(R.drawable.bg_gray);
                binding.carpet.setBackgroundResource(R.drawable.bg_blue);
                binding.home.setBackgroundResource(R.drawable.bg_gray);
                break;
            case Constants.SERVICE_HOME:
                binding.clothing.setBackgroundResource(R.drawable.bg_gray);
                binding.carpet.setBackgroundResource(R.drawable.bg_gray);
                binding.home.setBackgroundResource(R.drawable.bg_blue);
                break;
        }
    }

    private void getServicesRequest(String nameService) {
        db.collection("Services")
                .whereEqualTo("email", model.getEmail())
                .whereEqualTo("nameService", nameService)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        Log.e("response", "Listen failed.", error);
                        return;
                    }
                    if (value != null) {
                        ArrayList<Services> list = new ArrayList<>();
                        for (QueryDocumentSnapshot d : value) {
                            Services model = d.toObject(Services.class);
                            list.add(model);
                        }
                        adapter.setData(list);
                        Log.e("response", "list: " + list);
                    }
                });

    }
}