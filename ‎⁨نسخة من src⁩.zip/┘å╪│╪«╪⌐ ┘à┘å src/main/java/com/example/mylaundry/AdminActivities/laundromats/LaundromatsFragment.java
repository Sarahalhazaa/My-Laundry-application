package com.example.mylaundry.AdminActivities.laundromats;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.mylaundry.databinding.FragmentLaundromatsBinding;
import com.example.mylaundry.helpers.BaseFragment;
import com.example.mylaundry.helpers.Constants;

public class LaundromatsFragment extends BaseFragment {

    FragmentLaundromatsBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentLaundromatsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView();
    }

    private void initView() {
        binding.back.setOnClickListener(v -> {
            requireActivity().onBackPressed();
        });
        binding.newSubscription.setOnClickListener(v -> {
            replaceAdmenFragments(LaundromatsSubscriptionsFragment.newInstance(Constants.NEW));
        });
        binding.currentSubscription.setOnClickListener(v -> {
            replaceAdmenFragments(LaundromatsSubscriptionsFragment.newInstance(Constants.CURRENT));
        });
        binding.renewalSubscription.setOnClickListener(v -> {
            replaceAdmenFragments(LaundromatsSubscriptionsFragment.newInstance(Constants.RENEWAL));
        });
        binding.previousSubscription.setOnClickListener(v -> {
            replaceAdmenFragments(LaundromatsSubscriptionsFragment.newInstance(Constants.PREVIOUS));
        });
    }

}