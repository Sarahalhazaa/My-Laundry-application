package com.example.mylaundry.AdminActivities.adapters;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mylaundry.Model.ItemServies;
import com.example.mylaundry.R;
import com.example.mylaundry.databinding.ItemSubscriptionServiceItemBinding;

import java.util.ArrayList;

@SuppressLint({"NotifyDataSetChanged", "SetTextI18n"})
public class SubscriptionServiceItemAdapter extends RecyclerView.Adapter<SubscriptionServiceItemAdapter.AdapterNewSubLaundryViewHolder> {

    ArrayList<ItemServies> list;

    public void setData(ArrayList<ItemServies> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    public ArrayList<ItemServies> getData() {
        return list;
    }

    public SubscriptionServiceItemAdapter() {
    }

    @NonNull
    @Override
    public AdapterNewSubLaundryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_subscription_service_item, parent, false);
        return new AdapterNewSubLaundryViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterNewSubLaundryViewHolder holder, int position) {
        ItemServies model = list.get(position);

        holder.binding.name.setText((position + 1) + "- " + model.getName());
        holder.binding.price.setText("Price: " + model.getPrice() + " SR");

    }

    @Override
    public int getItemCount() {
        return (list != null ? list.size() : 0);
    }


    static class AdapterNewSubLaundryViewHolder extends RecyclerView.ViewHolder {
        ItemSubscriptionServiceItemBinding binding;

        private AdapterNewSubLaundryViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ItemSubscriptionServiceItemBinding.bind(itemView);
        }
    }

}