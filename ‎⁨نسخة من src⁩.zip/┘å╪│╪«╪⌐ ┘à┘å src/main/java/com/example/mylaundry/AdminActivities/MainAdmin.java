package com.example.mylaundry.AdminActivities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;

import com.example.mylaundry.AdminActivities.AdminFragment.AdminFragmentMain;
import com.example.mylaundry.Fragment.MoreFragment;
import com.example.mylaundry.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainAdmin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_admin);

        BottomNavigationView bottomNav = findViewById(R.id.admin_navigatin_view);
        bottomNav.setOnNavigationItemSelectedListener(navListener);

        getSupportFragmentManager().beginTransaction().replace(R.id.admin_container, new AdminFragmentMain()).commit();

    }

    private final BottomNavigationView.OnNavigationItemSelectedListener navListener = item -> {
        // By using switch we can easily get
        // the selected fragment
        // by using there id.
        Fragment selectedFragment = null;
        int itemId = item.getItemId();
        if (itemId == R.id.home_admin) {
            selectedFragment = new AdminFragmentMain();
        } else if (itemId == R.id.more_admin) {
           // selectedFragment = new AdminFragmentMore();
            selectedFragment = new MoreFragment();
        }
        // It will help to replace the
        // one fragment to other.
        if (selectedFragment != null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.admin_container, selectedFragment).commit();
        }
        return true;
    };


}