package com.example.mylaundry.AdminActivities.drivers;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;


import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.mylaundry.AdminActivities.adapters.SubscriptionDriverAdapter;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.databinding.FragmentDriversSubscriptionsBinding;
import com.example.mylaundry.helpers.BaseFragment;
import com.example.mylaundry.helpers.Constants;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

import java.util.ArrayList;

@SuppressLint("SetTextI18n")
public class DriversSubscriptionsFragment extends BaseFragment {

    private static final String ARG_TYPE = "arg_type";
    String type;
    FragmentDriversSubscriptionsBinding binding;
    SubscriptionDriverAdapter adapter;
    ArrayList<SubscriptionModel> list = new ArrayList<>();
    FirebaseFirestore db;

    public DriversSubscriptionsFragment() {
        // Required empty public constructor
    }

    public static DriversSubscriptionsFragment newInstance(String type) {
        DriversSubscriptionsFragment fragment = new DriversSubscriptionsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_TYPE, type);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            type = getArguments().getString(ARG_TYPE);
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentDriversSubscriptionsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView();
    }

    private void initView() {
        switch (type) {
            case Constants.NEW:
                binding.title.setText("New Subscriptions");
                break;
            case Constants.CURRENT:
                binding.title.setText("Current Subscriptions");
                break;
            case Constants.RENEWAL:
                binding.title.setText("Subscription Renewal Requests");
                break;
            case Constants.PREVIOUS:
                binding.title.setText("Previous Subscriptions");
                break;
        }
        binding.back.setOnClickListener(v -> requireActivity().onBackPressed());

        db = FirebaseFirestore.getInstance();
        adapter = new SubscriptionDriverAdapter(requireActivity());
        adapter.setListener(position -> {
            Intent intent = new Intent(requireActivity(), DriverSubscriptionActivity.class);
            intent.putExtra(Constants.TYPE_MODEL, adapter.getData().get(position));
            startActivity(intent);
        });
        binding.recyclerview.setAdapter(adapter);
        binding.recyclerview.setHasFixedSize(true);
        getSubscriptionRequest();

    }

    private void getSubscriptionRequest() {
        loadingDialog.show();
        db.collection("SubscriptionDriver")
                .whereEqualTo("type", type)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        Log.e("response", "Listen failed.", error);
                        return;
                    }
                    Log.e("response", "value:" + (value != null));
                    list.clear();
                    if (value != null) {
                        if (value.isEmpty()) {
                            binding.empty.setVisibility(View.VISIBLE);
                            binding.recyclerview.setVisibility(View.GONE);
                        } else {
                            for (QueryDocumentSnapshot document : value) {
                                SubscriptionModel model = document.toObject(SubscriptionModel.class);
                                model.setDocumentId(document.getId());
                                list.add(model);
                            }
                            adapter.setData(list);
                            binding.recyclerview.setVisibility(View.VISIBLE);
                            binding.empty.setVisibility(View.GONE);
                        }
                    } else {
                        binding.empty.setVisibility(View.VISIBLE);
                        binding.recyclerview.setVisibility(View.GONE);
                    }
                    loadingDialog.dismissWithAnimation();
                });
    }


}