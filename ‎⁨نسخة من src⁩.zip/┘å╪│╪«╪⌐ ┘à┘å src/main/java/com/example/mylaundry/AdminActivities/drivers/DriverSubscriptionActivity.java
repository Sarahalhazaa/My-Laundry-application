package com.example.mylaundry.AdminActivities.drivers;

import android.annotation.TargetApi;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;


import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.databinding.ActivityDriverSubscriptionBinding;
import com.example.mylaundry.helpers.BaseActivity;
import com.example.mylaundry.helpers.Constants;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;
import java.util.Locale;


public class DriverSubscriptionActivity extends BaseActivity {

    ActivityDriverSubscriptionBinding binding;
    SubscriptionModel model;
    FirebaseFirestore db;
    String newDate = "";
    String endDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDriverSubscriptionBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initView();
    }

    private void initView() {
        model = (SubscriptionModel) getIntent().getSerializableExtra(Constants.TYPE_MODEL);
        db = FirebaseFirestore.getInstance();
        Log.e("response", "getDocumentId: " + model.getDocumentId());

        switch (model.getType()) {
            case Constants.NEW:
                binding.containerNew.setVisibility(View.VISIBLE);
                binding.containerRenewal.setVisibility(View.GONE);
                binding.delete.setVisibility(View.GONE);
                break;
            case Constants.CURRENT:
                binding.containerNew.setVisibility(View.GONE);
                binding.containerRenewal.setVisibility(View.GONE);
                binding.delete.setVisibility(View.VISIBLE);
                break;
            case Constants.RENEWAL:
                binding.containerNew.setVisibility(View.GONE);
                binding.containerRenewal.setVisibility(View.VISIBLE);
                binding.delete.setVisibility(View.GONE);
                break;
            case Constants.PREVIOUS:
                binding.containerNew.setVisibility(View.GONE);
                binding.containerRenewal.setVisibility(View.GONE);
                binding.delete.setVisibility(View.GONE);
                break;
        }

        binding.back.setOnClickListener(v -> onBackPressed());
        binding.title.setText(model.getName());

        binding.idNo.setText(model.getID());

        binding.city.setText(model.getArea());
        binding.driverEmail.setText(model.getEmail());
        binding.driverPhone.setText(model.getPhone());
        binding.subscriptionStart.setText(model.getNowdate());
        binding.subscriptionEnd.setText(model.getEndDate());
        binding.subscriptionPeriod.setText(model.getDuration());
        binding.evaluation.setText(model.getEvaluation());

        onViewClick();
    }

    private void onViewClick() {

        binding.reject.setOnClickListener(v -> {
            loadingDialog.show();
            db.collection("SubscriptionDriver")
                    .document(model.getDocumentId())
                    .update("type",Constants.PREVIOUS)
                    .addOnCompleteListener(task -> {
                        loadingDialog.dismissWithAnimation();
                        onBackPressed();
                    });
        });
        binding.approval.setOnClickListener(v -> {
            loadingDialog.show();
            db.collection("SubscriptionDriver")
                    .document(model.getDocumentId())
                    .update("type", Constants.CURRENT)
                    .addOnCompleteListener(task -> {
                        loadingDialog.dismissWithAnimation();
                        onBackPressed();
                    });
        });


        binding.rejectRenewal.setOnClickListener(v -> {
            loadingDialog.show();
            db.collection("SubscriptionDriver")
                    .document(model.getDocumentId())
//                    .update("type", Constants.PREVIOUS)
                    .update("type",Constants.RENEWAL)
                    .addOnCompleteListener(task -> {
                        loadingDialog.dismissWithAnimation();
                        onBackPressed();
                    });
        });

        binding.approvalRenewal.setOnClickListener(v -> {
            loadingDialog.show();
            db.collection("SubscriptionDriver")
                    .document(model.getDocumentId())
                    .update("type", Constants.CURRENT,
                            "endDate", endDate,
                            "nowdate", newDate
                    ).addOnCompleteListener(task -> {
                        loadingDialog.dismissWithAnimation();
                        onBackPressed();
                    });
        });
        binding.delete.setOnClickListener(v -> {
            loadingDialog.show();
            db.collection("SubscriptionDriver")
                    .document(model.getDocumentId())
                    .update("type",Constants.PREVIOUS)
                    .addOnCompleteListener(task -> {
                        loadingDialog.dismissWithAnimation();
                        onBackPressed();
                    });
        });

        findDifference(model.getNowdate(), model.getEndDate());

    }

    @TargetApi(Build.VERSION_CODES.O)
    private void findDifference(String start, String end) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
        Period diff = Period.between(LocalDate.parse(start).withDayOfMonth(1), LocalDate.parse(end).withDayOfMonth(1));
        int months = diff.getMonths();
        int years = diff.getYears();
        Calendar today = Calendar.getInstance();
        newDate = sdf.format(today.getTime());
        if (months == 6) {
            today.set(Calendar.MONTH, 6);
        } else {
            int year = Calendar.getInstance().get(Calendar.YEAR);
            year = year + 1;
            today.set(Calendar.YEAR, year);
        }
        endDate = sdf.format(today.getTime());
        Log.e("response", "months: " + months);
        Log.e("response", "years: " + years);
        Log.e("response", "newDate: " + newDate);
        Log.e("response", "endDate: " + endDate);
    }

}