package com.example.mylaundry.AdminActivities.AdminFragment;

import android.os.Bundle;



import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.mylaundry.AdminActivities.drivers.DriversFragment;
import com.example.mylaundry.AdminActivities.laundromats.LaundromatsFragment;
import com.example.mylaundry.AdminActivities.orders.OrdersFragment;
import com.example.mylaundry.databinding.FragmentAdminMainBinding;
import com.example.mylaundry.helpers.BaseFragment;

import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

public class AdminFragmentMain extends BaseFragment {
    FragmentAdminMainBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentAdminMainBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView();
    }

    private void initView() {

        binding.laundromats.setOnClickListener(v -> {
            replaceAdmenFragments(new LaundromatsFragment());
        });

        binding.drivers.setOnClickListener(v -> {
            replaceAdmenFragments(new DriversFragment());
        });

        binding.orders.setOnClickListener(v -> {
            replaceAdmenFragments(new OrdersFragment());
        });
    }
}