package com.example.mylaundry.AcivitysMainFragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Adapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mylaundry.AdapterView.AdapterOrder;
import com.example.mylaundry.AdapterView.ModelArray;
import com.example.mylaundry.AdapterView.OrderAdapterCon;
import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.R;
import com.kofigyan.stateprogressbar.StateProgressBar;
import com.kofigyan.stateprogressbar.components.StateItem;
import com.kofigyan.stateprogressbar.listeners.OnStateItemClickListener;

import java.util.ArrayList;

public class Details_Order extends AppCompatActivity {
    ArrayList<RequestModel> requestModels;
    RecyclerView recyclerView;
    TextView total, addtax, amount, namela, Date, stat, number;
    TextView time;
    ArrayList<Services> services;
    AdapterOrder adapterCon;
    ModelArray model;
    String[] descriptionData = {"Waiting for request", "request accepted",
            "Items received", "Items have been delivered to the laundromat", "Delivered"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_order);
        namela = findViewById(R.id.namelaundryorder);
        recyclerView = findViewById(R.id.recyclerView);
        stat = findViewById(R.id.textView70);
        total = findViewById(R.id.totalnumber);
        number = findViewById(R.id.textView33);
        addtax = findViewById(R.id.totalprice);
        amount = findViewById(R.id.totalp);
        Date = findViewById(R.id.textView73);
        stat.setText("request accepted");

        StateProgressBar stateProgressBar = findViewById(R.id.your_state_progress_bar_id);
        stateProgressBar.setOnStateItemClickListener(new OnStateItemClickListener() {
            @Override
            public void onStateItemClick(StateProgressBar stateProgressBar, StateItem stateItem, int stateNumber, boolean isCurrentState) {
                Toast.makeText(getApplicationContext(), "state Clicked Number is "
                        + stateNumber, Toast.LENGTH_LONG).show();
            }
        });

//        switch (stateProgressBar.getCurrentStateNumber()) {
//            case 1:
//                stateProgressBar.setCurrentStateNumber(StateProgressBar.StateNumber.TWO);
//                break;
//            case 2:
//                stateProgressBar.setCurrentStateNumber(StateProgressBar.StateNumber.THREE);
//                break;
//            case 3:
//                stateProgressBar.setCurrentStateNumber(StateProgressBar.StateNumber.FOUR);
//                break;
//            case 4:
//                stateProgressBar.setAllStatesCompleted(true);
//                break;
//        }

        // stateProgressBar.setStateDescriptionData(descriptionData);

        String name = getIntent().getStringExtra("namela");
        namela.setText(name);
        String totall = getIntent().getStringExtra("total");
        total.setText(totall);
        String Addtax = getIntent().getStringExtra("addtax");
        addtax.setText(Addtax);
        String Amount = getIntent().getStringExtra("amount");
        amount.setText(Amount);

        model = (ModelArray) getIntent().getSerializableExtra("getdata");


        String date = getIntent().getStringExtra("date");
        String Nu = getIntent().getStringExtra("number");

        Date.setText("Date : " + date);


        number.setText("Order" + "(" + Nu + ")");


        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapterCon = new AdapterOrder(this, model.getOrderdel());
        recyclerView.setAdapter(adapterCon);


    }
}