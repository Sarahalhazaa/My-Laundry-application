package com.example.mylaundry.AcivitysMainFragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.mylaundry.AcivitysOfLaundry.OrderConfirmation;
import com.example.mylaundry.AdapterView.AdapterOrder;
import com.example.mylaundry.AdapterView.AdapterServices;
import com.example.mylaundry.AdapterView.AdapterviewOrder;
import com.example.mylaundry.AdapterView.ModelArray;
import com.example.mylaundry.Model.RequestModel;
import com.example.mylaundry.Model.Services;
import com.example.mylaundry.OwnerActivitys.ActivitysOwner.SubscriptionModel;
import com.example.mylaundry.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;
import java.util.List;

import io.grpc.Server;

public class ActivityCurrentRequests extends AppCompatActivity {


    ArrayList<RequestModel> st;

   // ArrayList<ModelArray> data;

    RecyclerView recyclerView;
    AdapterviewOrder adapterviewOrder;
    FirebaseFirestore db;
    RequestModel requestModel;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_requests);

        db = FirebaseFirestore.getInstance();
        recyclerView = findViewById(R.id.viewrec);
        st = new ArrayList<>();
        auth=FirebaseAuth.getInstance();
        Button back = findViewById(R.id.button24);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        getData();

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapterviewOrder = new AdapterviewOrder(this, st);
        recyclerView.setAdapter(adapterviewOrder);
    }

    void getData() {
        db.collection("RequestModel").whereEqualTo("keyuser",auth.getUid()).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        if (!queryDocumentSnapshots.isEmpty()) {
                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                            for (DocumentSnapshot d : list) {
                                requestModel = d.toObject(RequestModel.class);
                                if (requestModel.getType().equals("Delivered")||requestModel.getType().equals("request Rejected")){
                                    Toast.makeText(ActivityCurrentRequests.this, "No data found ", Toast.LENGTH_SHORT).show();

                                }
                                else {
                                    st.add(requestModel);

                                }

                            }
                            adapterviewOrder.update(st);

                        } else {

                            Toast.makeText(ActivityCurrentRequests.this, "No data found ", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(e -> {
                    // if we do not get any data or any error we are displaying
                    // a toast message that we do not get any data
                    Toast.makeText(ActivityCurrentRequests.this, "Fail to get the data.", Toast.LENGTH_SHORT).show();
                });


    }
}